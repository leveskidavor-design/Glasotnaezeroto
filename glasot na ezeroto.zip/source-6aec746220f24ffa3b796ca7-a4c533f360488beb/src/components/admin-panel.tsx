import { Link, useRouter } from '@tanstack/react-router'
import {
  Crosshair,
  Loader2,
  LockKeyhole,
  Plus,
  Ship,
  Trash2,
  RotateCcw,
  Save,
  Undo2,
} from 'lucide-react'
import { useEffect, useMemo, useState, useSyncExternalStore } from 'react'
import { toast } from 'sonner'
import { AdminStopsMap, type EditableStop } from '@/components/admin-stops-map'
import { StopTextsEditor, UiTextsEditor } from '@/components/admin-texts'
import { BoatsManager, TourLink } from '@/components/admin-boats'
import { OwnDevices } from '@/components/admin-own-devices'
import { LeafletAdminMap } from '@/components/leaflet-admin-map'
import { SiteHeader } from '@/components/site-header'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { STOPS } from '@/data/tour'
import { AUTH_ERRORS, adminSession } from '@/lib/admin-auth'
import {
  isExtraStop,
  MAX_EXTRA_STOPS,
  RADIUS_MAX,
  RADIUS_MIN,
  type BoatInfo,
} from '@/lib/stop-positions'
import { useStops } from '@/lib/stops-context'
import {
  addBoatStop,
  deleteBoatStop,
  resetTourConfig,
  saveTourConfig,
  verifyAdminPassword,
} from '@/lib/stops.functions'
import { cn } from '@/lib/utils'

/**
 * Admin area. Without `boat`: the main admin (shared defaults and the boats).
 * With `boat`: that boat's own positions, texts and labels.
 */
export function AdminPanel({ boat }: { boat?: BoatInfo }) {
  const session = adminSession(boat?.id)
  const password = useSyncExternalStore(
    session.subscribe,
    session.get,
    session.getServer,
  )
  const checked = password !== undefined
  const logout = () => session.set(null)

  return (
    <div className="min-h-screen bg-cream">
      <SiteHeader />
      <main className="mx-auto max-w-content px-4 py-6 sm:px-6 sm:py-10">
        {!checked ? (
          <div className="grid place-items-center py-24" role="status">
            <Loader2 className="size-6 animate-spin text-lake motion-reduce:animate-none" />
            <span className="sr-only">Се вчитува…</span>
          </div>
        ) : password ? (
          <AdminSections
            boat={boat}
            password={password}
            onAuthLost={(msg) => {
              toast.error(msg)
              logout()
            }}
          />
        ) : (
          <Login boat={boat} onSuccess={(pw) => session.set(pw)} />
        )}
      </main>
    </div>
  )
}

const ALL_SECTIONS = [
  { id: 'boats', label: 'Бродови', mainOnly: true, boatOnly: false },
  {
    id: 'places',
    label: 'Локации и радиуси',
    mainOnly: false,
    boatOnly: false,
  },
  {
    id: 'stops',
    label: 'Текстови на точките',
    mainOnly: false,
    boatOnly: false,
  },
  {
    id: 'ui',
    label: 'Натписи во апликацијата',
    mainOnly: false,
    boatOnly: false,
  },
  { id: 'devices', label: 'Уреди', mainOnly: false, boatOnly: true },
] as const

type SectionId = (typeof ALL_SECTIONS)[number]['id']

/** The three admin areas. All stay mounted so unsaved edits survive switching. */
function AdminSections({
  boat,
  password,
  onAuthLost,
}: {
  boat?: BoatInfo
  password: string
  onAuthLost: (message: string) => void
}) {
  const SECTIONS = ALL_SECTIONS.filter((s) =>
    boat ? !s.mainOnly : !s.boatOnly,
  )
  const [section, setSection] = useState<SectionId>(SECTIONS[0].id)
  const boatId = boat?.id
  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl font-bold text-lake-deep">
            {boat ? boat.name : 'Главен админ'}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {boat ? (
              <>
                Измените важат само за овој брод. Линк за турата:{' '}
                <TourLink boatId={boat.id} />
              </>
            ) : (
              'Заеднички вредности за сите бродови и управување со бродовите.'
            )}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm" asChild>
            {boat ? (
              <Link to="/b/$boat" params={{ boat: boat.id }}>
                <Ship className="size-4" /> Кон турата
              </Link>
            ) : (
              <Link to="/tour">
                <Ship className="size-4" /> Кон турата
              </Link>
            )}
          </Button>
        </div>
      </div>
      <div
        className="mt-4 flex flex-wrap gap-1 rounded-2xl border border-lake-deep/15 bg-white p-1 sm:inline-flex sm:rounded-full"
        role="tablist"
        aria-label="Што уредувате"
      >
        {SECTIONS.map((s) => (
          <button
            key={s.id}
            type="button"
            role="tab"
            id={`tab-${s.id}`}
            aria-selected={section === s.id}
            aria-controls={`panel-${s.id}`}
            onClick={() => setSection(s.id)}
            className={cn(
              'rounded-full px-4 py-2 text-sm font-semibold transition-colors motion-reduce:transition-none focus-visible:outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50',
              section === s.id
                ? 'bg-lake-deep text-white'
                : 'text-lake-deep hover:bg-lake-deep/5',
            )}
          >
            {s.label}
          </button>
        ))}
      </div>
      {SECTIONS.map((s) => (
        <section
          key={s.id}
          id={`panel-${s.id}`}
          role="tabpanel"
          aria-labelledby={`tab-${s.id}`}
          hidden={section !== s.id}
          className="mt-6"
        >
          {s.id === 'boats' ? (
            <BoatsManager password={password} onAuthLost={onAuthLost} />
          ) : s.id === 'places' ? (
            <Editor
              password={password}
              boatId={boatId}
              onAuthLost={onAuthLost}
            />
          ) : s.id === 'devices' ? (
            boat && (
              <OwnDevices
                boatId={boat.id}
                password={password}
                onAuthLost={onAuthLost}
              />
            )
          ) : s.id === 'stops' ? (
            <StopTextsEditor
              password={password}
              boatId={boatId}
              onAuthLost={onAuthLost}
            />
          ) : (
            <UiTextsEditor
              password={password}
              boatId={boatId}
              onAuthLost={onAuthLost}
            />
          )}
        </section>
      ))}
    </div>
  )
}

function Login({
  boat,
  onSuccess,
}: {
  boat?: BoatInfo
  onSuccess: (password: string) => void
}) {
  const [value, setValue] = useState('')
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!value) return
    setPending(true)
    setError(null)
    try {
      const res = await verifyAdminPassword({
        data: { password: value, boatId: boat?.id },
      })
      if (res.ok) onSuccess(value)
      else setError(AUTH_ERRORS[res.error])
    } catch {
      setError('Серверот не одговара. Проверете ја врската и обидете се пак.')
    } finally {
      setPending(false)
    }
  }

  return (
    <div className="mx-auto max-w-sm py-10">
      <div className="rounded-3xl border border-lake-deep/10 bg-white p-6 shadow-sm">
        <div className="mb-5 grid size-12 place-items-center rounded-2xl bg-lake-deep/10 text-lake-deep">
          <LockKeyhole className="size-6" />
        </div>
        <h1 className="font-display text-3xl font-bold text-lake-deep">
          {boat ? boat.name : 'Главен админ'}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {boat
            ? 'Внесете ја лозинката на бродот за да ги менувате точките, текстовите и натписите.'
            : 'Внесете ја главната лозинка за да ги управувате бродовите и заедничките вредности.'}
        </p>
        <form onSubmit={submit} className="mt-6 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="admin-password">Лозинка</Label>
            <Input
              id="admin-password"
              type="password"
              autoComplete="current-password"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              aria-invalid={!!error}
              aria-describedby={error ? 'admin-password-error' : undefined}
              autoFocus
            />
            {error && (
              <p
                id="admin-password-error"
                role="alert"
                className="text-sm text-destructive"
              >
                {error}
              </p>
            )}
          </div>
          <Button type="submit" className="w-full" disabled={pending || !value}>
            {pending && (
              <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
            )}
            Најави се
          </Button>
        </form>
      </div>
      <p className="mt-4 text-center text-sm">
        {boat ? (
          <Link
            to="/b/$boat"
            params={{ boat: boat.id }}
            className="text-lake underline-offset-4 hover:underline"
          >
            ← Кон турата на бродот
          </Link>
        ) : (
          <Link to="/" className="text-lake underline-offset-4 hover:underline">
            ← Назад кон почетна
          </Link>
        )}
      </p>
    </div>
  )
}

interface Draft {
  lat: string
  lng: string
  radius: string
}

type Drafts = Record<string, Draft>

const toDraft = (s: { lat: number; lng: number; radius: number }): Draft => ({
  lat: String(s.lat),
  lng: String(s.lng),
  radius: String(s.radius),
})

function parseDraft(d: Draft) {
  const lat = Number(d.lat)
  const lng = Number(d.lng)
  const radius = Number(d.radius)
  const errors = {
    lat: d.lat.trim() === '' || !Number.isFinite(lat) || lat < -90 || lat > 90,
    lng:
      d.lng.trim() === '' || !Number.isFinite(lng) || lng < -180 || lng > 180,
    radius:
      d.radius.trim() === '' ||
      !Number.isInteger(radius) ||
      radius < RADIUS_MIN ||
      radius > RADIUS_MAX,
  }
  return {
    lat,
    lng,
    radius,
    errors,
    valid: !Object.values(errors).some(Boolean),
  }
}

function Editor({
  password,
  boatId,
  onAuthLost,
}: {
  password: string
  boatId?: string
  onAuthLost: (message: string) => void
}) {
  const router = useRouter()
  const saved = useStops()
  const savedDrafts = useMemo(
    () => Object.fromEntries(saved.map((s) => [s.id, toDraft(s)])) as Drafts,
    [saved],
  )
  const [drafts, setDrafts] = useState<Drafts>(savedDrafts)
  const [selectedId, setSelectedId] = useState<string | null>(
    saved[0]?.id ?? null,
  )
  const [focusKey, setFocusKey] = useState(0)
  // Google Maps first, then the keyless map if Google can't load
  const [mapProvider, setMapProvider] = useState<'google' | 'leaflet'>('google')
  const [mapStatus, setMapStatus] = useState<'loading' | 'ready' | 'error'>(
    'loading',
  )
  const [saving, setSaving] = useState(false)
  const [resetOpen, setResetOpen] = useState(false)
  const [locating, setLocating] = useState<string | null>(null)
  // A boat's own extra zones
  const [addOpen, setAddOpen] = useState(false)
  const [newName, setNewName] = useState('')
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const extraCount = saved.filter((s) => isExtraStop(s.id)).length

  // Start over from the saved data whenever it reloads (e.g. after saving)
  const [baseline, setBaseline] = useState(savedDrafts)
  if (baseline !== savedDrafts) {
    setBaseline(savedDrafts)
    setDrafts(savedDrafts)
  }

  const parsed = useMemo(
    () =>
      saved.map((s) => {
        const p = parseDraft(drafts[s.id] ?? toDraft(s))
        const changed =
          p.valid &&
          (p.lat !== s.lat || p.lng !== s.lng || p.radius !== s.radius)
        const def = STOPS.find((d) => d.id === s.id)
        const isDefault =
          !!def &&
          p.lat === def.lat &&
          p.lng === def.lng &&
          p.radius === def.radius
        return { stop: s, ...p, changed, isDefault }
      }),
    [saved, drafts],
  )

  const dirty = saved.some((s) => {
    const d = drafts[s.id]
    const o = savedDrafts[s.id]
    return (
      d && o && (d.lat !== o.lat || d.lng !== o.lng || d.radius !== o.radius)
    )
  })
  const allValid = parsed.every((p) => p.valid)

  // Warn before leaving with unsaved edits
  useEffect(() => {
    if (!dirty) return
    const onBeforeUnload = (e: BeforeUnloadEvent) => e.preventDefault()
    window.addEventListener('beforeunload', onBeforeUnload)
    return () => window.removeEventListener('beforeunload', onBeforeUnload)
  }, [dirty])

  const mapStops: EditableStop[] = useMemo(
    () =>
      parsed.map((p) =>
        p.valid
          ? {
              id: p.stop.id,
              name: p.stop.name,
              lat: p.lat,
              lng: p.lng,
              radius: p.radius,
            }
          : {
              id: p.stop.id,
              name: p.stop.name,
              lat: p.stop.lat,
              lng: p.stop.lng,
              radius: p.stop.radius,
            },
      ),
    [parsed],
  )

  const setField = (id: string, field: keyof Draft, value: string) =>
    setDrafts((prev) => ({ ...prev, [id]: { ...prev[id], [field]: value } }))

  const select = (id: string, focus = false) => {
    setSelectedId(id)
    if (focus) setFocusKey((k) => k + 1)
  }

  const takeMyPosition = (id: string) => {
    if (!('geolocation' in navigator)) {
      toast.error('Овој уред не поддржува GPS.')
      return
    }
    setLocating(id)
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(null)
        setDrafts((prev) => ({
          ...prev,
          [id]: {
            ...prev[id],
            lat: String(Math.round(pos.coords.latitude * 1e6) / 1e6),
            lng: String(Math.round(pos.coords.longitude * 1e6) / 1e6),
          },
        }))
        select(id, true)
        toast.success(
          `Позицијата е земена (точност ±${Math.round(pos.coords.accuracy)} m). Зачувајте за да важи.`,
        )
      },
      (err) => {
        setLocating(null)
        toast.error(
          err.code === err.PERMISSION_DENIED
            ? 'Дозволете пристап до локацијата во прелистувачот.'
            : 'Не може да се одреди позицијата. Обидете се пак.',
        )
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 },
    )
  }

  const save = async () => {
    if (!allValid) return
    setSaving(true)
    try {
      const res = await saveTourConfig({
        data: {
          password,
          boatId,
          stops: parsed.map((p) => ({
            stopId: p.stop.id,
            lat: p.lat,
            lng: p.lng,
            radius: p.radius,
          })),
        },
      })
      if (!res.ok) return onAuthLost(AUTH_ERRORS[res.error])
      await router.invalidate()
      toast.success('Точките се зачувани. Важат за сите уреди.')
    } catch {
      toast.error(
        'Зачувувањето не успеа. Проверете ја врската и обидете се пак.',
      )
    } finally {
      setSaving(false)
    }
  }

  const reset = async () => {
    setSaving(true)
    try {
      const res = await resetTourConfig({ data: { password, boatId } })
      if (!res.ok) return onAuthLost(AUTH_ERRORS[res.error])
      setResetOpen(false)
      await router.invalidate()
      toast.success('Вратени се почетните точки.')
    } catch {
      toast.error('Враќањето не успеа. Обидете се пак.')
    } finally {
      setSaving(false)
    }
  }

  const addStop = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!boatId || !newName.trim()) return
    setSaving(true)
    try {
      // Placed near the selected stop (or mid-lake); then dragged into place
      const near = parsed.find((p) => p.stop.id === selectedId)?.stop
      const res = await addBoatStop({
        data: {
          password,
          boatId,
          name: newName.trim(),
          lat: near ? Math.round((near.lat - 0.006) * 1e6) / 1e6 : 41.03,
          lng: near ? Math.round((near.lng - 0.006) * 1e6) / 1e6 : 20.77,
          radius: 300,
        },
      })
      if (!res.ok) {
        if (res.error === 'limit')
          return toast.error(
            `Може да имате најмногу ${MAX_EXTRA_STOPS} дополнителни точки.`,
          )
        return onAuthLost(AUTH_ERRORS[res.error])
      }
      setAddOpen(false)
      setNewName('')
      await router.invalidate()
      select(res.stopId, true)
      toast.success(
        'Точката е додадена. Повлечете ја на картата, зачувајте, а приказните напишете ги во „Текстови на точките“.',
      )
    } catch {
      toast.error('Додавањето не успеа. Проверете ја врската и обидете се пак.')
    } finally {
      setSaving(false)
    }
  }

  const removeStop = async () => {
    if (!boatId || !deleteId) return
    setSaving(true)
    try {
      const res = await deleteBoatStop({
        data: { password, boatId, stopId: deleteId },
      })
      if (!res.ok) return onAuthLost(AUTH_ERRORS[res.error])
      setDeleteId(null)
      await router.invalidate()
      setSelectedId(saved[0]?.id ?? null)
      toast.success('Точката е избришана.')
    } catch {
      toast.error('Бришењето не успеа. Обидете се пак.')
    } finally {
      setSaving(false)
    }
  }

  const deleteName = deleteId
    ? saved.find((s) => s.id === deleteId)?.name
    : undefined

  return (
    <div className="pb-28">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-lake-deep">
            Локации и радиуси
          </h2>
          <p className="mt-1 max-w-reading text-sm text-muted-foreground">
            Изберете точка, па повлечете ја на картата за да ја преместите.
            Радиусот го менувате со лизгачот во листата
            {mapProvider === 'google' &&
              ' или со белата рачка на работ на кругот'}
            . Можете и рачно да ги внесете координатите или да ја земете
            моменталната GPS позиција. Приказната се пушта кога бродот ќе влезе
            во кругот.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {boatId && (
            <Button
              size="sm"
              onClick={() => setAddOpen(true)}
              disabled={extraCount >= MAX_EXTRA_STOPS || dirty || saving}
              title={dirty ? 'Прво зачувајте ги промените' : 'Додај нова зона'}
            >
              <Plus className="size-4" /> Нова точка ({extraCount}/
              {MAX_EXTRA_STOPS})
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setResetOpen(true)}
          >
            <RotateCcw className="size-4" /> Почетни вредности
          </Button>
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        <div className="relative h-[55vh] min-h-80 overflow-hidden rounded-2xl border border-lake-deep/15 bg-lake-deep/5 lg:sticky lg:top-4 lg:h-[calc(100vh-8rem)]">
          {mapStatus !== 'error' &&
            (mapProvider === 'google' ? (
              <AdminStopsMap
                stops={mapStops}
                selectedId={selectedId}
                onSelect={(id) => select(id)}
                onChange={(id, next) =>
                  setDrafts((prev) => ({ ...prev, [id]: toDraft(next) }))
                }
                onStatus={(st) => {
                  if (st !== 'error') return setMapStatus(st)
                  setMapStatus('loading')
                  setMapProvider('leaflet')
                }}
                focusKey={focusKey}
              />
            ) : (
              <LeafletAdminMap
                stops={mapStops}
                selectedId={selectedId}
                onSelect={(id) => select(id)}
                onChange={(id, next) =>
                  setDrafts((prev) => ({ ...prev, [id]: toDraft(next) }))
                }
                onStatus={setMapStatus}
                focusKey={focusKey}
              />
            ))}
          {mapStatus === 'loading' && (
            <div
              className="absolute inset-0 grid place-items-center text-sm text-muted-foreground"
              role="status"
            >
              <span className="flex items-center gap-2">
                <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
                Се вчитува картата…
              </span>
            </div>
          )}
          {mapStatus === 'error' && (
            <div className="absolute inset-0 grid place-items-center p-6 text-center text-sm text-muted-foreground">
              <p>
                Картата не може да се вчита. Внесете ги координатите и радиусот
                рачно во листата.
              </p>
            </div>
          )}
        </div>

        <ol className="space-y-3">
          {parsed.map((p, i) => {
            const id = p.stop.id
            const d = drafts[id] ?? toDraft(p.stop)
            const selected = id === selectedId
            return (
              <li
                key={id}
                className={cn(
                  'rounded-2xl border bg-white p-4 shadow-sm transition-colors motion-reduce:transition-none',
                  selected
                    ? 'border-terracotta ring-2 ring-terracotta/30'
                    : 'border-lake-deep/10',
                )}
              >
                <button
                  type="button"
                  onClick={() => select(id, true)}
                  className="flex w-full items-center gap-3 rounded-lg text-left focus-visible:outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
                  aria-pressed={selected}
                >
                  <span
                    className={cn(
                      'grid size-8 shrink-0 place-items-center rounded-full text-sm font-bold',
                      selected
                        ? 'bg-terracotta text-white'
                        : 'bg-lake-deep/10 text-lake-deep',
                    )}
                  >
                    {i + 1}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-semibold text-ink">
                      {p.stop.name}
                    </span>
                    <span className="block text-xs text-muted-foreground">
                      {isExtraStop(id) && (
                        <span className="font-semibold text-terracotta">
                          Дополнителна ·{' '}
                        </span>
                      )}
                      {p.changed
                        ? 'Незачувани промени'
                        : p.isDefault
                          ? 'Почетна вредност'
                          : 'Зачувано'}
                    </span>
                  </span>
                  {p.changed && (
                    <span
                      className="size-2.5 rounded-full bg-terracotta"
                      aria-hidden
                    />
                  )}
                </button>

                <div className="mt-6 grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor={`${id}-lat`}>Ширина (lat)</Label>
                    <Input
                      id={`${id}-lat`}
                      inputMode="decimal"
                      value={d.lat}
                      onFocus={() => select(id)}
                      onChange={(e) =>
                        setField(id, 'lat', e.target.value.replace(',', '.'))
                      }
                      aria-invalid={p.errors.lat}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor={`${id}-lng`}>Должина (lng)</Label>
                    <Input
                      id={`${id}-lng`}
                      inputMode="decimal"
                      value={d.lng}
                      onFocus={() => select(id)}
                      onChange={(e) =>
                        setField(id, 'lng', e.target.value.replace(',', '.'))
                      }
                      aria-invalid={p.errors.lng}
                    />
                  </div>
                </div>

                <div className="mt-3 space-y-1.5">
                  <Label htmlFor={`${id}-radius`}>Радиус (метри)</Label>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min={RADIUS_MIN}
                      max={RADIUS_MAX}
                      step={10}
                      value={p.errors.radius ? p.stop.radius : p.radius}
                      onChange={(e) => {
                        select(id)
                        setField(id, 'radius', e.target.value)
                      }}
                      aria-label={`Радиус за ${p.stop.name}`}
                      className="h-2 flex-1 cursor-pointer accent-terracotta"
                    />
                    <Input
                      id={`${id}-radius`}
                      inputMode="numeric"
                      className="w-24"
                      value={d.radius}
                      onFocus={() => select(id)}
                      onChange={(e) => setField(id, 'radius', e.target.value)}
                      aria-invalid={p.errors.radius}
                    />
                  </div>
                </div>

                {!p.valid && (
                  <p className="mt-2 text-xs text-destructive" role="alert">
                    {p.errors.radius
                      ? `Радиусот мора да биде цел број од ${RADIUS_MIN} до ${RADIUS_MAX} m.`
                      : 'Внесете валидни координати (на пр. 41.1116 и 20.7986).'}
                  </p>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-3"
                  onClick={() => takeMyPosition(id)}
                  disabled={locating !== null}
                >
                  {locating === id ? (
                    <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
                  ) : (
                    <Crosshair className="size-4" />
                  )}
                  Земи ја мојата позиција
                </Button>
                {isExtraStop(id) && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="ml-2 mt-3 text-destructive hover:text-destructive"
                    onClick={() => setDeleteId(id)}
                    disabled={saving}
                  >
                    <Trash2 className="size-4" /> Избриши
                  </Button>
                )}
              </li>
            )
          })}
        </ol>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-cream/95 backdrop-blur">
        <div className="mx-auto flex max-w-content items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <p className="text-sm text-muted-foreground" aria-live="polite">
            {!allValid
              ? 'Поправете ги означените полиња.'
              : dirty
                ? 'Имате незачувани промени.'
                : 'Сите промени се зачувани.'}
          </p>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              onClick={() => setDrafts(savedDrafts)}
              disabled={!dirty || saving}
            >
              <Undo2 className="size-4" />
              <span className="hidden sm:inline">Откажи</span>
            </Button>
            <Button onClick={save} disabled={!dirty || !allValid || saving}>
              {saving ? (
                <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
              ) : (
                <Save className="size-4" />
              )}
              Зачувај
            </Button>
          </div>
        </div>
      </div>

      <Dialog open={resetOpen} onOpenChange={setResetOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Врати ги почетните точки?</DialogTitle>
            <DialogDescription>
              {boatId
                ? 'Позициите и радиусите на овој брод се бришат и повторно важат заедничките вредности. Дополнителните точки на бродот остануваат.'
                : 'Сите зачувани позиции и радиуси се бришат и повторно важат оригиналните вредности на турата, на сите уреди.'}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Откажи</Button>
            </DialogClose>
            <Button variant="destructive" onClick={reset} disabled={saving}>
              {saving && (
                <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
              )}
              Врати
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <form onSubmit={addStop}>
            <DialogHeader>
              <DialogTitle>Нова точка на турата</DialogTitle>
              <DialogDescription>
                Дополнителна зона само за овој брод (најмногу {MAX_EXTRA_STOPS}
                ). Се појавува до избраната точка; потоа повлечете ја на
                вистинското место и зачувајте.
              </DialogDescription>
            </DialogHeader>
            <div className="my-5 space-y-2">
              <Label htmlFor="new-stop-name">Име на точката</Label>
              <Input
                id="new-stop-name"
                value={newName}
                maxLength={120}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="на пр. Плажа Лагадин"
                autoFocus
              />
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button type="button" variant="outline">
                  Откажи
                </Button>
              </DialogClose>
              <Button type="submit" disabled={saving || !newName.trim()}>
                {saving ? (
                  <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
                ) : (
                  <Plus className="size-4" />
                )}
                Додај
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog
        open={deleteId !== null}
        onOpenChange={(o) => !o && setDeleteId(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Избриши ја точката „{deleteName}“?</DialogTitle>
            <DialogDescription>
              Зоната и сите нејзини текстови се бришат од турата на овој брод.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Откажи</Button>
            </DialogClose>
            <Button
              variant="destructive"
              onClick={removeStop}
              disabled={saving}
            >
              {saving && (
                <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
              )}
              Избриши
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
