import { Link } from '@tanstack/react-router'
import { LogoutButton } from '@/components/logout-button'
import { useTourMeta } from '@/lib/stops-context'
import { useUiLang } from '@/lib/ui-lang'
import { cn } from '@/lib/utils'

export function SiteHeader({ overlay = false }: { overlay?: boolean }) {
  const { t } = useUiLang()
  const { boat } = useTourMeta()
  return (
    <header
      className={cn(
        'z-20 w-full',
        overlay
          ? 'absolute inset-x-0 top-0 text-white'
          : 'border-b border-border bg-cream/90 backdrop-blur',
      )}
    >
      <div className="mx-auto flex max-w-content items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <Link
          to={boat ? '/b/$boat' : '/'}
          params={boat ? { boat: boat.id } : undefined}
          className="flex items-center gap-2.5"
        >
          <img src="/icon.svg" alt="" className="size-8 rounded-lg" />
          <span className="leading-tight">
            <span className="block font-display text-xl font-bold tracking-wide sm:text-2xl">
              {t('brand')}
            </span>
            <span
              className={cn(
                'hidden text-[11px] sm:block',
                overlay ? 'text-white/80' : 'text-muted-foreground',
              )}
            >
              {t('tagline')}
            </span>
          </span>
        </Link>
        <LogoutButton light={overlay} />
      </div>
    </header>
  )
}
