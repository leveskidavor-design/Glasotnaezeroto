import { useParams } from '@tanstack/react-router'
import { Loader2, LogOut } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { adminSession } from '@/lib/admin-auth'
import { logoutBoatDevice } from '@/lib/stops.functions'
import { cn } from '@/lib/utils'

/**
 * "Одјави се" for the top of every logged-in page. On a boat's pages it also
 * frees this device's slot, so the boat account can be used on another device.
 */
export function LogoutButton({ light = false }: { light?: boolean }) {
  const params = useParams({ strict: false }) as { boat?: string }
  const boatId = params.boat
  const [open, setOpen] = useState(false)
  const [pending, setPending] = useState(false)

  const logout = async () => {
    setPending(true)
    if (boatId) {
      try {
        await logoutBoatDevice({ data: { boatId } })
      } catch {
        setPending(false)
        toast.error(
          'Одјавувањето не успеа – потребна е интернет врска. Обидете се пак.',
        )
        return
      }
      adminSession(boatId).set(null)
      try {
        localStorage.removeItem('lihnid:last-boat')
      } catch {
        /* storage unavailable */
      }
    }
    adminSession().set(null)
    // Full reload so the tour, voice, music and GPS all stop
    window.location.assign(
      boatId ? `/?boat=${encodeURIComponent(boatId)}` : '/',
    )
  }

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={() => setOpen(true)}
        className={cn(
          light &&
            'border-white/40 bg-white/10 text-white backdrop-blur hover:bg-white/20 hover:text-white',
        )}
      >
        <LogOut className="size-4" /> Одјави се
      </Button>
      <Dialog open={open} onOpenChange={(o) => !pending && setOpen(o)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Одјава од акаунтот</DialogTitle>
            <DialogDescription>
              {boatId
                ? 'Овој уред ќе биде одјавен од бродот и местото за уред ќе се ослободи, па акаунтот може да се најави на друг уред. Турата што тече ќе запре.'
                : 'Ќе бидете одјавени од главниот админ на овој уред.'}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline" disabled={pending}>
                Откажи
              </Button>
            </DialogClose>
            <Button onClick={logout} disabled={pending}>
              {pending ? (
                <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
              ) : (
                <LogOut className="size-4" />
              )}
              Одјави се
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
