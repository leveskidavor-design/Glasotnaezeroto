import {
  Crosshair,
  Expand,
  Loader2,
  Map as MapIcon,
  MapPin,
  Minimize,
} from 'lucide-react'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  GoogleTourMap,
  type GoogleMapHandle,
} from '@/components/google-tour-map'
import { LeafletTourMap } from '@/components/leaflet-tour-map'
import { TourMap } from '@/components/tour-map'
import { Button } from '@/components/ui/button'
import { distanceM, formatDistance } from '@/lib/geo'
import { useStops } from '@/lib/stops-context'
import { useUiLang } from '@/lib/ui-lang'
import type { Position } from '@/lib/use-tour-engine'
import { cn } from '@/lib/utils'

interface Props {
  position: Position | null
  triggered: string[]
  activeStopId?: string
  /** Shown on top of the map in passenger (fullscreen) display */
  headline?: React.ReactNode
}

/**
 * The boat-position display for passengers: Google Maps with the live boat,
 * the story zones, plus the nearest stop and exact coordinates.
 * Can be switched to a fullscreen passenger display (e.g. a tablet on board).
 * Falls back to the OpenStreetMap map when Google Maps is unavailable.
 */
export function PassengerMap({
  position,
  triggered,
  activeStopId,
  headline,
}: Props) {
  const { t } = useUiLang()
  const STOPS = useStops()
  const wrapper = useRef<HTMLDivElement>(null)
  const handle = useRef<GoogleMapHandle>(null)
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading')
  const [follow, setFollow] = useState(true)
  const [full, setFull] = useState(false)

  // Google Maps first; if it can't load (no or invalid key) the keyless
  // interactive map takes over, and the static map is the last resort.
  const [provider, setProvider] = useState<'google' | 'leaflet' | 'static'>(
    'google',
  )
  const useGoogle = provider !== 'static'
  const onMapStatus = useCallback((s: 'loading' | 'ready' | 'error') => {
    if (s !== 'error') return setStatus(s)
    setStatus('loading')
    setProvider((p) => (p === 'google' ? 'leaflet' : 'static'))
  }, [])

  const nearest = useMemo(() => {
    if (!position) return null
    let best: { name: string; d: number } | null = null
    for (const s of STOPS) {
      const d = distanceM(position.lat, position.lng, s.lat, s.lng)
      if (!best || d < best.d) best = { name: s.name, d }
    }
    return best
  }, [position, STOPS])

  const toggleFull = useCallback(async () => {
    const el = wrapper.current
    if (!full) {
      setFull(true)
      try {
        if (el?.requestFullscreen) await el.requestFullscreen()
      } catch {
        /* CSS fallback (e.g. iPhone) */
      }
    } else {
      setFull(false)
      if (document.fullscreenElement)
        await document.exitFullscreen().catch(() => {})
    }
  }, [full])

  useEffect(() => {
    const onChange = () => {
      if (!document.fullscreenElement) setFull(false)
    }
    document.addEventListener('fullscreenchange', onChange)
    return () => document.removeEventListener('fullscreenchange', onChange)
  }, [])

  useEffect(() => {
    if (!full) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setFull(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [full])

  return (
    <section
      ref={wrapper}
      aria-label={t('mapTitle')}
      className={cn(
        'flex flex-col overflow-hidden bg-card',
        full
          ? 'fixed inset-0 z-50 h-[100svh] w-screen'
          : 'rounded-2xl border border-lake-deep/15 shadow-sm',
      )}
    >
      <div
        className={cn(
          'relative bg-[#aad3df]',
          useGoogle
            ? full
              ? 'flex-1'
              : 'h-[60svh] min-h-80 lg:h-[calc(100svh-12rem)]'
            : full && 'flex-1',
        )}
      >
        {useGoogle ? (
          <>
            {provider === 'google' ? (
              <GoogleTourMap
                position={position}
                triggered={triggered}
                activeStopId={activeStopId}
                follow={follow}
                onFollowChange={setFollow}
                onStatus={onMapStatus}
                handleRef={handle}
                boatLabel={t('boatHere')}
              />
            ) : (
              <LeafletTourMap
                position={position}
                triggered={triggered}
                activeStopId={activeStopId}
                follow={follow}
                onFollowChange={setFollow}
                onStatus={onMapStatus}
                handleRef={handle}
                boatLabel={t('boatHere')}
              />
            )}
            {status === 'loading' && (
              <div className="absolute inset-0 grid place-items-center bg-lake-light/80 text-sm text-lake-deep">
                <span className="flex items-center gap-2">
                  <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />{' '}
                  {t('mapLoading')}
                </span>
              </div>
            )}
          </>
        ) : (
          <div className={cn(full && 'grid h-full place-items-center')}>
            <TourMap
              position={position}
              triggered={triggered}
              activeStopId={activeStopId}
            />
          </div>
        )}

        {full && headline && (
          <div className="pointer-events-none absolute inset-x-3 top-3 sm:inset-x-auto sm:left-3 sm:max-w-md">
            <div className="rounded-2xl bg-lake-deep/90 p-4 text-white shadow-lg backdrop-blur">
              {headline}
            </div>
          </div>
        )}

        <div
          className={cn(
            'absolute right-3 flex flex-col gap-2',
            full ? 'bottom-6' : 'bottom-3',
          )}
        >
          {useGoogle && status === 'ready' && (
            <>
              <Button
                size="icon"
                variant="secondary"
                className={cn(
                  'rounded-full shadow-md',
                  follow && 'bg-lake-deep text-white hover:bg-lake-deep/90',
                )}
                onClick={() => handle.current?.follow()}
                aria-label={t('mapFollow')}
                aria-pressed={follow}
                title={t('mapFollow')}
              >
                <Crosshair className="size-5" />
              </Button>
              <Button
                size="icon"
                variant="secondary"
                className="rounded-full shadow-md"
                onClick={() => handle.current?.overview()}
                aria-label={t('mapOverview')}
                title={t('mapOverview')}
              >
                <MapIcon className="size-5" />
              </Button>
            </>
          )}
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full shadow-md"
            onClick={toggleFull}
            aria-label={full ? t('mapExitFullscreen') : t('mapFullscreen')}
            title={full ? t('mapExitFullscreen') : t('mapFullscreen')}
          >
            {full ? (
              <Minimize className="size-5" />
            ) : (
              <Expand className="size-5" />
            )}
          </Button>
        </div>
      </div>

      {/* Exact position read-out */}
      <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1 border-t border-border bg-card px-4 py-3 text-sm">
        {position && nearest ? (
          <>
            <span className="flex items-center gap-1.5 font-semibold text-lake-deep">
              <MapPin className="size-4 text-terracotta" />
              {t('nearestStop')}: {nearest.name} · {formatDistance(nearest.d)}
            </span>
            <span className="font-mono text-xs text-muted-foreground">
              {t('coords')}: {position.lat.toFixed(5)},{' '}
              {position.lng.toFixed(5)}
            </span>
          </>
        ) : (
          <span className="text-muted-foreground">{t('mapNoPosition')}</span>
        )}
        {provider === 'static' && (
          <span className="w-full text-xs text-terracotta">
            {t('mapError')}
          </span>
        )}
      </div>
    </section>
  )
}
