import { Loader2, LogOut, RotateCcw, Smartphone } from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { AUTH_ERRORS } from '@/lib/admin-auth'
import {
  listOwnBoatDevices,
  removeBoatDevices,
  type BoatDevice,
} from '@/lib/stops.functions'
import { cn } from '@/lib/utils'

type Device = BoatDevice & { current: boolean }

const dateTime = (iso: string) =>
  new Date(iso).toLocaleString('mk-MK', {
    day: 'numeric',
    month: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })

/**
 * A boat's own admin: the devices logged in to the boat account. Any of them
 * can be logged out here (e.g. a lost phone, or when it's unclear which device
 * holds the slot), so another device can log in.
 */
export function OwnDevices({
  boatId,
  password,
  onAuthLost,
}: {
  boatId: string
  password: string
  onAuthLost: (message: string) => void
}) {
  const [data, setData] = useState<{
    max: number
    devices: Device[]
  } | null>(null)
  const [loadError, setLoadError] = useState(false)
  const [pending, setPending] = useState<string | null>(null)
  // Latest callback without reloading the list on every parent render
  const authLost = useRef(onAuthLost)
  useEffect(() => {
    authLost.current = onAuthLost
  })

  const load = useCallback(async () => {
    try {
      const res = await listOwnBoatDevices({ data: { password, boatId } })
      if (!res.ok) return authLost.current(AUTH_ERRORS[res.error])
      setLoadError(false)
      setData({ max: res.maxDevices, devices: res.devices })
    } catch {
      setLoadError(true)
    }
  }, [password, boatId])

  useEffect(() => {
    let active = true
    listOwnBoatDevices({ data: { password, boatId } })
      .then((res) => {
        if (!active) return
        if (!res.ok) return authLost.current(AUTH_ERRORS[res.error])
        setData({ max: res.maxDevices, devices: res.devices })
      })
      .catch(() => active && setLoadError(true))
    return () => {
      active = false
    }
  }, [password, boatId])

  const remove = async (device: Device) => {
    setPending(device.id)
    try {
      const res = await removeBoatDevices({
        data: { password, boatId, deviceId: device.id },
      })
      if (!res.ok) return onAuthLost(AUTH_ERRORS[res.error])
      toast.success(
        device.current
          ? 'Овој уред е одјавен од турата.'
          : 'Уредот е одјавен. Местото е слободно за друг уред.',
      )
      await load()
    } catch {
      toast.error('Одјавувањето не успеа. Обидете се пак.')
    } finally {
      setPending(null)
    }
  }

  return (
    <div className="max-w-2xl rounded-3xl border border-lake-deep/10 bg-white p-5 shadow-sm sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl font-bold text-lake-deep">
            Најавени уреди
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {data
              ? `Искористени ${data.devices.length} од ${data.max} дозволени. `
              : ''}
            Ако не знаете кој уред е најавен, одјавете го тука – неговото место
            се ослободува и акаунтот може да се најави на друг уред.
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => void load()}
          aria-label="Освежи ја листата"
        >
          <RotateCcw className="size-4" />
        </Button>
      </div>

      <div className="mt-5">
        {loadError ? (
          <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
            Листата не може да се вчита.{' '}
            <button
              type="button"
              className="font-semibold underline"
              onClick={() => void load()}
            >
              Обидете се пак
            </button>
          </div>
        ) : !data ? (
          <ul className="space-y-2" aria-busy="true">
            {[0, 1].map((i) => (
              <li
                key={i}
                className="h-16 animate-pulse rounded-xl bg-lake-deep/5 motion-reduce:animate-none"
              />
            ))}
          </ul>
        ) : data.devices.length === 0 ? (
          <p className="rounded-xl border border-dashed border-lake-deep/25 p-6 text-center text-sm text-muted-foreground">
            Нема најавен уред. Секој уред што ќе се најави со кодот и лозинката
            на бродот ќе се појави тука.
          </p>
        ) : (
          <ul className="space-y-2">
            {data.devices.map((v) => (
              <li
                key={v.id}
                className={cn(
                  'flex items-center gap-3 rounded-xl border p-3',
                  v.current
                    ? 'border-lake/40 bg-lake/5'
                    : 'border-lake-deep/10',
                )}
              >
                <Smartphone className="size-4 shrink-0 text-lake" />
                <div className="min-w-0 flex-1 text-sm">
                  <p className="flex flex-wrap items-center gap-2 font-medium text-ink">
                    <span className="truncate">{v.label}</span>
                    {v.current && <Badge variant="secondary">Овој уред</Badge>}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Најавен {dateTime(v.createdAt)} · последно користен{' '}
                    {dateTime(v.lastSeenAt)}
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => remove(v)}
                  disabled={pending !== null}
                  aria-label={`Одјави го уредот ${v.label}`}
                >
                  {pending === v.id ? (
                    <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
                  ) : (
                    <LogOut className="size-4" />
                  )}
                  Одјави
                </Button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
