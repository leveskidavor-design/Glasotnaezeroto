import { useMemo } from 'react'
import type { Stop } from '@/data/tour'
import { useStops } from '@/lib/stops-context'
import type { Position } from '@/lib/use-tour-engine'

const Z = 12
const WORLD = 256 * 2 ** Z

function project(lat: number, lng: number) {
  const s = Math.sin((lat * Math.PI) / 180)
  return {
    x: ((lng + 180) / 360) * WORLD,
    y: (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * WORLD,
  }
}

const metresPerPx = (lat: number) =>
  (156543.03392 * Math.cos((lat * Math.PI) / 180)) / 2 ** Z

// Frame around every stop
function computeFrame(stops: Stop[]) {
  const pts = [...stops.map((s) => [s.lat, s.lng] as [number, number])].map(
    ([a, b]) => project(a, b),
  )
  const pad = 40
  let minX = Math.min(...pts.map((p) => p.x)) - pad
  let maxX = Math.max(...pts.map((p) => p.x)) + pad
  const minY = Math.min(...pts.map((p) => p.y)) - pad
  const maxY = Math.max(...pts.map((p) => p.y)) + pad
  const minAspect = 0.62
  const h = maxY - minY
  if ((maxX - minX) / h < minAspect) {
    const extra = (minAspect * h - (maxX - minX)) / 2
    minX -= extra
    maxX += extra
  }
  return { minX, minY, w: maxX - minX, h }
}

function computeTiles(frame: ReturnType<typeof computeFrame>) {
  const list: { x: number; y: number }[] = []
  for (
    let x = Math.floor(frame.minX / 256);
    x <= Math.floor((frame.minX + frame.w) / 256);
    x++
  )
    for (
      let y = Math.floor(frame.minY / 256);
      y <= Math.floor((frame.minY + frame.h) / 256);
      y++
    )
      list.push({ x, y })
  return list
}

interface Props {
  position: Position | null
  triggered: string[]
  activeStopId?: string
  onSelectStop?: (id: string) => void
}

export function TourMap({
  position,
  triggered,
  activeStopId,
  onSelectStop,
}: Props) {
  const STOPS = useStops()
  const frame = useMemo(() => computeFrame(STOPS), [STOPS])
  const tiles = useMemo(() => computeTiles(frame), [frame])
  const boat = useMemo(
    () => (position ? project(position.lat, position.lng) : null),
    [position],
  )
  const accuracyR =
    position?.accuracy && position.accuracy > 30
      ? position.accuracy / metresPerPx(position.lat)
      : 0

  return (
    <div className="relative overflow-hidden rounded-2xl border border-lake-deep/15 bg-[#aad3df] shadow-sm">
      <svg
        viewBox={`${frame.minX} ${frame.minY} ${frame.w} ${frame.h}`}
        className="block h-full w-full"
        role="img"
        aria-label="Карта на рутата"
      >
        <g style={{ filter: 'saturate(0.55) sepia(0.12) brightness(1.03)' }}>
          {tiles.map((t) => (
            <image
              key={`${t.x}-${t.y}`}
              href={`https://tile.openstreetmap.org/${Z}/${t.x}/${t.y}.png`}
              x={t.x * 256}
              y={t.y * 256}
              width={256}
              height={256}
            />
          ))}
        </g>

        {STOPS.map((s, i) => {
          const p = project(s.lat, s.lng)
          const r = s.radius / metresPerPx(s.lat)
          const heard = triggered.includes(s.id)
          const active = s.id === activeStopId
          return (
            <g
              key={s.id}
              onClick={() => onSelectStop?.(s.id)}
              className={onSelectStop ? 'cursor-pointer' : undefined}
            >
              <title>{s.name}</title>
              <circle
                cx={p.x}
                cy={p.y}
                r={Math.max(r, 7)}
                fill={active ? 'var(--terracotta)' : 'var(--lake-deep)'}
                fillOpacity={active ? 0.28 : 0.14}
                stroke={active ? 'var(--terracotta)' : 'var(--lake-deep)'}
                strokeOpacity={0.6}
                strokeWidth={1}
                className={active ? 'zone-pulse' : undefined}
              />
              <circle
                cx={p.x}
                cy={p.y}
                r={8}
                fill={heard ? 'var(--lake-deep)' : '#fffaf1'}
                stroke="var(--lake-deep)"
                strokeWidth={1.6}
              />
              <text
                x={p.x}
                y={p.y + 3.4}
                textAnchor="middle"
                fontSize={9.5}
                fontWeight={700}
                fill={heard ? '#fffaf1' : 'var(--lake-deep)'}
                style={{ fontFamily: 'var(--font-body)' }}
              >
                {i + 1}
              </text>
            </g>
          )
        })}

        {boat && (
          <g transform={`translate(${boat.x} ${boat.y})`}>
            {accuracyR > 0 && (
              <circle
                r={accuracyR}
                fill="#2563eb"
                fillOpacity={0.1}
                stroke="#2563eb"
                strokeOpacity={0.3}
              />
            )}
            <circle
              r={13}
              fill="var(--terracotta)"
              opacity={0.25}
              className="boat-ping"
            />
            <circle
              r={7}
              fill="var(--terracotta)"
              stroke="#fff"
              strokeWidth={2.5}
            />
          </g>
        )}
      </svg>
      <div className="absolute bottom-1 right-1.5 rounded bg-white/80 px-1.5 py-0.5 text-[10px] text-slate-600">
        ©{' '}
        <a
          href="https://www.openstreetmap.org/copyright"
          target="_blank"
          rel="noreferrer"
          className="underline"
        >
          OpenStreetMap
        </a>
      </div>
    </div>
  )
}
