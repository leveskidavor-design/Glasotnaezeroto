import { useEffect, useImperativeHandle, useRef, useState } from 'react'
import { useStops } from '@/lib/stops-context'
import { bearingDeg, distanceM } from '@/lib/geo'
import { loadGoogleMaps, onGoogleAuthFailure } from '@/lib/google-maps'
import type { Position } from '@/lib/use-tour-engine'

const LAKE_DEEP = '#0b4f5c'
const TERRACOTTA = '#c1553b'

export interface GoogleMapHandle {
  /** Re-centre on the boat and keep following it */
  follow: () => void
  /** Show all stops */
  overview: () => void
}

interface Props {
  position: Position | null
  triggered: string[]
  activeStopId?: string
  follow: boolean
  onFollowChange: (follow: boolean) => void
  onStatus: (status: 'loading' | 'ready' | 'error') => void
  handleRef: React.Ref<GoogleMapHandle>
  boatLabel: string
}

export type HtmlOverlay = google.maps.OverlayView & {
  setPosition: (p: google.maps.LatLngLiteral) => void
  el: HTMLDivElement
}

/** An absolutely positioned HTML element pinned to a lat/lng. */
export function makeOverlay(
  g: typeof google.maps,
  pos: google.maps.LatLngLiteral,
  el: HTMLDivElement,
  zIndex: number,
) {
  class Overlay extends g.OverlayView {
    el = el
    pos = pos
    onAdd() {
      this.el.style.position = 'absolute'
      this.el.style.zIndex = String(zIndex)
      this.getPanes()?.overlayMouseTarget.appendChild(this.el)
    }
    draw() {
      const p = this.getProjection()?.fromLatLngToDivPixel(
        new g.LatLng(this.pos),
      )
      if (!p) return
      this.el.style.left = `${p.x}px`
      this.el.style.top = `${p.y}px`
    }
    onRemove() {
      this.el.remove()
    }
    setPosition(next: google.maps.LatLngLiteral) {
      this.pos = next
      this.draw()
    }
  }
  return new Overlay() as HtmlOverlay
}

function boatElement(label: string) {
  const el = document.createElement('div')
  el.className = 'gm-boat'
  el.setAttribute('role', 'img')
  el.setAttribute('aria-label', label)
  el.innerHTML = `
    <span class="gm-boat-ping"></span>
    <span class="gm-boat-arrow">
      <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true">
        <path d="M12 2 L19 20 L12 16 L5 20 Z" fill="#fff"/>
      </svg>
    </span>
    <span class="gm-boat-label">${label}</span>`
  return el
}

export function stopElement(index: number, title: string) {
  const el = document.createElement('div')
  el.className = 'gm-stop'
  el.title = title
  el.textContent = String(index + 1)
  return el
}

export function GoogleTourMap({
  position,
  triggered,
  activeStopId,
  follow,
  onFollowChange,
  onStatus,
  handleRef,
  boatLabel,
}: Props) {
  const STOPS = useStops()
  const stopsRef = useRef(STOPS)
  const container = useRef<HTMLDivElement>(null)
  const map = useRef<google.maps.Map | null>(null)
  const boat = useRef<HtmlOverlay | null>(null)
  const accuracy = useRef<google.maps.Circle | null>(null)
  const zones = useRef<
    Map<string, { circle: google.maps.Circle; marker: HtmlOverlay }>
  >(new Map())
  const lastPos = useRef<Position | null>(null)
  const heading = useRef(160)
  const followRef = useRef(follow)
  const routeBounds = useRef<google.maps.LatLngBounds | null>(null)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    followRef.current = follow
  }, [follow])

  useImperativeHandle(
    handleRef,
    () => ({
      follow: () => {
        onFollowChange(true)
        const m = map.current
        const p = lastPos.current
        if (m && p) {
          if ((m.getZoom() ?? 0) < 14) m.setZoom(15)
          m.panTo({ lat: p.lat, lng: p.lng })
        }
      },
      overview: () => {
        onFollowChange(false)
        if (map.current && routeBounds.current)
          map.current.fitBounds(routeBounds.current, 32)
      },
    }),
    [onFollowChange],
  )

  // Create the map once
  useEffect(() => {
    let cancelled = false
    const zoneMap = zones.current
    onStatus('loading')
    const offAuth = onGoogleAuthFailure(() => onStatus('error'))

    loadGoogleMaps()
      .then((g) => {
        if (cancelled || !container.current) return
        const bounds = new g.LatLngBounds()
        stopsRef.current.forEach((s) =>
          bounds.extend({ lat: s.lat, lng: s.lng }),
        )

        const m = new g.Map(container.current, {
          center: bounds.getCenter(),
          zoom: 11,
          mapTypeId: 'hybrid',
          mapTypeControl: true,
          mapTypeControlOptions: { mapTypeIds: ['roadmap', 'hybrid'] },
          streetViewControl: false,
          fullscreenControl: false,
          rotateControl: false,
          clickableIcons: false,
          gestureHandling: 'greedy',
        })
        m.fitBounds(bounds, 32)
        map.current = m
        routeBounds.current = bounds

        // Stops
        stopsRef.current.forEach((s, i) => {
          const circle = new g.Circle({
            map: m,
            center: { lat: s.lat, lng: s.lng },
            radius: s.radius,
            fillColor: LAKE_DEEP,
            fillOpacity: 0.15,
            strokeColor: LAKE_DEEP,
            strokeOpacity: 0.7,
            strokeWeight: 1.5,
            clickable: false,
          })
          const marker = makeOverlay(
            g,
            { lat: s.lat, lng: s.lng },
            stopElement(i, s.name),
            10,
          )
          marker.setMap(m)
          zones.current.set(s.id, { circle, marker })
        })

        // Boat
        accuracy.current = new g.Circle({
          map: m,
          radius: 0,
          center: bounds.getCenter(),
          visible: false,
          fillColor: '#2563eb',
          fillOpacity: 0.1,
          strokeColor: '#2563eb',
          strokeOpacity: 0.35,
          strokeWeight: 1,
          clickable: false,
        })
        const b = makeOverlay(
          g,
          bounds.getCenter().toJSON(),
          boatElement(boatLabel),
          20,
        )
        b.el.style.display = 'none'
        b.setMap(m)
        boat.current = b

        m.addListener('dragstart', () => onFollowChange(false))

        setReady(true)
        onStatus('ready')
      })
      .catch(() => {
        if (!cancelled) onStatus('error')
      })

    return () => {
      cancelled = true
      offAuth()
      zoneMap.forEach(({ circle, marker }) => {
        circle.setMap(null)
        marker.setMap(null)
      })
      zoneMap.clear()
      boat.current?.setMap(null)
      accuracy.current?.setMap(null)
      map.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- create the map once
  }, [])

  // Move the boat
  useEffect(() => {
    const m = map.current
    const b = boat.current
    if (!ready || !m || !b) return
    if (!position) {
      b.el.style.display = 'none'
      accuracy.current?.setVisible(false)
      return
    }
    const prev = lastPos.current
    if (prev && distanceM(prev.lat, prev.lng, position.lat, position.lng) > 3) {
      heading.current = bearingDeg(
        prev.lat,
        prev.lng,
        position.lat,
        position.lng,
      )
    }
    const first = !prev
    lastPos.current = position

    const ll = { lat: position.lat, lng: position.lng }
    b.el.style.display = ''
    b.setPosition(ll)
    const arrow = b.el.querySelector<HTMLElement>('.gm-boat-arrow')
    if (arrow) arrow.style.transform = `rotate(${heading.current}deg)`

    const acc = accuracy.current
    if (acc) {
      const show = position.accuracy !== undefined && position.accuracy > 25
      acc.setVisible(show)
      if (show) {
        acc.setCenter(ll)
        acc.setRadius(position.accuracy ?? 0)
      }
    }

    if (followRef.current) {
      if (first) m.setZoom(14)
      m.panTo(ll)
    }
  }, [position, ready])

  // Keep zones in sync with edited stop positions
  useEffect(() => {
    stopsRef.current = STOPS
    if (!ready) return
    STOPS.forEach((s) => {
      const z = zones.current.get(s.id)
      if (!z) return
      z.circle.setCenter({ lat: s.lat, lng: s.lng })
      z.circle.setRadius(s.radius)
      z.marker.setPosition({ lat: s.lat, lng: s.lng })
    })
    if (window.google?.maps) {
      const bounds = new google.maps.LatLngBounds()
      STOPS.forEach((s) => bounds.extend({ lat: s.lat, lng: s.lng }))
      routeBounds.current = bounds
    }
  }, [STOPS, ready])

  // Re-centre when follow is switched back on
  useEffect(() => {
    const m = map.current
    const p = lastPos.current
    if (ready && follow && m && p) m.panTo({ lat: p.lat, lng: p.lng })
  }, [follow, ready])

  // Zone colours
  useEffect(() => {
    if (!ready) return
    zones.current.forEach(({ circle, marker }, id) => {
      const active = id === activeStopId
      const heard = triggered.includes(id)
      circle.setOptions({
        fillColor: active ? TERRACOTTA : LAKE_DEEP,
        strokeColor: active ? TERRACOTTA : LAKE_DEEP,
        fillOpacity: active ? 0.3 : 0.15,
      })
      marker.el.dataset.state = active ? 'active' : heard ? 'heard' : 'pending'
    })
  }, [triggered, activeStopId, ready])

  return <div ref={container} className="absolute inset-0" />
}
