import { useEffect, useRef, useState } from 'react'
import type * as L from 'leaflet'
import type { EditableStop } from '@/components/admin-stops-map'
import { addBaseLayers, stopIcon } from '@/components/leaflet-tour-map'

const LAKE_DEEP = '#0b4f5c'
const TERRACOTTA = '#c1553b'

interface Props {
  stops: EditableStop[]
  selectedId: string | null
  onSelect: (id: string) => void
  onChange: (
    id: string,
    next: { lat: number; lng: number; radius: number },
  ) => void
  onStatus: (status: 'loading' | 'ready' | 'error') => void
  /** Increment to pan to the selected stop */
  focusKey: number
}

const round6 = (n: number) => Math.round(n * 1e6) / 1e6

/**
 * Keyless admin map, used when Google Maps is unavailable. Drag a stop's
 * numbered marker to move it; the radius is set with the slider in the list.
 */
export function LeafletAdminMap({
  stops,
  selectedId,
  onSelect,
  onChange,
  onStatus,
  focusKey,
}: Props) {
  const container = useRef<HTMLDivElement>(null)
  const lib = useRef<typeof L | null>(null)
  const map = useRef<L.Map | null>(null)
  const zones = useRef(
    new Map<string, { circle: L.Circle; marker: L.Marker; index: number }>(),
  )
  const initial = useRef(stops)
  const handlers = useRef({ onSelect, onChange })
  useEffect(() => {
    handlers.current = { onSelect, onChange }
  })
  const [ready, setReady] = useState(false)

  useEffect(() => {
    let cancelled = false
    const zoneMap = zones.current
    onStatus('loading')
    import('leaflet')
      .then((mod) => {
        const Leaf = (mod.default ?? mod) as typeof L
        if (cancelled || !container.current) return
        lib.current = Leaf
        const m = Leaf.map(container.current)
        map.current = m
        addBaseLayers(Leaf, m)
        m.fitBounds(
          Leaf.latLngBounds(initial.current.map((s) => [s.lat, s.lng])),
          { padding: [32, 32] },
        )
        initial.current.forEach((s, i) => {
          const circle = Leaf.circle([s.lat, s.lng], {
            radius: s.radius,
            color: LAKE_DEEP,
            weight: 2,
            fillColor: LAKE_DEEP,
            fillOpacity: 0.18,
          }).addTo(m)
          circle.on('click', () => handlers.current.onSelect(s.id))
          const marker = Leaf.marker([s.lat, s.lng], {
            icon: stopIcon(Leaf, i, 'pending'),
            title: s.name,
            draggable: false,
            autoPan: true,
          }).addTo(m)
          marker.on('click', () => handlers.current.onSelect(s.id))
          marker.on('drag', () => circle.setLatLng(marker.getLatLng()))
          marker.on('dragend', () => {
            const ll = marker.getLatLng()
            handlers.current.onChange(s.id, {
              lat: round6(ll.lat),
              lng: round6(ll.lng),
              radius: Math.round(circle.getRadius()),
            })
          })
          zoneMap.set(s.id, { circle, marker, index: i })
        })
        setReady(true)
        onStatus('ready')
      })
      .catch(() => {
        if (!cancelled) onStatus('error')
      })
    return () => {
      cancelled = true
      zoneMap.clear()
      map.current?.remove()
      map.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- create the map once
  }, [])

  // Reflect typed values and the selection on the map
  useEffect(() => {
    const Leaf = lib.current
    if (!ready || !Leaf) return
    for (const s of stops) {
      const z = zones.current.get(s.id)
      if (!z) continue
      const selected = s.id === selectedId
      const cur = z.marker.getLatLng()
      if (
        Math.abs(cur.lat - s.lat) > 1e-6 ||
        Math.abs(cur.lng - s.lng) > 1e-6
      ) {
        z.marker.setLatLng([s.lat, s.lng])
        z.circle.setLatLng([s.lat, s.lng])
      }
      if (Math.abs(z.circle.getRadius() - s.radius) >= 1)
        z.circle.setRadius(s.radius)
      z.circle.setStyle({
        color: selected ? TERRACOTTA : LAKE_DEEP,
        fillColor: selected ? TERRACOTTA : LAKE_DEEP,
        fillOpacity: selected ? 0.28 : 0.18,
      })
      z.marker.setIcon(stopIcon(Leaf, z.index, selected ? 'active' : 'pending'))
      z.marker.setZIndexOffset(selected ? 1000 : 0)
      if (selected) z.marker.dragging?.enable()
      else z.marker.dragging?.disable()
    }
  }, [stops, selectedId, ready])

  // Pan to the selected stop on request
  useEffect(() => {
    if (!ready || !focusKey || !selectedId) return
    const s = stops.find((x) => x.id === selectedId)
    const m = map.current
    if (!s || !m) return
    m.setView([s.lat, s.lng], Math.max(m.getZoom(), 14))
    // eslint-disable-next-line react-hooks/exhaustive-deps -- only when focus is requested
  }, [focusKey, ready])

  return <div ref={container} className="absolute inset-0 z-0" />
}
