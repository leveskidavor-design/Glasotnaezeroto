import { Link } from '@tanstack/react-router'
import {
  Check,
  Copy,
  ExternalLink,
  KeyRound,
  Loader2,
  Plus,
  LogOut,
  Settings2,
  Ship,
  Smartphone,
  Trash2,
} from 'lucide-react'
import { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Skeleton } from '@/components/ui/skeleton'
import { AUTH_ERRORS } from '@/lib/admin-auth'
import {
  BOAT_ID_RE,
  type BoatListItem,
  createBoat,
  deleteBoat,
  DEVICES_CAP,
  listBoats,
  removeBoatDevices,
  updateBoat,
} from '@/lib/stops.functions'

type Boat = BoatListItem

const parseDevices = (v: string) => {
  const n = Number(v)
  return Number.isInteger(n) && n >= 1 && n <= DEVICES_CAP ? n : null
}

const dateTime = (iso: string) =>
  new Date(iso).toLocaleString('mk-MK', {
    day: 'numeric',
    month: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })

/** Number input for a boat's device limit, with its hint. */
function MaxDevicesField({
  id,
  value,
  onChange,
}: {
  id: string
  value: string
  onChange: (v: string) => void
}) {
  const invalid = parseDevices(value) === null
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>Број на уреди</Label>
      <Input
        id={id}
        type="number"
        inputMode="numeric"
        min={1}
        max={DEVICES_CAP}
        step={1}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        aria-invalid={invalid}
        aria-describedby={`${id}-hint`}
        className="w-28"
      />
      <p
        id={`${id}-hint`}
        className={
          invalid ? 'text-xs text-destructive' : 'text-xs text-muted-foreground'
        }
      >
        {invalid
          ? `Цел број од 1 до ${DEVICES_CAP}.`
          : 'На колку телефони/таблети може истовремено да се најави овој акаунт. Секој нов уред над бројот се одбива.'}
      </p>
    </div>
  )
}

const CYR: Record<string, string> = {
  а: 'a',
  б: 'b',
  в: 'v',
  г: 'g',
  д: 'd',
  ѓ: 'gj',
  е: 'e',
  ж: 'zh',
  з: 'z',
  ѕ: 'dz',
  и: 'i',
  ј: 'j',
  к: 'k',
  л: 'l',
  љ: 'lj',
  м: 'm',
  н: 'n',
  њ: 'nj',
  о: 'o',
  п: 'p',
  р: 'r',
  с: 's',
  т: 't',
  ќ: 'kj',
  у: 'u',
  ф: 'f',
  х: 'h',
  ц: 'c',
  ч: 'ch',
  џ: 'dzh',
  ш: 'sh',
  ђ: 'dj',
  ћ: 'c',
  й: 'j',
  ы: 'y',
  э: 'e',
  ю: 'ju',
  я: 'ja',
  щ: 'sht',
  ъ: 'a',
  ь: '',
}

/** Boat name → URL code, e.g. "Брод Марија" → "brod-marija" */
function slugify(name: string) {
  return name
    .toLowerCase()
    .split('')
    .map((c) => CYR[c] ?? c)
    .join('')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40)
    .replace(/-+$/g, '')
}

const tourUrl = (id: string) =>
  typeof window === 'undefined'
    ? `/b/${id}`
    : `${window.location.origin}/b/${id}`

/** The boat's tour link, with a copy button. */
export function TourLink({ boatId }: { boatId: string }) {
  const [copied, setCopied] = useState(false)
  const url = tourUrl(boatId)
  return (
    <span className="inline-flex flex-wrap items-center gap-1.5">
      <a
        href={`/b/${boatId}`}
        target="_blank"
        rel="noreferrer"
        className="break-all font-mono text-xs font-semibold text-lake underline-offset-4 hover:underline"
      >
        {url}
      </a>
      <button
        type="button"
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(url)
            setCopied(true)
            setTimeout(() => setCopied(false), 1500)
          } catch {
            toast.error('Копирањето не успеа.')
          }
        }}
        className="inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-xs font-medium text-lake-deep hover:bg-lake-deep/5 focus-visible:outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
        aria-label="Копирај го линкот"
      >
        {copied ? (
          <Check className="size-3.5" />
        ) : (
          <Copy className="size-3.5" />
        )}
        {copied ? 'Копирано' : 'Копирај'}
      </button>
    </span>
  )
}

export function BoatsManager({
  password,
  onAuthLost,
}: {
  password: string
  onAuthLost: (message: string) => void
}) {
  const [boats, setBoats] = useState<Boat[] | null>(null)
  const [error, setError] = useState(false)
  const [editing, setEditing] = useState<Boat | null>(null)
  const [deleting, setDeleting] = useState<Boat | null>(null)
  const [devicesOf, setDevicesOf] = useState<string | null>(null)

  const load = useCallback(async () => {
    setError(false)
    try {
      const res = await listBoats({ data: { password } })
      if (!res.ok) return onAuthLost(AUTH_ERRORS[res.error])
      setBoats(res.boats)
    } catch {
      setError(true)
    }
  }, [password, onAuthLost])

  useEffect(() => {
    void load()
  }, [load])

  return (
    <div className="grid gap-6 pb-10 lg:grid-cols-[minmax(0,1fr)_22rem]">
      <section aria-labelledby="boats-title">
        <h2
          id="boats-title"
          className="font-display text-2xl font-bold text-lake-deep"
        >
          Бродови
        </h2>
        <p className="mt-1 max-w-reading text-sm text-muted-foreground">
          Секој брод има свој линк за турата и своја лозинка. Со неа екипажот ги
          менува точките, текстовите и натписите само за својот брод. Најавата е
          на почетната страница.
        </p>

        {error ? (
          <div className="mt-5 rounded-2xl border border-destructive/30 bg-white p-4 text-sm">
            <p className="text-destructive">
              Бродовите не можат да се вчитаат.
            </p>
            <Button variant="outline" size="sm" className="mt-3" onClick={load}>
              Обиди се пак
            </Button>
          </div>
        ) : boats === null ? (
          <div className="mt-5 space-y-3" role="status" aria-label="Се вчитува">
            {[0, 1].map((i) => (
              <Skeleton key={i} className="h-28 rounded-2xl" />
            ))}
          </div>
        ) : boats.length === 0 ? (
          <div className="mt-5 rounded-2xl border border-dashed border-lake-deep/25 bg-white/60 p-8 text-center">
            <Ship className="mx-auto size-8 text-lake" />
            <p className="mt-2 font-semibold text-ink">Сè уште нема бродови</p>
            <p className="text-sm text-muted-foreground">
              Додадете го првиот брод со формуларот.
            </p>
          </div>
        ) : (
          <ul className="mt-5 space-y-3">
            {boats.map((b) => (
              <li
                key={b.id}
                className="rounded-2xl border border-lake-deep/10 bg-white p-4 shadow-sm"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="flex items-center gap-2 font-semibold text-ink">
                      <Ship className="size-4 text-terracotta" /> {b.name}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Код: <span className="font-mono">{b.id}</span>
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button asChild variant="outline" size="sm">
                      <Link to="/b/$boat/admin" params={{ boat: b.id }}>
                        <Settings2 className="size-4" /> Уреди
                      </Link>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditing(b)}
                    >
                      <KeyRound className="size-4" /> Име / лозинка / уреди
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setDeleting(b)}
                      aria-label={`Избриши ${b.name}`}
                    >
                      <Trash2 className="size-4 text-destructive" />
                    </Button>
                  </div>
                </div>
                <p className="mt-3 flex flex-wrap items-center gap-1.5 text-sm">
                  <ExternalLink className="size-3.5 text-muted-foreground" />
                  Тура: <TourLink boatId={b.id} />
                </p>
                <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-lake-deep/10 pt-3 text-sm">
                  <Smartphone className="size-4 text-muted-foreground" />
                  <span>
                    Најавени уреди:{' '}
                    <span
                      className={
                        b.devices.length >= b.maxDevices
                          ? 'font-semibold text-terracotta'
                          : 'font-semibold text-ink'
                      }
                    >
                      {b.devices.length} / {b.maxDevices}
                    </span>
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="ml-auto"
                    onClick={() => setDevicesOf(b.id)}
                  >
                    Прегледај
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <CreateBoatForm
        password={password}
        onAuthLost={onAuthLost}
        onCreated={load}
      />

      <EditBoatDialog
        boat={editing}
        password={password}
        onAuthLost={onAuthLost}
        onClose={() => setEditing(null)}
        onSaved={load}
      />
      <DevicesDialog
        boat={boats?.find((b) => b.id === devicesOf) ?? null}
        password={password}
        onAuthLost={onAuthLost}
        onClose={() => setDevicesOf(null)}
        onChanged={load}
      />
      <DeleteBoatDialog
        boat={deleting}
        password={password}
        onAuthLost={onAuthLost}
        onClose={() => setDeleting(null)}
        onDeleted={load}
      />
    </div>
  )
}

function CreateBoatForm({
  password,
  onAuthLost,
  onCreated,
}: {
  password: string
  onAuthLost: (m: string) => void
  onCreated: () => void
}) {
  const [name, setName] = useState('')
  const [id, setId] = useState('')
  const [idTouched, setIdTouched] = useState(false)
  const [boatPassword, setBoatPassword] = useState('')
  const [devices, setDevices] = useState('1')
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const code = idTouched ? id : slugify(name)
  const codeValid = BOAT_ID_RE.test(code) && code !== 'admin'
  const maxDevices = parseDevices(devices)
  const valid =
    name.trim().length > 0 &&
    codeValid &&
    boatPassword.length >= 6 &&
    maxDevices !== null

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!valid || maxDevices === null) return
    setPending(true)
    setError(null)
    try {
      const res = await createBoat({
        data: {
          password,
          id: code,
          name: name.trim(),
          boatPassword,
          maxDevices,
        },
      })
      if (!res.ok) {
        if (res.error === 'exists')
          return setError('Веќе постои брод со тој код. Изберете друг.')
        return onAuthLost(AUTH_ERRORS[res.error])
      }
      toast.success(`Бродот „${name.trim()}“ е додаден.`)
      setName('')
      setId('')
      setIdTouched(false)
      setBoatPassword('')
      setDevices('1')
      onCreated()
    } catch {
      setError('Додавањето не успеа. Проверете ја врската и обидете се пак.')
    } finally {
      setPending(false)
    }
  }

  return (
    <section
      aria-labelledby="new-boat"
      className="h-fit rounded-2xl border border-lake-deep/10 bg-white p-5 shadow-sm lg:sticky lg:top-4"
    >
      <h2
        id="new-boat"
        className="flex items-center gap-2 font-semibold text-ink"
      >
        <Plus className="size-4 text-terracotta" /> Нов брод
      </h2>
      <form onSubmit={submit} className="mt-4 space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="boat-name">Име на бродот</Label>
          <Input
            id="boat-name"
            value={name}
            maxLength={80}
            placeholder="на пр. Марија"
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="boat-code">Код (за линкот и најавата)</Label>
          <Input
            id="boat-code"
            value={code}
            maxLength={40}
            onChange={(e) => {
              setIdTouched(true)
              setId(e.target.value.toLowerCase())
            }}
            aria-invalid={code.length > 0 && !codeValid}
            aria-describedby="boat-code-hint"
            className="font-mono"
          />
          <p id="boat-code-hint" className="text-xs text-muted-foreground">
            {code === 'admin'
              ? 'Кодот „admin“ е резервиран за главниот админ.'
              : code && !codeValid
                ? 'Само мали латинични букви, бројки и цртички.'
                : `Корисничко име за најава и линк: /b/${code || '…'}`}
          </p>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="boat-pass">Лозинка за бродот</Label>
          <Input
            id="boat-pass"
            type="password"
            autoComplete="new-password"
            value={boatPassword}
            onChange={(e) => setBoatPassword(e.target.value)}
            aria-invalid={boatPassword.length > 0 && boatPassword.length < 6}
            aria-describedby="boat-pass-hint"
          />
          <p id="boat-pass-hint" className="text-xs text-muted-foreground">
            Најмалку 6 знаци. Со кодот и оваа лозинка екипажот се најавува на
            почетната страница.
          </p>
        </div>
        <MaxDevicesField
          id="boat-devices"
          value={devices}
          onChange={setDevices}
        />
        {error && (
          <p role="alert" className="text-sm text-destructive">
            {error}
          </p>
        )}
        <Button type="submit" className="w-full" disabled={!valid || pending}>
          {pending ? (
            <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
          ) : (
            <Plus className="size-4" />
          )}
          Додај брод
        </Button>
      </form>
    </section>
  )
}

function EditBoatDialog({
  boat,
  password,
  onAuthLost,
  onClose,
  onSaved,
}: {
  boat: Boat | null
  password: string
  onAuthLost: (m: string) => void
  onClose: () => void
  onSaved: () => void
}) {
  const [name, setName] = useState('')
  const [boatPassword, setBoatPassword] = useState('')
  const [devices, setDevices] = useState('1')
  const [pending, setPending] = useState(false)
  const [shownFor, setShownFor] = useState<string | null>(null)
  if (boat && shownFor !== boat.id) {
    setShownFor(boat.id)
    setName(boat.name)
    setBoatPassword('')
    setDevices(String(boat.maxDevices))
  }

  const passOk = boatPassword.length === 0 || boatPassword.length >= 6
  const maxDevices = parseDevices(devices)
  const valid = name.trim().length > 0 && passOk && maxDevices !== null
  const dropped =
    boat && maxDevices !== null
      ? Math.max(0, boat.devices.length - maxDevices)
      : 0

  const save = async () => {
    if (!boat || !valid || maxDevices === null) return
    setPending(true)
    try {
      const res = await updateBoat({
        data: {
          password,
          id: boat.id,
          name: name.trim(),
          boatPassword: boatPassword || undefined,
          maxDevices,
        },
      })
      if (!res.ok) return onAuthLost(AUTH_ERRORS[res.error])
      toast.success('Промените се зачувани.')
      onSaved()
      onClose()
      setShownFor(null)
    } catch {
      toast.error('Зачувувањето не успеа. Обидете се пак.')
    } finally {
      setPending(false)
    }
  }

  return (
    <Dialog
      open={!!boat}
      onOpenChange={(o) => {
        if (!o) {
          onClose()
          setShownFor(null)
        }
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Име, лозинка и уреди</DialogTitle>
          <DialogDescription>
            Кодот и линкот остануваат исти. Оставете ја лозинката празна ако не
            сакате да ја менувате.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="edit-boat-name">Име на бродот</Label>
            <Input
              id="edit-boat-name"
              value={name}
              maxLength={80}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="edit-boat-pass">Нова лозинка</Label>
            <Input
              id="edit-boat-pass"
              type="password"
              autoComplete="new-password"
              value={boatPassword}
              onChange={(e) => setBoatPassword(e.target.value)}
              aria-invalid={!passOk}
            />
            {!passOk && (
              <p className="text-xs text-destructive">Најмалку 6 знаци.</p>
            )}
          </div>
          <MaxDevicesField
            id="edit-boat-devices"
            value={devices}
            onChange={setDevices}
          />
          {dropped > 0 && (
            <p role="alert" className="text-sm text-terracotta">
              Сега се најавени {boat?.devices.length} уреди. При зачувување{' '}
              {dropped === 1
                ? 'најдолго некористениот уред ќе биде одјавен.'
                : `${dropped} најдолго некористени уреди ќе бидат одјавени.`}
            </p>
          )}
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline">Откажи</Button>
          </DialogClose>
          <Button onClick={save} disabled={!valid || pending}>
            {pending && (
              <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
            )}
            Зачувај
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

function DeleteBoatDialog({
  boat,
  password,
  onAuthLost,
  onClose,
  onDeleted,
}: {
  boat: Boat | null
  password: string
  onAuthLost: (m: string) => void
  onClose: () => void
  onDeleted: () => void
}) {
  const [pending, setPending] = useState(false)
  const remove = async () => {
    if (!boat) return
    setPending(true)
    try {
      const res = await deleteBoat({ data: { password, id: boat.id } })
      if (!res.ok) return onAuthLost(AUTH_ERRORS[res.error])
      toast.success(`Бродот „${boat.name}“ е избришан.`)
      onDeleted()
      onClose()
    } catch {
      toast.error('Бришењето не успеа. Обидете се пак.')
    } finally {
      setPending(false)
    }
  }
  return (
    <Dialog open={!!boat} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Да се избрише „{boat?.name}“?</DialogTitle>
          <DialogDescription>
            Се бришат бродот, неговите точки и текстови. Линкот за турата повеќе
            нема да работи. Ова не може да се врати.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline">Откажи</Button>
          </DialogClose>
          <Button variant="destructive" onClick={remove} disabled={pending}>
            {pending && (
              <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
            )}
            Избриши
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/** The devices logged in to a boat; the main admin can log them out. */
function DevicesDialog({
  boat,
  password,
  onAuthLost,
  onClose,
  onChanged,
}: {
  boat: Boat | null
  password: string
  onAuthLost: (m: string) => void
  onClose: () => void
  onChanged: () => void | Promise<void>
}) {
  const [pending, setPending] = useState<string | null>(null)
  const remove = async (deviceId?: string) => {
    if (!boat) return
    setPending(deviceId ?? 'all')
    try {
      const res = await removeBoatDevices({
        data: { password, boatId: boat.id, deviceId },
      })
      if (!res.ok) return onAuthLost(AUTH_ERRORS[res.error])
      toast.success(deviceId ? 'Уредот е одјавен.' : 'Сите уреди се одјавени.')
      await onChanged()
    } catch {
      toast.error('Одјавувањето не успеа. Обидете се пак.')
    } finally {
      setPending(null)
    }
  }
  return (
    <Dialog open={!!boat} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Најавени уреди – {boat?.name}</DialogTitle>
          <DialogDescription>
            Искористени {boat?.devices.length ?? 0} од {boat?.maxDevices ?? 0}{' '}
            дозволени. Одјавениот уред повеќе не може да ја отвори турата сè
            додека пак не се најави, а неговото место се ослободува за друг
            уред.
          </DialogDescription>
        </DialogHeader>
        {boat && boat.devices.length === 0 ? (
          <p className="rounded-xl border border-dashed border-lake-deep/25 p-6 text-center text-sm text-muted-foreground">
            Сè уште нема најавен уред.
          </p>
        ) : (
          <ul className="max-h-80 space-y-2 overflow-y-auto">
            {boat?.devices.map((v) => (
              <li
                key={v.id}
                className="flex items-center gap-3 rounded-xl border border-lake-deep/10 p-3"
              >
                <Smartphone className="size-4 shrink-0 text-lake" />
                <div className="min-w-0 flex-1 text-sm">
                  <p className="truncate font-medium text-ink">{v.label}</p>
                  <p className="text-xs text-muted-foreground">
                    Најавен {dateTime(v.createdAt)} · последно користен{' '}
                    {dateTime(v.lastSeenAt)}
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => remove(v.id)}
                  disabled={pending !== null}
                  aria-label={`Одјави го уредот ${v.label}`}
                >
                  {pending === v.id ? (
                    <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
                  ) : (
                    <LogOut className="size-4" />
                  )}
                  Одјави
                </Button>
              </li>
            ))}
          </ul>
        )}
        <DialogFooter>
          {boat && boat.devices.length > 1 && (
            <Button
              variant="destructive"
              onClick={() => remove()}
              disabled={pending !== null}
            >
              {pending === 'all' && (
                <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
              )}
              Одјави ги сите
            </Button>
          )}
          <DialogClose asChild>
            <Button variant="outline">Затвори</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
