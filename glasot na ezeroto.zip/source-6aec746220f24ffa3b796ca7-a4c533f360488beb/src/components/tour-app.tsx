import { Link } from '@tanstack/react-router'
import {
  ArrowUp,
  Check,
  CircleCheck,
  CircleX,
  Headphones,
  Loader2,
  LockKeyhole,
  MapPin,
  Navigation,
  Pause,
  Play,
  RotateCcw,
  Ship,
  SkipForward,
  Square,
  TriangleAlert,
  Volume2,
} from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import { SiteHeader } from '@/components/site-header'
import { LogoutButton } from '@/components/logout-button'
import { MusicPlayer } from '@/components/music-player'
import { PassengerMap } from '@/components/passenger-map'
import { TourConditions } from '@/components/tour-conditions'
import { Button } from '@/components/ui/button'
import { getLanguage, LANGUAGES, type Lang } from '@/data/tour'
import { useStops, useTourMeta } from '@/lib/stops-context'
import { distanceM, formatDistance } from '@/lib/geo'
import { useUiLang } from '@/lib/ui-lang'
import { useNarrator } from '@/lib/use-narrator'
import { useGpsCheck, type GpsCheckStatus } from '@/lib/use-gps-check'
import { useTourEngine } from '@/lib/use-tour-engine'
import { cn } from '@/lib/utils'

const LANGS_KEY = 'lihnid.narrationLangs'

const img = (file: string, w: number) =>
  `/.netlify/images?url=/img/${file}&w=${w}&fm=webp`

/** Language selection with GPS check, then the live GPS tour. */
export function TourApp() {
  const { t } = useUiLang()

  const [langs, setLangs] = useState<Lang[]>(['mk'])

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(LANGS_KEY) ?? 'null') as
        Lang[] | null
      if (Array.isArray(saved) && saved.length)
        setLangs(saved.filter((l) => LANGUAGES.some((x) => x.code === l)))
    } catch {
      /* ignore */
    }
  }, [])
  useEffect(
    () => localStorage.setItem(LANGS_KEY, JSON.stringify(langs)),
    [langs],
  )

  const stops = useStops()
  const narrator = useNarrator(stops)
  const tour = useTourEngine({ langs, stops, narrator })

  const gps = useGpsCheck()

  if (tour.running)
    return (
      <div className="min-h-screen bg-cream">
        <SiteHeader />
        <main className="mx-auto max-w-content px-4 py-6 sm:px-6 sm:py-10">
          <LiveTour tour={tour} narrator={narrator} langs={langs} t={t} />
        </main>
      </div>
    )

  return (
    <div className="relative isolate min-h-screen overflow-hidden bg-lake-deep">
      <img
        src={img('hero.png', 1600)}
        srcSet={`${img('hero.png', 800)} 800w, ${img('hero.png', 1600)} 1600w`}
        sizes="100vw"
        alt=""
        className="fixed inset-0 -z-20 size-full object-cover"
      />
      <div className="fixed inset-0 -z-10 bg-gradient-to-b from-lake-deep/70 via-lake-deep/55 to-lake-deep/90" />
      <div className="mx-auto flex max-w-content justify-end px-4 pt-3 sm:px-6">
        <LogoutButton light />
      </div>
      <main className="mx-auto max-w-content px-4 pb-10 pt-4 sm:px-6 sm:pt-8">
        <Setup
          t={t}
          langs={langs}
          setLangs={setLangs}
          narrator={narrator}
          gpsStatus={gps.status}
          gpsAccuracy={gps.position?.accuracy}
          onCheckGps={gps.check}
          onStart={() => {
            const p = gps.position
            // Use the pre-checked fix only if it is recent
            tour.start(p && Date.now() - p.at < 60_000 ? p : null)
          }}
        />
      </main>
    </div>
  )
}

type T = ReturnType<typeof useUiLang>['t']

/* ------------------------------------------------------------------ */
/* Setup                                                               */
/* ------------------------------------------------------------------ */

function Setup(props: {
  t: T
  langs: Lang[]
  setLangs: (l: Lang[]) => void
  narrator: ReturnType<typeof useNarrator>
  gpsStatus: GpsCheckStatus
  gpsAccuracy?: number
  onCheckGps: () => void
  onStart: () => void
}) {
  const { t, langs, setLangs, narrator } = props
  const { boat } = useTourMeta()
  // The tour can only start once GPS is on and a position was received
  const gpsReady = props.gpsStatus === 'ready'
  const canStart = langs.length > 0 && gpsReady

  // The natural (Microsoft) voices need internet unless already cached.
  // Read in an effect: navigator doesn't exist during server rendering.
  const [online, setOnline] = useState(true)
  useEffect(() => {
    const update = () => setOnline(navigator.onLine)
    update()
    window.addEventListener('online', update)
    window.addEventListener('offline', update)
    return () => {
      window.removeEventListener('online', update)
      window.removeEventListener('offline', update)
    }
  }, [])

  const ordered = [
    ...langs.map((c) => getLanguage(c)),
    ...LANGUAGES.filter((l) => !langs.includes(l.code)),
  ]

  const toggle = (code: Lang) =>
    setLangs(
      langs.includes(code) ? langs.filter((l) => l !== code) : [...langs, code],
    )

  const moveUp = (code: Lang) => {
    const i = langs.indexOf(code)
    if (i <= 0) return
    const next = [...langs]
    ;[next[i - 1], next[i]] = [next[i], next[i - 1]]
    setLangs(next)
  }

  return (
    <div className="mx-auto max-w-2xl">
      {/* Brand and slogan, centred over the lake */}
      <header className="flex flex-col items-center py-6 text-center text-white sm:py-10">
        <img
          src="/icon.svg"
          alt=""
          className="size-20 rounded-2xl shadow-xl ring-1 ring-white/30 sm:size-24"
        />
        <p className="mt-4 text-balance font-display text-5xl font-bold leading-none tracking-wide drop-shadow-lg sm:text-7xl">
          {t('brand')}
        </p>
        <h1 className="mt-3 max-w-xl text-balance font-display text-2xl font-semibold italic leading-snug drop-shadow-lg sm:text-4xl">
          {t('heroTitle')}
        </h1>
      </header>

      {/* Languages */}
      <section className="mt-8 rounded-3xl border border-border bg-card p-5 shadow-xl sm:p-7">
        <h2 className="flex items-center gap-2 text-2xl font-bold text-lake-deep">
          <Headphones className="size-5 text-terracotta" />{' '}
          {t('narrationLangs')}
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          {t('narrationLangsHint')}
        </p>
        <ul className="mt-5 space-y-2">
          {ordered.map((l) => {
            const selected = langs.includes(l.code)
            const pos = langs.indexOf(l.code)
            const voice = narrator.voices?.[l.code]
            return (
              <li
                key={l.code}
                className={cn(
                  'flex items-center gap-3 rounded-2xl border p-3 transition',
                  selected
                    ? 'border-lake bg-lake-light/60'
                    : 'border-border bg-background',
                )}
              >
                <button
                  type="button"
                  onClick={() => toggle(l.code)}
                  aria-pressed={selected}
                  className="flex flex-1 items-center gap-3 text-left"
                >
                  <span
                    className={cn(
                      'grid size-7 shrink-0 place-items-center rounded-full border-2 text-xs font-bold',
                      selected
                        ? 'border-lake-deep bg-lake-deep text-white'
                        : 'border-border text-transparent',
                    )}
                  >
                    {selected ? pos + 1 : <Check className="size-3" />}
                  </span>
                  <span className="text-2xl leading-none">{l.flag}</span>
                  <span className="flex min-w-0 items-center gap-2">
                    <span className="font-semibold">{l.name}</span>
                    <VoiceStatus
                      t={t}
                      lang={l.code}
                      voice={voice}
                      ready={narrator.voices !== null}
                      online={online}
                    />
                  </span>
                </button>
                {selected && pos > 0 && (
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => moveUp(l.code)}
                    aria-label={t('moveUp')}
                  >
                    <ArrowUp className="size-4" />
                  </Button>
                )}
              </li>
            )
          })}
        </ul>
      </section>

      <GpsCard
        t={t}
        status={props.gpsStatus}
        accuracy={props.gpsAccuracy}
        onCheck={props.onCheckGps}
      />

      <Button
        size="lg"
        disabled={!canStart}
        onClick={props.onStart}
        aria-describedby={canStart ? undefined : 'start-blocked'}
        className="mt-6 h-14 w-full rounded-full bg-terracotta text-lg hover:bg-terracotta/90 disabled:opacity-60"
      >
        {gpsReady ? (
          <Ship className="size-5" />
        ) : (
          <LockKeyhole className="size-5" />
        )}{' '}
        {t('begin')}
      </Button>
      {!canStart && (
        <p
          id="start-blocked"
          className="mx-auto mt-3 w-fit rounded-full bg-white/90 px-4 py-1.5 text-center text-sm font-medium text-terracotta"
        >
          {langs.length === 0 ? t('pickOne') : t('gpsNeeded')}
        </p>
      )}
      <p className="mt-6 text-center">
        {boat ? (
          // A boat's own editor; the main admin's /admin would change every boat
          <Link
            to="/b/$boat/admin"
            params={{ boat: boat.id }}
            className="text-xs text-white/60 underline-offset-4 hover:text-white hover:underline"
          >
            Уредување на турата на „{boat.name}“
          </Link>
        ) : (
          <Link
            to="/admin"
            className="inline-flex items-center gap-2 rounded-full bg-white/90 px-5 py-2.5 text-sm font-semibold text-lake-deep shadow-lg transition-colors hover:bg-white focus-visible:outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 motion-reduce:transition-none"
          >
            <LockKeyhole className="size-4 text-terracotta" /> Админ страна
          </Link>
        )}
      </p>
    </div>
  )
}

function GpsCard({
  t,
  status,
  accuracy,
  onCheck,
}: {
  t: T
  status: GpsCheckStatus
  accuracy?: number
  onCheck: () => void
}) {
  const ready = status === 'ready'
  const problem =
    status === 'denied'
      ? t('gpsBlocked')
      : status === 'unavailable'
        ? t('gpsOff')
        : status === 'timeout'
          ? t('gpsNoFix')
          : status === 'unsupported'
            ? t('gpsUnsupported')
            : null
  return (
    <section
      className={cn(
        'mt-5 rounded-3xl border bg-card p-5 shadow-xl sm:p-7',
        ready
          ? 'border-emerald-500/50'
          : problem
            ? 'border-terracotta/50'
            : 'border-border',
      )}
      aria-live="polite"
    >
      <div className="flex items-start gap-3">
        <Navigation
          className={cn(
            'mt-0.5 size-6 shrink-0',
            ready ? 'text-emerald-600' : 'text-terracotta',
          )}
        />
        <div className="min-w-0 flex-1">
          <h2 className="text-2xl font-bold text-lake-deep">{t('modeGps')}</h2>
          {status === 'checking' && (
            <p className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
              {t('gpsChecking')}
            </p>
          )}
          {ready && (
            <p className="mt-1 flex items-center gap-2 text-sm font-semibold text-emerald-700">
              <CircleCheck className="size-4" /> {t('gpsReady')}
              {accuracy !== undefined && (
                <span className="font-normal text-muted-foreground">
                  · {t('accuracy')} ±{Math.round(accuracy)} m
                </span>
              )}
            </p>
          )}
          {status === 'prompt' && (
            <p className="mt-1 text-sm text-muted-foreground">
              {t('gpsPrompt')}
            </p>
          )}
          {problem && (
            <p className="mt-1 flex items-start gap-2 text-sm text-terracotta">
              <TriangleAlert className="mt-0.5 size-4 shrink-0" /> {problem}
            </p>
          )}
          {(status === 'prompt' || (problem && status !== 'unsupported')) && (
            <Button
              variant={status === 'prompt' ? 'default' : 'outline'}
              size="sm"
              className="mt-3"
              onClick={onCheck}
            >
              {status === 'prompt' ? (
                <Navigation className="size-4" />
              ) : (
                <RotateCcw className="size-4" />
              )}
              {status === 'prompt' ? t('gpsAllow') : t('gpsRetry')}
            </Button>
          )}
        </div>
      </div>
    </section>
  )
}

function VoiceStatus({
  t,
  lang,
  voice,
  ready,
  online,
}: {
  t: T
  lang: Lang
  voice?: { voice: SpeechSynthesisVoice | null; exact: boolean }
  ready: boolean
  online: boolean
}) {
  const hasCloud = Boolean(LANGUAGES.find((l) => l.code === lang)?.cloudVoice)
  // The Microsoft voice is played as audio from the server on every device
  // (needs internet, or audio already cached); the device voice is the backup.
  const found = (hasCloud && online) || Boolean(voice?.voice)
  // Offline and the device voices haven't been listed yet: don't guess.
  if (!found && !ready) return null
  const label = found ? t('voiceFound') : t('voiceMissing')
  return found ? (
    <CircleCheck
      className="size-5 shrink-0 text-emerald-600"
      role="img"
      aria-label={label}
    />
  ) : (
    <CircleX
      className="size-5 shrink-0 text-red-600"
      role="img"
      aria-label={label}
    />
  )
}

/* ------------------------------------------------------------------ */
/* Live tour                                                           */
/* ------------------------------------------------------------------ */

function LiveTour({
  tour,
  narrator,
  langs,
  t,
}: {
  tour: ReturnType<typeof useTourEngine>
  narrator: ReturnType<typeof useNarrator>
  langs: Lang[]
  t: T
}) {
  const { nowPlaying, queue } = narrator
  const STOPS = useStops()
  const playingStop = nowPlaying
    ? STOPS.find((s) => s.id === nowPlaying.stopId)
    : undefined

  // The route has no fixed order: the boat can start anywhere and every zone
  // tells its story when the boat enters it. "Next" is the nearest zone not
  // heard yet (list order only until there is a GPS position).
  const { nextStop, nextDistance } = useMemo(() => {
    const left = STOPS.filter((s) => !tour.triggered.includes(s.id))
    const p = tour.position
    if (!p) return { nextStop: left[0], nextDistance: null }
    let best: (typeof left)[number] | undefined
    let bestD = Infinity
    for (const s of left) {
      // distance to the zone's edge, so a big zone close by counts as near
      const d = Math.max(0, distanceM(p.lat, p.lng, s.lat, s.lng) - s.radius)
      if (d < bestD) {
        best = s
        bestD = d
      }
    }
    return { nextStop: best, nextDistance: best ? bestD : null }
  }, [STOPS, tour.triggered, tour.position])

  const finished = !nextStop && !narrator.busy

  return (
    <div className="grid gap-6 lg:grid-cols-[1.25fr_1fr]">
      <div className="space-y-5">
        {/* Status bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <StatusPill tour={tour} t={t} />
          <Button
            variant="outline"
            size="sm"
            className="rounded-full"
            onClick={tour.stop}
          >
            <Square className="size-3.5" /> {t('stop')}
          </Button>
        </div>

        {tour.gpsError && (
          <div className="flex gap-3 rounded-2xl border border-terracotta/40 bg-terracotta/10 p-4 text-sm">
            <TriangleAlert className="size-5 shrink-0 text-terracotta" />
            {tour.gpsError === 'unsupported'
              ? t('gpsUnsupported')
              : t('gpsDenied')}
          </div>
        )}

        {/* Now playing */}
        <section
          aria-live="polite"
          className="overflow-hidden rounded-3xl bg-lake-deep text-white shadow-lg shadow-lake-deep/20"
        >
          {playingStop && nowPlaying ? (
            <div className="p-6 sm:p-8">
              <div className="flex items-center justify-between gap-3">
                <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-[#7fd0c8]">
                  {!narrator.paused && <Wave />} {t('nowPlaying')}
                </p>
                <span className="rounded-full bg-white/15 px-3 py-1 text-sm font-semibold">
                  {getLanguage(nowPlaying.lang).flag}{' '}
                  {getLanguage(nowPlaying.lang).name}
                </span>
              </div>
              <h2 className="mt-3 text-4xl font-bold leading-tight sm:text-5xl">
                {playingStop.name}
              </h2>
              <p className="text-white/70">{playingStop.subtitle}</p>
              <p className="mt-5 max-h-64 overflow-y-auto text-lg leading-relaxed">
                {nowPlaying.sentences.map((s, i) => (
                  <span
                    key={i}
                    className={cn(
                      'transition-colors',
                      i === nowPlaying.sentenceIndex
                        ? 'rounded bg-white/15 text-white'
                        : i < nowPlaying.sentenceIndex
                          ? 'text-white/55'
                          : 'text-white/80',
                    )}
                  >
                    {s}{' '}
                  </span>
                ))}
              </p>
              <div className="mt-6 flex flex-wrap items-center gap-2">
                {narrator.paused ? (
                  <Button
                    onClick={narrator.resume}
                    className="rounded-full bg-white text-lake-deep hover:bg-white/90"
                  >
                    <Play className="size-4" /> {t('resume')}
                  </Button>
                ) : (
                  <Button
                    onClick={narrator.pause}
                    className="rounded-full bg-white text-lake-deep hover:bg-white/90"
                  >
                    <Pause className="size-4" /> {t('pause')}
                  </Button>
                )}
                <Button
                  variant="ghost"
                  onClick={narrator.skip}
                  className="rounded-full text-white hover:bg-white/15 hover:text-white"
                >
                  <SkipForward className="size-4" /> {t('skip')}
                </Button>
                {queue.length > 0 && (
                  <span className="ml-auto text-sm text-white/70">
                    {t('statusQueued')}:{' '}
                    {queue.map((q) => getLanguage(q.lang).flag).join(' ')}
                  </span>
                )}
              </div>
            </div>
          ) : finished ? (
            <div className="flex items-center gap-4 p-6 sm:p-8">
              <CircleCheck className="size-10 shrink-0 text-[#7fd0c8]" />
              <p className="text-3xl font-bold">{t('tourDone')}</p>
            </div>
          ) : (
            <div className="p-6 sm:p-8">
              <p className="flex items-center gap-2 text-sm text-white/75">
                <Ship className="size-4 animate-bounce" /> {t('waiting')}
              </p>
              {nextStop && (
                <>
                  <p className="mt-4 text-xs font-semibold uppercase tracking-[0.16em] text-[#7fd0c8]">
                    {t('nextStop')}
                  </p>
                  <h2 className="mt-1 text-4xl font-bold">{nextStop.name}</h2>
                  <p className="text-white/70">{nextStop.subtitle}</p>
                  {nextDistance !== null && (
                    <p className="mt-4 inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-sm">
                      <MapPin className="size-4" />{' '}
                      {formatDistance(nextDistance)} {t('distance')}
                    </p>
                  )}
                </>
              )}
            </div>
          )}
        </section>

        <PreloadStatus narrator={narrator} t={t} />

        {/* Background music, quieter while a story is told */}
        <MusicPlayer ducked={narrator.busy} />

        {/* Stops */}
        <section className="rounded-3xl border border-border bg-card p-4 sm:p-6">
          <h3 className="px-1 text-2xl font-bold text-lake-deep">
            {t('stopsTitle')}
          </h3>
          <ol className="mt-3 divide-y divide-border">
            {STOPS.map((s, i) => {
              const heard = tour.triggered.includes(s.id)
              const playing = nowPlaying?.stopId === s.id
              const queued = queue.some((q) => q.stopId === s.id)
              return (
                <li key={s.id} className="flex items-center gap-3 px-1 py-3">
                  <span
                    className={cn(
                      'grid size-8 shrink-0 place-items-center rounded-full text-sm font-bold',
                      playing
                        ? 'bg-terracotta text-white'
                        : heard
                          ? 'bg-lake-deep text-white'
                          : 'border-2 border-lake-deep/30 text-lake-deep',
                    )}
                  >
                    {i + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{s.name}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {playing
                        ? t('nowPlaying')
                        : queued
                          ? t('statusQueued')
                          : heard
                            ? t('statusHeard')
                            : s.subtitle}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant={heard ? 'ghost' : 'outline'}
                    className="shrink-0 rounded-full"
                    disabled={playing || queued}
                    onClick={() => tour.playStop(s.id)}
                    aria-label={heard ? t('replay') : t('playNow')}
                  >
                    {heard ? (
                      <RotateCcw className="size-4" />
                    ) : (
                      <Play className="size-4" />
                    )}
                    <span className="hidden sm:inline">
                      {heard ? t('replay') : t('playNow')}
                    </span>
                  </Button>
                </li>
              )
            })}
          </ol>
        </section>
      </div>

      {/* Map */}
      <div className="order-first lg:order-none lg:sticky lg:top-6 lg:self-start">
        <PassengerMap
          position={tour.position}
          triggered={tour.triggered}
          activeStopId={nowPlaying?.stopId}
          headline={
            playingStop && nowPlaying ? (
              <>
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#7fd0c8]">
                  {t('nowPlaying')} · {getLanguage(nowPlaying.lang).flag}{' '}
                  {getLanguage(nowPlaying.lang).name}
                </p>
                <p className="mt-1 font-display text-3xl font-bold leading-tight">
                  {playingStop.name}
                </p>
                <p className="text-sm text-white/75">{playingStop.subtitle}</p>
              </>
            ) : nextStop ? (
              <>
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#7fd0c8]">
                  {t('nextStop')}
                </p>
                <p className="mt-1 font-display text-3xl font-bold leading-tight">
                  {nextStop.name}
                </p>
                {nextDistance !== null && (
                  <p className="text-sm text-white/75">
                    {formatDistance(nextDistance)} {t('distance')}
                  </p>
                )}
              </>
            ) : (
              <p className="font-display text-2xl font-bold">{t('tourDone')}</p>
            )
          }
        />
        <TourConditions position={tour.position} />
        <p className="mt-3 text-center text-xs text-muted-foreground">
          {langs
            .map((l) => `${getLanguage(l).flag} ${getLanguage(l).name}`)
            .join('  →  ')}
        </p>
      </div>
    </div>
  )
}

function StatusPill({
  tour,
  t,
}: {
  tour: ReturnType<typeof useTourEngine>
  t: T
}) {
  if (!tour.position)
    return (
      <span className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1.5 text-sm font-semibold">
        <Loader2 className="size-4 animate-spin" /> {t('gpsWaiting')}
      </span>
    )
  return (
    <span className="inline-flex items-center gap-2 rounded-full bg-lake-light px-3 py-1.5 text-sm font-semibold text-lake-deep">
      <span className="size-2 rounded-full bg-emerald-500" /> GPS
      {tour.position.accuracy !== undefined && (
        <span className="font-normal">
          · {t('accuracy')} ±{Math.round(tour.position.accuracy)} m
        </span>
      )}
    </span>
  )
}

function Wave() {
  return (
    <span className="flex h-3 items-end gap-0.5" aria-hidden>
      {[0, 0.15, 0.3, 0.45].map((d) => (
        <span
          key={d}
          className="wave-bar w-0.5 rounded-full bg-[#7fd0c8]"
          style={{ height: '100%', animationDelay: `${d}s` }}
        />
      ))}
    </span>
  )
}

/** Progress of downloading the narration audio for use without internet. */
function PreloadStatus({
  narrator,
  t,
}: {
  narrator: ReturnType<typeof useNarrator>
  t: T
}) {
  const p = narrator.preload
  if (!p || p.total === 0) return null
  const finished = p.done >= p.total
  return (
    <p className="flex items-center gap-2 text-xs text-muted-foreground">
      <Volume2 className="size-3.5 shrink-0 text-lake" />
      {!finished
        ? `${t('preparingAudio')}: ${Math.round((p.done / p.total) * 100)}%`
        : p.failed
          ? t('audioPartly')
          : t('audioReady')}
    </p>
  )
}
