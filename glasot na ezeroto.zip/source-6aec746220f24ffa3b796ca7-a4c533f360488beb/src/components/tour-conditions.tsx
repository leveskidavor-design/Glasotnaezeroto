import { Gauge, Loader2, Navigation2, Thermometer, Wind } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { distanceM } from '@/lib/geo'
import { useUiLang } from '@/lib/ui-lang'
import type { Position } from '@/lib/use-tour-engine'
import { cn } from '@/lib/utils'

/** Used for the weather until the boat has a GPS position (Ohrid harbour). */
const OHRID: [number, number] = [41.1116, 20.7986]
const WEATHER_REFRESH_MS = 10 * 60_000

interface Weather {
  temperature: number
  windSpeed: number
  windGusts: number
  /** Direction the wind blows from, degrees clockwise from north */
  windFrom: number
  code: number
  at: number
}

const COMPASS = ['С', 'СИ', 'И', 'ЈИ', 'Ј', 'ЈЗ', 'З', 'СЗ']
const COMPASS_LONG = [
  'северен',
  'североисточен',
  'источен',
  'југоисточен',
  'јужен',
  'југозападен',
  'западен',
  'северозападен',
]
const compassIndex = (deg: number) =>
  Math.round((((deg % 360) + 360) % 360) / 45) % 8

/** WMO weather codes as short Macedonian descriptions. */
function describe(code: number) {
  if (code === 0) return 'Ведро'
  if (code <= 2) return 'Претежно ведро'
  if (code === 3) return 'Облачно'
  if (code === 45 || code === 48) return 'Магла'
  if (code >= 51 && code <= 57) return 'Ситен дожд'
  if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return 'Дожд'
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return 'Снег'
  if (code >= 95) return 'Невреме'
  return ''
}

/** Beaufort-style label so passengers get a feel for the wind. */
function windLabel(kmh: number) {
  if (kmh < 2) return 'Тивко'
  if (kmh < 12) return 'Слаб ветар'
  if (kmh < 29) return 'Умерен ветар'
  if (kmh < 50) return 'Силен ветар'
  return 'Многу силен ветар'
}

/**
 * Current weather at the boat (Open-Meteo, free and keyless). Refreshes every
 * 10 minutes, and when the boat has moved more than ~3 km.
 */
function useWeather(position: Position | null) {
  const [weather, setWeather] = useState<Weather | null>(null)
  const [failed, setFailed] = useState(false)
  const [lat, lng] = position ? [position.lat, position.lng] : OHRID
  // Snap to a ~3 km grid so GPS updates don't trigger a new request
  const fLat = Math.round(Math.round(lat / 0.03) * 0.03 * 100) / 100
  const fLng = Math.round(Math.round(lng / 0.03) * 0.03 * 100) / 100

  const [key, setKey] = useState(0)
  useEffect(() => {
    const id = setInterval(() => setKey((k) => k + 1), WEATHER_REFRESH_MS)
    return () => clearInterval(id)
  }, [])

  useEffect(() => {
    const ctrl = new AbortController()
    const url =
      'https://api.open-meteo.com/v1/forecast?' +
      new URLSearchParams({
        latitude: String(fLat),
        longitude: String(fLng),
        current:
          'temperature_2m,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m',
        wind_speed_unit: 'kmh',
        timezone: 'auto',
      }).toString()
    fetch(url, { signal: ctrl.signal })
      .then((r) => {
        if (!r.ok) throw new Error(String(r.status))
        return r.json() as Promise<{
          current?: {
            temperature_2m: number
            weather_code: number
            wind_speed_10m: number
            wind_direction_10m: number
            wind_gusts_10m: number
          }
        }>
      })
      .then((d) => {
        const c = d.current
        if (!c) throw new Error('no data')
        setWeather({
          temperature: c.temperature_2m,
          windSpeed: c.wind_speed_10m,
          windGusts: c.wind_gusts_10m,
          windFrom: c.wind_direction_10m,
          code: c.weather_code,
          at: Date.now(),
        })
        setFailed(false)
      })
      .catch((e: unknown) => {
        if ((e as Error).name !== 'AbortError') setFailed(true)
      })
    return () => ctrl.abort()
  }, [fLat, fLng, key])

  return { weather, failed }
}

/**
 * Boat speed in km/h. Uses the speed the GPS reports; when the device doesn't
 * report it, it is worked out from successive positions. Smoothed so the
 * number doesn't jump around.
 */
function useBoatSpeed(position: Position | null) {
  const [kmh, setKmh] = useState<number | null>(null)
  const prev = useRef<Position | null>(null)

  useEffect(() => {
    if (!position) return
    let mps: number | null = null
    if (typeof position.speed === 'number' && position.speed >= 0) {
      mps = position.speed
    } else {
      const p = prev.current
      if (p?.at && position.at && position.at > p.at) {
        const dt = (position.at - p.at) / 1000
        const d = distanceM(p.lat, p.lng, position.lat, position.lng)
        // Ignore jitter smaller than the GPS uncertainty
        const noise = Math.max(position.accuracy ?? 10, p.accuracy ?? 10)
        if (dt >= 1) mps = d < noise / 2 && dt < 10 ? 0 : d / dt
      }
    }
    prev.current = position
    if (mps === null || !Number.isFinite(mps) || mps > 40) return
    const next = mps * 3.6
    setKmh((cur) => (cur === null ? next : cur * 0.6 + next * 0.4))
  }, [position])

  return kmh
}

function Panel({
  title,
  icon: Icon,
  children,
  className,
}: {
  title: string
  icon: typeof Wind
  children: React.ReactNode
  className?: string
}) {
  return (
    <section
      aria-label={title}
      className={cn(
        'rounded-2xl border border-lake-deep/15 bg-card p-4 shadow-sm',
        className,
      )}
    >
      <h2 className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
        <Icon className="size-4 text-terracotta" /> {title}
      </h2>
      {children}
    </section>
  )
}

/** Weather and boat-speed windows shown under the map during the tour. */
export function TourConditions({ position }: { position: Position | null }) {
  const { t } = useUiLang()
  const { weather, failed } = useWeather(position)
  const kmh = useBoatSpeed(position)
  const ci = weather ? compassIndex(weather.windFrom) : 0

  return (
    <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
      <Panel title={t('weatherTitle')} icon={Thermometer}>
        {weather ? (
          <div className="mt-2">
            <p className="flex items-baseline gap-2">
              <span className="font-display text-4xl font-bold text-lake-deep">
                {Math.round(weather.temperature)}°C
              </span>
              <span className="text-sm text-muted-foreground">
                {describe(weather.code)}
              </span>
            </p>
            <p className="mt-2 flex items-center gap-2 text-sm">
              <span
                className="grid size-7 place-items-center rounded-full bg-lake-light text-lake-deep"
                aria-hidden
              >
                {/* Arrow points where the wind blows to */}
                <Navigation2
                  className="size-4"
                  style={{ transform: `rotate(${weather.windFrom + 180}deg)` }}
                />
              </span>
              <span>
                <span className="font-semibold text-ink">
                  {Math.round(weather.windSpeed)} km/h
                </span>{' '}
                {COMPASS_LONG[ci]} ({COMPASS[ci]}) ·{' '}
                {windLabel(weather.windSpeed)}
              </span>
            </p>
            {weather.windGusts > weather.windSpeed + 5 && (
              <p className="mt-1 text-xs text-muted-foreground">
                {t('windGusts')} {Math.round(weather.windGusts)} km/h
              </p>
            )}
          </div>
        ) : failed ? (
          <p className="mt-2 text-sm text-muted-foreground">
            {t('weatherError')}
          </p>
        ) : (
          <p
            className="mt-2 flex items-center gap-2 text-sm text-muted-foreground"
            role="status"
          >
            <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
            Се вчитува…
          </p>
        )}
      </Panel>

      <Panel title={t('speedTitle')} icon={Gauge}>
        {kmh !== null ? (
          <div className="mt-2">
            <p className="flex items-baseline gap-1.5" aria-live="polite">
              <span className="font-display text-4xl font-bold tabular-nums text-lake-deep">
                {kmh < 0.5 ? '0' : kmh < 10 ? kmh.toFixed(1) : Math.round(kmh)}
              </span>
              <span className="text-sm font-semibold text-muted-foreground">
                km/h
              </span>
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              {kmh < 1
                ? t('boatStill')
                : `${(kmh / 1.852).toFixed(1)} ${t('knotsGps')}`}
            </p>
          </div>
        ) : (
          <p className="mt-2 text-sm text-muted-foreground">
            {position ? t('speedCalculating') : t('gpsWaiting')}
          </p>
        )}
      </Panel>
    </div>
  )
}
