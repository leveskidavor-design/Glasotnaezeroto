import 'leaflet/dist/leaflet.css'
import { useEffect, useImperativeHandle, useRef, useState } from 'react'
import type * as L from 'leaflet'
import type { GoogleMapHandle } from '@/components/google-tour-map'
import { bearingDeg, distanceM } from '@/lib/geo'
import { useStops } from '@/lib/stops-context'
import type { Position } from '@/lib/use-tour-engine'

const LAKE_DEEP = '#0b4f5c'
const TERRACOTTA = '#c1553b'

/** Satellite imagery with place labels, plus a plain street map. No API key needed. */
export function addBaseLayers(Leaf: typeof L, map: L.Map) {
  const satellite = Leaf.layerGroup([
    Leaf.tileLayer(
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      {
        maxZoom: 19,
        attribution: 'Сателит © Esri, Maxar, Earthstar Geographics',
      },
    ),
    Leaf.tileLayer(
      'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
      { maxZoom: 19 },
    ),
  ])
  const streets = Leaf.tileLayer(
    'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    {
      maxZoom: 19,
      attribution:
        '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    },
  )
  satellite.addTo(map)
  Leaf.control
    .layers({ Сателит: satellite, Карта: streets }, undefined, {
      position: 'topright',
    })
    .addTo(map)
  map.attributionControl.setPrefix(false)
}

export function stopIcon(Leaf: typeof L, index: number, state: string) {
  return Leaf.divIcon({
    className: '',
    html: `<div class="gm-stop" data-state="${state}">${index + 1}</div>`,
    iconSize: [0, 0],
  })
}

interface Props {
  position: Position | null
  triggered: string[]
  activeStopId?: string
  follow: boolean
  onFollowChange: (follow: boolean) => void
  onStatus: (status: 'loading' | 'ready' | 'error') => void
  handleRef: React.Ref<GoogleMapHandle>
  boatLabel: string
}

/**
 * Interactive map used when Google Maps is not available (no or invalid key).
 * Same behaviour as the Google map: live boat with heading, stop zones,
 * follow-the-boat and all-stops overview.
 */
export function LeafletTourMap({
  position,
  triggered,
  activeStopId,
  follow,
  onFollowChange,
  onStatus,
  handleRef,
  boatLabel,
}: Props) {
  const STOPS = useStops()
  const container = useRef<HTMLDivElement>(null)
  const lib = useRef<typeof L | null>(null)
  const map = useRef<L.Map | null>(null)
  const zones = useRef(
    new Map<string, { circle: L.Circle; marker: L.Marker; index: number }>(),
  )
  const boat = useRef<L.Marker | null>(null)
  const accuracy = useRef<L.Circle | null>(null)
  const lastPos = useRef<Position | null>(null)
  const heading = useRef(160)
  const followRef = useRef(follow)
  const stopsRef = useRef(STOPS)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    followRef.current = follow
  }, [follow])

  const stopsBounds = () => {
    const Leaf = lib.current
    if (!Leaf) return null
    return Leaf.latLngBounds(stopsRef.current.map((s) => [s.lat, s.lng]))
  }

  useImperativeHandle(
    handleRef,
    () => ({
      follow: () => {
        onFollowChange(true)
        const m = map.current
        const p = lastPos.current
        if (m && p) m.setView([p.lat, p.lng], Math.max(m.getZoom(), 15))
      },
      overview: () => {
        onFollowChange(false)
        const b = stopsBounds()
        if (map.current && b) map.current.fitBounds(b, { padding: [32, 32] })
      },
    }),
    [onFollowChange],
  )

  // Create the map once (Leaflet needs the browser, so it is loaded here)
  useEffect(() => {
    let cancelled = false
    const zoneMap = zones.current
    onStatus('loading')
    import('leaflet')
      .then((mod) => {
        const Leaf = (mod.default ?? mod) as typeof L
        if (cancelled || !container.current) return
        lib.current = Leaf
        const m = Leaf.map(container.current, {
          zoomControl: true,
          attributionControl: true,
        })
        map.current = m
        addBaseLayers(Leaf, m)
        const b = stopsBounds()
        if (b) m.fitBounds(b, { padding: [32, 32] })
        m.on('dragstart', () => onFollowChange(false))

        stopsRef.current.forEach((s, i) => {
          const circle = Leaf.circle([s.lat, s.lng], {
            radius: s.radius,
            color: LAKE_DEEP,
            weight: 1.5,
            opacity: 0.8,
            fillColor: LAKE_DEEP,
            fillOpacity: 0.18,
            interactive: false,
          }).addTo(m)
          const marker = Leaf.marker([s.lat, s.lng], {
            icon: stopIcon(Leaf, i, 'pending'),
            title: s.name,
            keyboard: false,
          }).addTo(m)
          zoneMap.set(s.id, { circle, marker, index: i })
        })

        accuracy.current = Leaf.circle([0, 0], {
          radius: 0,
          color: '#2563eb',
          weight: 1,
          opacity: 0.35,
          fillColor: '#2563eb',
          fillOpacity: 0.1,
          interactive: false,
        })
        boat.current = Leaf.marker([0, 0], {
          icon: Leaf.divIcon({
            className: '',
            html: `<div class="gm-boat" role="img" aria-label="${boatLabel}">
              <span class="gm-boat-ping"></span>
              <span class="gm-boat-arrow"><svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M12 2 L19 20 L12 16 L5 20 Z" fill="#fff"/></svg></span>
              <span class="gm-boat-label">${boatLabel}</span></div>`,
            iconSize: [0, 0],
          }),
          zIndexOffset: 1000,
          keyboard: false,
          interactive: false,
        })
        setReady(true)
        onStatus('ready')
      })
      .catch(() => {
        if (!cancelled) onStatus('error')
      })
    return () => {
      cancelled = true
      zoneMap.clear()
      map.current?.remove()
      map.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- create the map once
  }, [])

  // Keep zones in sync with edited stop positions
  useEffect(() => {
    stopsRef.current = STOPS
    if (!ready) return
    STOPS.forEach((s) => {
      const z = zones.current.get(s.id)
      if (!z) return
      z.circle.setLatLng([s.lat, s.lng]).setRadius(s.radius)
      z.marker.setLatLng([s.lat, s.lng])
    })
  }, [STOPS, ready])

  // Move the boat
  useEffect(() => {
    const m = map.current
    const b = boat.current
    if (!ready || !m || !b) return
    if (!position) {
      b.remove()
      accuracy.current?.remove()
      return
    }
    const prev = lastPos.current
    if (prev && distanceM(prev.lat, prev.lng, position.lat, position.lng) > 3)
      heading.current = bearingDeg(
        prev.lat,
        prev.lng,
        position.lat,
        position.lng,
      )
    const first = !prev
    lastPos.current = position
    const ll: L.LatLngTuple = [position.lat, position.lng]
    b.setLatLng(ll)
    if (!m.hasLayer(b)) b.addTo(m)
    const arrow = b.getElement()?.querySelector<HTMLElement>('.gm-boat-arrow')
    if (arrow) arrow.style.transform = `rotate(${heading.current}deg)`

    const acc = accuracy.current
    if (acc) {
      const show = position.accuracy !== undefined && position.accuracy > 25
      if (show) {
        acc.setLatLng(ll).setRadius(position.accuracy ?? 0)
        if (!m.hasLayer(acc)) acc.addTo(m)
      } else acc.remove()
    }

    if (followRef.current) {
      if (first) m.setView(ll, 15)
      else m.panTo(ll)
    }
  }, [position, ready])

  // Re-centre when follow is switched back on
  useEffect(() => {
    const p = lastPos.current
    if (ready && follow && map.current && p) map.current.panTo([p.lat, p.lng])
  }, [follow, ready])

  // Zone colours
  useEffect(() => {
    const Leaf = lib.current
    if (!ready || !Leaf) return
    zones.current.forEach(({ circle, marker, index }, id) => {
      const active = id === activeStopId
      const heard = triggered.includes(id)
      circle.setStyle({
        color: active ? TERRACOTTA : LAKE_DEEP,
        fillColor: active ? TERRACOTTA : LAKE_DEEP,
        fillOpacity: active ? 0.3 : 0.18,
      })
      marker.setIcon(
        stopIcon(Leaf, index, active ? 'active' : heard ? 'heard' : 'pending'),
      )
    })
  }, [triggered, activeStopId, ready])

  return <div ref={container} className="absolute inset-0 z-0" />
}
