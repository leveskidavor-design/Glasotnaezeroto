import { useRouter } from '@tanstack/react-router'
import {
  Loader2,
  RotateCcw,
  Save,
  Search,
  Square,
  Undo2,
  Volume2,
} from 'lucide-react'
import { useEffect, useMemo, useRef, useState } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { LANGUAGES, type Lang } from '@/data/tour'
import {
  defaultTexts,
  stopKey,
  storyKey,
  TEXT_MAX,
  uiKey,
  type TextOverrides,
} from '@/lib/content-texts'
import { UI_STRINGS, type StringKey } from '@/lib/i18n'
import { AUTH_ERRORS } from '@/lib/admin-auth'
import {
  BOAT_PLACEHOLDER,
  fillBoatName,
  isExtraStop,
} from '@/lib/stop-positions'
import { useStops, useTextOverrides, useTourMeta } from '@/lib/stops-context'
import { saveTexts } from '@/lib/stops.functions'
import {
  sentenceAudioUrl,
  silentWavUrl,
  splitSentences,
} from '@/lib/cloud-voice'
import { resolveVoices } from '@/lib/use-narrator'
import { cn } from '@/lib/utils'

type Scope = 'stop' | 'ui'

const DEFAULTS = defaultTexts()

/**
 * Draft state for one area (stop texts or interface labels): the current
 * value of every key, starting from saved overrides over the defaults.
 */
function useTextDrafts(scope: Scope, boatId?: string) {
  const saved = useTextOverrides()
  const { baseTexts } = useTourMeta()
  // What "original" means: the bundled texts for the main admin; for a boat,
  // the shared texts (bundled + main admin edits) it builds on.
  const base = useMemo(
    () => (boatId ? { ...DEFAULTS, ...baseTexts } : DEFAULTS),
    [boatId, baseTexts],
  )
  const initial = useMemo(() => {
    const out: TextOverrides = {}
    for (const [k, v] of Object.entries(base))
      if (k.startsWith(`${scope}:`)) out[k] = saved[k] ?? v
    return out
  }, [saved, scope, base])

  const [drafts, setDrafts] = useState(initial)
  // Start over from the saved texts whenever they reload (e.g. after saving)
  const [baseline, setBaseline] = useState(initial)
  if (baseline !== initial) {
    setBaseline(initial)
    setDrafts(initial)
  }

  const dirty = Object.keys(initial).some((k) => drafts[k] !== initial[k])
  const isChanged = (k: string) => drafts[k] !== initial[k]
  const isCustom = (k: string) => (drafts[k] ?? '').trim() !== base[k]
  const set = (k: string, v: string) => setDrafts((d) => ({ ...d, [k]: v }))
  const reset = (k: string) => set(k, base[k])
  const discard = () => setDrafts(initial)

  /** Only texts that differ from the layer below are stored. */
  const overrides = () => {
    const out: TextOverrides = {}
    for (const [k, v] of Object.entries(drafts))
      if (v.trim() && v.trim() !== base[k]) out[k] = v.trim()
    return out
  }

  return {
    base,
    drafts,
    dirty,
    isChanged,
    isCustom,
    set,
    reset,
    discard,
    overrides,
  }
}

function SaveBar({
  dirty,
  saving,
  onDiscard,
  onSave,
}: {
  dirty: boolean
  saving: boolean
  onDiscard: () => void
  onSave: () => void
}) {
  // Warn before leaving with unsaved edits
  useEffect(() => {
    if (!dirty) return
    const onBeforeUnload = (e: BeforeUnloadEvent) => e.preventDefault()
    window.addEventListener('beforeunload', onBeforeUnload)
    return () => window.removeEventListener('beforeunload', onBeforeUnload)
  }, [dirty])

  return (
    <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-cream/95 backdrop-blur">
      <div className="mx-auto flex max-w-content items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <p className="text-sm text-muted-foreground" aria-live="polite">
          {dirty ? 'Имате незачувани промени.' : 'Сите промени се зачувани.'}
        </p>
        <div className="flex gap-2">
          <Button
            variant="ghost"
            onClick={onDiscard}
            disabled={!dirty || saving}
          >
            <Undo2 className="size-4" />
            <span className="hidden sm:inline">Откажи</span>
          </Button>
          <Button onClick={onSave} disabled={!dirty || saving}>
            {saving ? (
              <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
            ) : (
              <Save className="size-4" />
            )}
            Зачувај
          </Button>
        </div>
      </div>
    </div>
  )
}

function useSave(
  scope: Scope,
  password: string,
  boatId: string | undefined,
  onAuthLost: (m: string) => void,
) {
  const router = useRouter()
  const [saving, setSaving] = useState(false)
  const save = async (texts: TextOverrides) => {
    setSaving(true)
    try {
      const res = await saveTexts({ data: { password, boatId, scope, texts } })
      if (!res.ok) return onAuthLost(AUTH_ERRORS[res.error])
      await router.invalidate()
      toast.success('Текстовите се зачувани. Важат за сите уреди.')
    } catch {
      toast.error(
        'Зачувувањето не успеа. Проверете ја врската и обидете се пак.',
      )
    } finally {
      setSaving(false)
    }
  }
  return { saving, save }
}

function ResetButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex items-center gap-1 rounded text-xs font-medium text-lake underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50"
    >
      <RotateCcw className="size-3" /> Врати оригинал
    </button>
  )
}

function PlaceholderHint({ boatName }: { boatName?: string }) {
  return (
    <p className="mt-2 max-w-reading rounded-xl bg-lake-light/60 px-3 py-2 text-sm text-lake-deep">
      Напишете{' '}
      <code className="rounded bg-white px-1 font-semibold">
        {BOAT_PLACEHOLDER}
      </code>{' '}
      таму каде што треба да стои името на бродот
      {boatName ? (
        <>
          {' '}
          (ќе пишува <strong>{boatName}</strong>)
        </>
      ) : (
        ' (секој брод го добива своето име)'
      )}
      . На пр.: „Добредојдовте на бродот {BOAT_PLACEHOLDER}!“
    </p>
  )
}

/* ------------------------------------------------------------------ */
/* Stop texts                                                          */
/* ------------------------------------------------------------------ */

/** Plays a story with the voice the tour would use on this device. */
function useListen() {
  const [playing, setPlaying] = useState<string | null>(null)
  const session = useRef(0)
  const audio = useRef<HTMLAudioElement | null>(null)
  const stopAll = () => {
    session.current++
    audio.current?.pause()
    window.speechSynthesis?.cancel()
  }
  useEffect(() => () => stopAll(), [])

  /** Plays the text with the Microsoft voice, sentence by sentence. */
  const listen = (id: string, text: string, lang: Lang) => {
    stopAll()
    if (playing === id) return setPlaying(null)
    const my = session.current
    const end = () => setPlaying((p) => (p === id ? null : p))
    const sentences = splitSentences(text).filter(Boolean)
    const a = (audio.current ??= new Audio())
    // Started inside the tap, so mobile browsers allow the audio below
    a.src = silentWavUrl()
    void a.play().catch(() => {})
    setPlaying(id)

    /** Backup when the Microsoft voice can't be loaded */
    const onDevice = (from: number) => {
      const synth = window.speechSynthesis
      const voice = resolveVoices()[lang]?.voice
      if (!synth || !voice) {
        toast.error(
          'Гласот не може да се вчита, а на уредот нема глас за овој јазик.',
        )
        return end()
      }
      const u = new SpeechSynthesisUtterance(sentences.slice(from).join(' '))
      u.voice = voice
      u.lang = voice.lang
      u.rate = 0.95
      u.onend = end
      u.onerror = end
      synth.speak(u)
    }

    const play = async (i: number): Promise<void> => {
      if (my !== session.current) return
      if (i >= sentences.length) return end()
      try {
        const url = await sentenceAudioUrl(lang, sentences[i])
        if (my !== session.current) return
        a.onended = () => void play(i + 1)
        a.src = url
        await a.play()
      } catch (err) {
        if (my !== session.current) return
        if (err instanceof Error && err.message === 'tts 422')
          toast.info(
            'Природниот глас за изменетиот текст е достапен по зачувувањето. Сега чита гласот на уредот.',
          )
        onDevice(i)
      }
    }
    void play(0)
  }
  return { playing, listen }
}

export function StopTextsEditor({
  password,
  boatId,
  onAuthLost,
}: {
  password: string
  /** Edit this boat's own texts instead of the shared ones */
  boatId?: string
  onAuthLost: (message: string) => void
}) {
  const d = useTextDrafts('stop', boatId)
  const { saving, save } = useSave('stop', password, boatId, onAuthLost)
  const { boat } = useTourMeta()
  const { playing, listen } = useListen()
  // Bundled stops plus this boat's own extra zones
  const stops = useStops()
  const [stopId, setStopId] = useState(stops[0].id)
  const stop = stops.find((s) => s.id === stopId) ?? stops[0]
  const extra = isExtraStop(stop.id)
  const stopChanged = (id: string) =>
    Object.keys(d.drafts).some(
      (k) => k.startsWith(`stop:${id}:`) && d.isChanged(k),
    )

  const nameK = stopKey(stop.id, 'name')
  const subK = stopKey(stop.id, 'subtitle')

  return (
    <div className="pb-28">
      <p className="max-w-reading text-sm text-muted-foreground">
        Изберете точка и сменете го името, поднасловот или приказната што се
        раскажува на секој јазик. Со „Слушни“ ја проверувате приказната со
        гласот на овој уред.
      </p>
      <PlaceholderHint boatName={boat?.name} />

      <div className="mt-6 grid gap-6 lg:grid-cols-[16rem_minmax(0,1fr)]">
        <nav aria-label="Точки">
          <ol className="flex gap-2 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible">
            {stops.map((s, i) => (
              <li key={s.id} className="shrink-0">
                <button
                  type="button"
                  onClick={() => setStopId(s.id)}
                  aria-current={s.id === stopId}
                  className={cn(
                    'flex w-full items-center gap-2 rounded-xl border px-3 py-2 text-left text-sm transition-colors motion-reduce:transition-none focus-visible:outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50',
                    s.id === stopId
                      ? 'border-terracotta bg-white font-semibold text-ink'
                      : 'border-lake-deep/10 bg-white/60 text-muted-foreground hover:bg-white',
                  )}
                >
                  <span className="grid size-6 shrink-0 place-items-center rounded-full bg-lake-deep/10 text-xs font-bold text-lake-deep">
                    {i + 1}
                  </span>
                  <span className="truncate">
                    {d.drafts[stopKey(s.id, 'name')] || s.name}
                  </span>
                  {isExtraStop(s.id) && (
                    <span className="shrink-0 rounded-full bg-terracotta/10 px-1.5 text-[10px] font-semibold uppercase text-terracotta">
                      нова
                    </span>
                  )}
                  {stopChanged(s.id) && (
                    <span
                      className="ml-auto size-2 shrink-0 rounded-full bg-terracotta"
                      aria-label="незачувани промени"
                    />
                  )}
                </button>
              </li>
            ))}
          </ol>
        </nav>

        <div className="space-y-5 rounded-2xl border border-lake-deep/10 bg-white p-4 shadow-sm sm:p-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <Label htmlFor="stop-name">Име на точката</Label>
                {d.isCustom(nameK) && (
                  <ResetButton onClick={() => d.reset(nameK)} />
                )}
              </div>
              <Input
                id="stop-name"
                value={d.drafts[nameK]}
                maxLength={200}
                onChange={(e) => d.set(nameK, e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <Label htmlFor="stop-subtitle">Поднаслов</Label>
                {d.isCustom(subK) && (
                  <ResetButton onClick={() => d.reset(subK)} />
                )}
              </div>
              <Input
                id="stop-subtitle"
                value={d.drafts[subK]}
                maxLength={300}
                onChange={(e) => d.set(subK, e.target.value)}
              />
            </div>
          </div>

          {LANGUAGES.map((l) => {
            const k = storyKey(stop.id, l.code)
            const id = `story-${l.code}`
            const value = d.drafts[k] ?? ''
            return (
              <div key={l.code} className="space-y-1.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <Label htmlFor={id} className="text-base">
                    <span aria-hidden>{l.flag}</span> Приказна · {l.name}
                  </Label>
                  <div className="flex items-center gap-3">
                    {d.isCustom(k) && (
                      <ResetButton onClick={() => d.reset(k)} />
                    )}
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        listen(k, fillBoatName(value, boat?.name), l.code)
                      }
                      disabled={!value.trim()}
                    >
                      {playing === k ? (
                        <Square className="size-4" />
                      ) : (
                        <Volume2 className="size-4" />
                      )}
                      {playing === k ? 'Стоп' : 'Слушни'}
                    </Button>
                  </div>
                </div>
                <Textarea
                  id={id}
                  value={value}
                  maxLength={TEXT_MAX}
                  rows={6}
                  onChange={(e) => d.set(k, e.target.value)}
                  aria-invalid={!extra && !value.trim()}
                  className="leading-relaxed"
                />
                <p
                  className={cn(
                    'text-xs',
                    value.trim() || extra
                      ? 'text-muted-foreground'
                      : 'text-destructive',
                  )}
                >
                  {value.trim()
                    ? `${value.length} знаци · околу ${Math.max(1, Math.round(value.split(/\s+/).length / 2.5 / 60))} мин раскажување`
                    : extra
                      ? 'Нема текст: на овој јазик нема да се раскажува.'
                      : 'Празен текст: ќе се користи оригиналната приказна.'}
                </p>
              </div>
            )
          })}
        </div>
      </div>

      <SaveBar
        dirty={d.dirty}
        saving={saving}
        onDiscard={d.discard}
        onSave={() => save(d.overrides())}
      />
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Interface labels                                                    */
/* ------------------------------------------------------------------ */

export function UiTextsEditor({
  password,
  boatId,
  onAuthLost,
}: {
  password: string
  /** Edit this boat's own texts instead of the shared ones */
  boatId?: string
  onAuthLost: (message: string) => void
}) {
  const d = useTextDrafts('ui', boatId)
  const { saving, save } = useSave('ui', password, boatId, onAuthLost)
  const { boat } = useTourMeta()
  const [query, setQuery] = useState('')
  const keys = Object.keys(UI_STRINGS) as StringKey[]
  const q = query.trim().toLowerCase()
  const shown = keys.filter((k) => {
    if (!q) return true
    const key = uiKey(k)
    return (
      UI_STRINGS[k].toLowerCase().includes(q) ||
      (d.drafts[key] ?? '').toLowerCase().includes(q)
    )
  })

  return (
    <div className="pb-28">
      <p className="max-w-reading text-sm text-muted-foreground">
        Натписите што се гледаат во апликацијата: слоганот, копчињата, пораките
        за GPS и гласот, и прозорците за времето и брзината. Над секое поле е
        оригиналниот текст.
      </p>
      <PlaceholderHint boatName={boat?.name} />

      <div className="relative mt-5 max-w-md">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Пребарај натпис…"
          aria-label="Пребарај натпис"
          className="bg-white pl-9"
        />
      </div>

      <ul className="mt-5 grid gap-3 md:grid-cols-2">
        {shown.map((k) => {
          const key = uiKey(k)
          const id = `ui-${k}`
          const original = d.base[key] ?? UI_STRINGS[k]
          const value = d.drafts[key] ?? ''
          const long = original.length > 70
          return (
            <li
              key={k}
              className={cn(
                'rounded-2xl border bg-white p-4 shadow-sm',
                d.isChanged(key)
                  ? 'border-terracotta/60'
                  : 'border-lake-deep/10',
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <Label
                  htmlFor={id}
                  className="text-xs font-normal text-muted-foreground"
                >
                  Оригинал: {original}
                </Label>
                {d.isCustom(key) && (
                  <ResetButton onClick={() => d.reset(key)} />
                )}
              </div>
              {long ? (
                <Textarea
                  id={id}
                  value={value}
                  maxLength={1000}
                  rows={3}
                  onChange={(e) => d.set(key, e.target.value)}
                  className="mt-2"
                />
              ) : (
                <Input
                  id={id}
                  value={value}
                  maxLength={300}
                  onChange={(e) => d.set(key, e.target.value)}
                  className="mt-2"
                />
              )}
            </li>
          )
        })}
        {shown.length === 0 && (
          <li className="text-sm text-muted-foreground">
            Нема натпис што одговара на пребарувањето.
          </li>
        )}
      </ul>

      <SaveBar
        dirty={d.dirty}
        saving={saving}
        onDiscard={d.discard}
        onSave={() => save(d.overrides())}
      />
    </div>
  )
}
