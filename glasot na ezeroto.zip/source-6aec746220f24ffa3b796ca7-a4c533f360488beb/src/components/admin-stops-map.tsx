import { useEffect, useRef, useState } from 'react'
import {
  makeOverlay,
  stopElement,
  type HtmlOverlay,
} from '@/components/google-tour-map'
import { loadGoogleMaps, onGoogleAuthFailure } from '@/lib/google-maps'

const LAKE_DEEP = '#0b4f5c'
const TERRACOTTA = '#c1553b'

export interface EditableStop {
  id: string
  name: string
  lat: number
  lng: number
  radius: number
}

interface Props {
  stops: EditableStop[]
  selectedId: string | null
  onSelect: (id: string) => void
  onChange: (
    id: string,
    next: { lat: number; lng: number; radius: number },
  ) => void
  onStatus: (status: 'loading' | 'ready' | 'error') => void
  /** Increment to pan to the selected stop */
  focusKey: number
}

const round6 = (n: number) => Math.round(n * 1e6) / 1e6

/**
 * Google map for the admin editor. The selected stop's circle is editable:
 * drag the circle to move the stop, drag the edge handle to change the radius.
 */
export function AdminStopsMap({
  stops,
  selectedId,
  onSelect,
  onChange,
  onStatus,
  focusKey,
}: Props) {
  const container = useRef<HTMLDivElement>(null)
  const map = useRef<google.maps.Map | null>(null)
  const zones = useRef(
    new Map<string, { circle: google.maps.Circle; marker: HtmlOverlay }>(),
  )
  const initial = useRef(stops)
  const handlers = useRef({ onSelect, onChange })
  useEffect(() => {
    handlers.current = { onSelect, onChange }
  })
  const [ready, setReady] = useState(false)

  // Create the map and the circles once
  useEffect(() => {
    let cancelled = false
    const zoneMap = zones.current
    onStatus('loading')
    const offAuth = onGoogleAuthFailure(() => onStatus('error'))

    loadGoogleMaps()
      .then((g) => {
        if (cancelled || !container.current) return
        const bounds = new g.LatLngBounds()
        initial.current.forEach((s) =>
          bounds.extend({ lat: s.lat, lng: s.lng }),
        )

        const m = new g.Map(container.current, {
          center: bounds.getCenter(),
          zoom: 11,
          mapTypeId: 'hybrid',
          mapTypeControl: true,
          mapTypeControlOptions: { mapTypeIds: ['roadmap', 'hybrid'] },
          streetViewControl: false,
          fullscreenControl: true,
          clickableIcons: false,
          gestureHandling: 'greedy',
        })
        m.fitBounds(bounds, 32)
        map.current = m

        initial.current.forEach((s, i) => {
          const circle = new g.Circle({
            map: m,
            center: { lat: s.lat, lng: s.lng },
            radius: s.radius,
            fillColor: LAKE_DEEP,
            fillOpacity: 0.18,
            strokeColor: LAKE_DEEP,
            strokeWeight: 2,
          })
          const el = stopElement(i, s.name)
          el.style.cursor = 'pointer'
          el.addEventListener('click', () => handlers.current.onSelect(s.id))
          const marker = makeOverlay(g, { lat: s.lat, lng: s.lng }, el, 10)
          marker.setMap(m)

          const emit = () => {
            const c = circle.getCenter()
            if (!c) return
            const next = {
              lat: round6(c.lat()),
              lng: round6(c.lng()),
              radius: Math.round(circle.getRadius()),
            }
            marker.setPosition({ lat: next.lat, lng: next.lng })
            handlers.current.onChange(s.id, next)
          }
          circle.addListener('click', () => handlers.current.onSelect(s.id))
          circle.addListener('dragend', emit)
          circle.addListener('radius_changed', () => {
            if (circle.get('lihnidSyncing')) return
            emit()
          })
          circle.addListener('center_changed', () => {
            const c = circle.getCenter()
            if (c) marker.setPosition({ lat: c.lat(), lng: c.lng() })
            if (circle.get('lihnidSyncing') || circle.get('dragging')) return
            emit()
          })
          circle.addListener('dragstart', () => circle.set('dragging', true))
          circle.addListener('dragend', () => circle.set('dragging', false))
          zoneMap.set(s.id, { circle, marker })
        })

        setReady(true)
        onStatus('ready')
      })
      .catch(() => {
        if (!cancelled) onStatus('error')
      })

    return () => {
      cancelled = true
      offAuth()
      zoneMap.forEach(({ circle, marker }) => {
        circle.setMap(null)
        marker.setMap(null)
      })
      zoneMap.clear()
      map.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- create the map once
  }, [])

  // Reflect typed values and the selection on the map
  useEffect(() => {
    if (!ready) return
    for (const s of stops) {
      const z = zones.current.get(s.id)
      if (!z) continue
      const { circle, marker } = z
      const selected = s.id === selectedId
      circle.set('lihnidSyncing', true)
      const c = circle.getCenter()
      if (
        !c ||
        Math.abs(c.lat() - s.lat) > 1e-6 ||
        Math.abs(c.lng() - s.lng) > 1e-6
      ) {
        circle.setCenter({ lat: s.lat, lng: s.lng })
        marker.setPosition({ lat: s.lat, lng: s.lng })
      }
      if (Math.abs(circle.getRadius() - s.radius) >= 1)
        circle.setRadius(s.radius)
      circle.setOptions({
        editable: selected,
        draggable: selected,
        zIndex: selected ? 5 : 1,
        fillColor: selected ? TERRACOTTA : LAKE_DEEP,
        strokeColor: selected ? TERRACOTTA : LAKE_DEEP,
        fillOpacity: selected ? 0.28 : 0.18,
      })
      circle.set('lihnidSyncing', false)
      marker.el.dataset.state = selected ? 'active' : 'pending'
    }
  }, [stops, selectedId, ready])

  // Pan to the selected stop on request
  useEffect(() => {
    if (!ready || !focusKey || !selectedId) return
    const s = stops.find((x) => x.id === selectedId)
    const m = map.current
    if (!s || !m) return
    if ((m.getZoom() ?? 0) < 14) m.setZoom(14)
    m.panTo({ lat: s.lat, lng: s.lng })
    // eslint-disable-next-line react-hooks/exhaustive-deps -- only when focus is requested
  }, [focusKey, ready])

  return <div ref={container} className="absolute inset-0" />
}
