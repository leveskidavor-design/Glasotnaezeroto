import {
  FolderOpen,
  Link2,
  Loader2,
  Music,
  Pause,
  Play,
  SkipBack,
  SkipForward,
  TriangleAlert,
  Volume1,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { resolveStreamUrl } from '@/lib/music.functions'
import { looksLikeStream, PLAYLIST } from '@/lib/stream-hints'
import { useUiLang } from '@/lib/ui-lang'
import { cn } from '@/lib/utils'

const SETTINGS_KEY = 'lihnid.music'
/** Music volume while a story is told: fully silent */
const DUCK_LEVEL = 0
const FADE_MS = 900

type Source = 'url' | 'files'
type Status = 'idle' | 'loading' | 'playing' | 'paused' | 'error'

interface Track {
  name: string
  url: string
}

/**
 * Background music for the tour: an online radio link or audio files from
 * this device. While a story is being told (`ducked`) the music fades down,
 * and comes back once every language has finished.
 */
export function MusicPlayer({ ducked }: { ducked: boolean }) {
  const { t } = useUiLang()
  const audioRef = useRef<HTMLAudioElement>(null)
  const [source, setSource] = useState<Source>('url')
  const [url, setUrl] = useState('')
  const [volume, setVolume] = useState(0.6)
  const [tracks, setTracks] = useState<Track[]>([])
  const [index, setIndex] = useState(0)
  const [status, setStatus] = useState<Status>('idle')
  const [error, setError] = useState<string | null>(null)
  /** Whether the user wants music playing (vs. paused by the user) */
  const wantPlaying = useRef(false)
  /** iOS doesn't allow changing the volume from a page: pause instead */
  const [canSetVolume, setCanSetVolume] = useState(true)
  const pausedForStory = useRef(false)
  /** The link the loaded stream belongs to, and the link already resolved */
  const loadedFor = useRef<string | null>(null)
  const resolvedFor = useRef<string | null>(null)
  /** Stream URLs found for the link, still to try */
  const candidates = useRef<string[]>([])
  const [stationName, setStationName] = useState<string | null>(null)
  const fadeFrame = useRef<number | null>(null)

  // Saved settings (link, volume, source)
  useEffect(() => {
    try {
      const s = JSON.parse(localStorage.getItem(SETTINGS_KEY) ?? 'null') as {
        url?: string
        volume?: number
        source?: Source
      } | null
      if (s?.url) setUrl(s.url)
      if (typeof s?.volume === 'number')
        setVolume(Math.min(1, Math.max(0, s.volume)))
      if (s?.source === 'files' || s?.source === 'url') setSource(s.source)
    } catch {
      /* ignore */
    }
    const a = audioRef.current
    if (a) {
      const before = a.volume
      a.volume = 0.5
      setCanSetVolume(Math.abs(a.volume - 0.5) < 0.01)
      a.volume = before
    }
  }, [])
  useEffect(() => {
    try {
      localStorage.setItem(
        SETTINGS_KEY,
        JSON.stringify({ url, volume, source }),
      )
    } catch {
      /* ignore */
    }
  }, [url, volume, source])

  // Stop the music and free the files when the tour ends
  const tracksRef = useRef(tracks)
  useEffect(() => {
    tracksRef.current = tracks
  }, [tracks])
  useEffect(
    () => () => {
      audioRef.current?.pause()
      tracksRef.current.forEach((tr) => URL.revokeObjectURL(tr.url))
      if (fadeFrame.current) cancelAnimationFrame(fadeFrame.current)
    },
    [],
  )

  const fadeTo = useCallback((target: number) => {
    const a = audioRef.current
    if (!a) return
    if (fadeFrame.current) cancelAnimationFrame(fadeFrame.current)
    const from = a.volume
    const start = performance.now()
    const step = (now: number) => {
      const k = Math.min(1, (now - start) / FADE_MS)
      a.volume = Math.min(1, Math.max(0, from + (target - from) * k))
      fadeFrame.current = k < 1 ? requestAnimationFrame(step) : null
      // Faded out: mute too, so nothing at all is heard under the story
      if (k >= 1 && target === 0) a.muted = true
    }
    fadeFrame.current = requestAnimationFrame(step)
  }, [])

  const play = useCallback(async (src?: string) => {
    const a = audioRef.current
    if (!a) return
    if (src && a.src !== src) a.src = src
    if (!a.src) return
    wantPlaying.current = true
    setError(null)
    setStatus('loading')
    try {
      await a.play()
    } catch (e) {
      // NotAllowedError: needs a tap; anything else is reported by onError
      if ((e as DOMException)?.name === 'NotAllowedError') {
        wantPlaying.current = false
        setStatus('paused')
      }
    }
  }, [])

  // Story playing → music down; all languages done → music back up
  useEffect(() => {
    const a = audioRef.current
    if (!a) return
    if (canSetVolume) {
      if (!ducked) a.muted = false
      fadeTo(ducked ? volume * DUCK_LEVEL : volume)
      return
    }
    if (ducked && !a.paused) {
      pausedForStory.current = true
      a.pause()
    } else if (!ducked && pausedForStory.current) {
      pausedForStory.current = false
      if (wantPlaying.current) {
        // A live stream restarts at the live point
        if (source === 'url') a.load()
        void play()
      }
    }
  }, [ducked, volume, canSetVolume, fadeTo, play, source])

  /** Finds the stream(s) behind a link: a web page, a playlist, … */
  const resolve = async (link: string) => {
    resolvedFor.current = link
    setStatus('loading')
    setError(null)
    try {
      const res = await resolveStreamUrl({ data: { url: link } })
      if (!res.ok) return false
      // An https page can't play http audio: http streams go via our proxy
      candidates.current = res.urls.map((u) =>
        u.startsWith('http:') ? `/radio-proxy?url=${encodeURIComponent(u)}` : u,
      )
      if (res.name) setStationName(res.name)
      return true
    } catch {
      return false
    }
  }

  const fail = () => {
    wantPlaying.current = false
    setStatus('error')
    setError(source === 'url' ? t('musicStreamError') : t('musicFileError'))
  }

  /** Plays the next found stream; false when none is left. */
  const playNextCandidate = async () => {
    const next = candidates.current.shift()
    if (!next) return false
    await play(next)
    return true
  }

  const playUrl = async () => {
    const link = url.trim()
    if (!/^https?:\/\//i.test(link)) {
      setStatus('error')
      setError(t('musicBadLink'))
      return
    }
    loadedFor.current = link
    resolvedFor.current = null
    candidates.current = []
    setStationName(null)
    wantPlaying.current = true
    const direct = looksLikeStream(link) && !PLAYLIST.test(link)
    if (direct) return void (await play(link))
    // A radio's web page (or a playlist): find its stream first
    if ((await resolve(link)) && (await playNextCandidate())) return
    // Nothing found: maybe the link plays as it is
    await play(link)
  }

  // This stream didn't play: try the next one found, or look for streams
  const onError = async () => {
    const a = audioRef.current
    if (!a || !wantPlaying.current) return
    if (source !== 'url') return fail()
    if (await playNextCandidate()) return
    const link = url.trim()
    if (resolvedFor.current !== link) {
      if ((await resolve(link)) && (await playNextCandidate())) return
    }
    fail()
  }

  const toggle = () => {
    const a = audioRef.current
    if (!a) return
    if (status === 'playing' || status === 'loading') {
      wantPlaying.current = false
      pausedForStory.current = false
      a.pause()
      setStatus('paused')
      return
    }
    if (source === 'url') {
      if (!a.src || loadedFor.current !== url.trim()) return void playUrl()
      a.load() // back to the live point
      return void play()
    }
    if (tracks.length) void play(a.src ? undefined : tracks[index].url)
  }

  const pickFiles = (files: FileList | null) => {
    if (!files?.length) return
    tracks.forEach((tr) => URL.revokeObjectURL(tr.url))
    const next = [...files]
      .filter(
        (f) =>
          f.type.startsWith('audio/') ||
          /\.(mp3|m4a|aac|ogg|wav|flac|opus)$/i.test(f.name),
      )
      .map((f) => ({
        name: f.name.replace(/\.[^.]+$/, ''),
        url: URL.createObjectURL(f),
      }))
    setTracks(next)
    setIndex(0)
    if (next.length) void play(next[0].url)
  }

  const goTo = (i: number) => {
    if (!tracks.length) return
    const n = (i + tracks.length) % tracks.length
    setIndex(n)
    void play(tracks[n].url)
  }

  const switchSource = (s: Source) => {
    if (s === source) return
    audioRef.current?.pause()
    audioRef.current?.removeAttribute('src')
    wantPlaying.current = false
    resolvedFor.current = null
    setStatus('idle')
    setError(null)
    setSource(s)
  }

  const clearFiles = () => {
    audioRef.current?.pause()
    audioRef.current?.removeAttribute('src')
    tracks.forEach((tr) => URL.revokeObjectURL(tr.url))
    wantPlaying.current = false
    setTracks([])
    setStatus('idle')
  }

  const active = status === 'playing' || status === 'loading'
  const VolumeIcon = volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2

  return (
    <section className="rounded-3xl border border-border bg-card p-4 sm:p-6">
      <audio
        ref={audioRef}
        preload="none"
        onPlaying={() => setStatus('playing')}
        onWaiting={() => wantPlaying.current && setStatus('loading')}
        onPause={() =>
          !pausedForStory.current &&
          setStatus((s) => (s === 'error' ? s : 'paused'))
        }
        onError={onError}
        onEnded={() => {
          if (source === 'files' && tracks.length) goTo(index + 1)
          else if (wantPlaying.current) {
            audioRef.current?.load()
            void play()
          }
        }}
      />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="flex items-center gap-2 px-1 text-2xl font-bold text-lake-deep">
          <Music className="size-5 text-terracotta" /> {t('musicTitle')}
        </h3>
        <div
          className="inline-flex rounded-full border border-border bg-background p-0.5"
          role="group"
          aria-label={t('musicSource')}
        >
          {(
            [
              ['url', Link2, t('musicSourceUrl')],
              ['files', FolderOpen, t('musicSourceFiles')],
            ] as const
          ).map(([id, Icon, label]) => (
            <button
              key={id}
              type="button"
              aria-pressed={source === id}
              onClick={() => switchSource(id)}
              className={cn(
                'inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition-colors motion-reduce:transition-none focus-visible:outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50',
                source === id
                  ? 'bg-lake-deep text-white'
                  : 'text-lake-deep hover:bg-lake-deep/5',
              )}
            >
              <Icon className="size-3.5" /> {label}
            </button>
          ))}
        </div>
      </div>
      <p className="mt-1 px-1 text-sm text-muted-foreground">
        {t('musicHint')}
      </p>

      {source === 'url' ? (
        <form
          className="mt-4 space-y-1.5"
          onSubmit={(e) => {
            e.preventDefault()
            void playUrl()
          }}
        >
          <Label htmlFor="music-url">{t('musicUrlLabel')}</Label>
          <div className="flex gap-2">
            <Input
              id="music-url"
              type="url"
              inputMode="url"
              placeholder="https://www.radio-stanica.mk"
              value={url}
              onChange={(e) => {
                setUrl(e.target.value)
                setStationName(null)
              }}
              aria-invalid={status === 'error'}
              aria-describedby="music-url-hint"
            />
            <Button type="submit" disabled={!url.trim()}>
              <Play className="size-4" /> {t('musicPlay')}
            </Button>
          </div>
          <p id="music-url-hint" className="text-xs text-muted-foreground">
            {t('musicUrlHint')}
          </p>
        </form>
      ) : (
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <Button variant="outline" asChild>
            <label className="cursor-pointer">
              <FolderOpen className="size-4" /> {t('musicPickFiles')}
              <input
                type="file"
                accept="audio/*,.mp3,.m4a,.aac,.ogg,.wav,.flac,.opus"
                multiple
                className="sr-only"
                onChange={(e) => {
                  pickFiles(e.target.files)
                  e.target.value = ''
                }}
              />
            </label>
          </Button>
          {tracks.length > 0 && (
            <>
              <span className="text-sm text-muted-foreground">
                {index + 1} / {tracks.length}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFiles}
                aria-label={t('musicClear')}
              >
                <X className="size-4" />
              </Button>
            </>
          )}
        </div>
      )}

      {/* Transport + volume */}
      <div className="mt-4 flex flex-wrap items-center gap-3 rounded-2xl bg-lake-light/50 p-3">
        {source === 'files' && tracks.length > 1 && (
          <Button
            size="icon"
            variant="ghost"
            onClick={() => goTo(index - 1)}
            aria-label={t('musicPrev')}
          >
            <SkipBack className="size-4" />
          </Button>
        )}
        <Button
          size="icon"
          className="rounded-full"
          onClick={toggle}
          disabled={source === 'url' ? !url.trim() : !tracks.length}
          aria-label={active ? t('pause') : t('musicPlay')}
        >
          {status === 'loading' ? (
            <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
          ) : active ? (
            <Pause className="size-4" />
          ) : (
            <Play className="size-4" />
          )}
        </Button>
        {source === 'files' && tracks.length > 1 && (
          <Button
            size="icon"
            variant="ghost"
            onClick={() => goTo(index + 1)}
            aria-label={t('musicNext')}
          >
            <SkipForward className="size-4" />
          </Button>
        )}
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-lake-deep">
            {source === 'files'
              ? (tracks[index]?.name ?? t('musicNoFiles'))
              : url.trim()
                ? (stationName ?? url.replace(/^https?:\/\//i, ''))
                : t('musicNoLink')}
          </p>
          <p className="text-xs text-muted-foreground" aria-live="polite">
            {status === 'loading'
              ? t('musicLoading')
              : status === 'playing' && ducked
                ? t('musicDucked')
                : status === 'playing'
                  ? t('musicPlaying')
                  : t('musicStopped')}
          </p>
        </div>
        {canSetVolume && (
          <label className="flex w-full items-center gap-2 sm:w-44">
            <VolumeIcon className="size-4 shrink-0 text-lake-deep" />
            <span className="sr-only">{t('musicVolume')}</span>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="h-2 flex-1 cursor-pointer accent-terracotta"
            />
          </label>
        )}
      </div>

      {error && (
        <p
          className="mt-3 flex items-start gap-2 text-sm text-terracotta"
          role="alert"
        >
          <TriangleAlert className="mt-0.5 size-4 shrink-0" /> {error}
        </p>
      )}
    </section>
  )
}
