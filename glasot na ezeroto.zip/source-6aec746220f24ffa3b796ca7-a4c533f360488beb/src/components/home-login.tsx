import { getRouteApi, Link, useNavigate } from '@tanstack/react-router'
import { Loader2, LockKeyhole, Ship } from 'lucide-react'
import { useMemo, useState, useSyncExternalStore } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { adminSession } from '@/lib/admin-auth'
import type { BoatInfo } from '@/lib/stop-positions'
import { login, MAIN_ADMIN_USER } from '@/lib/stops.functions'
import { useUiLang } from '@/lib/ui-lang'

const LAST_BOAT_KEY = 'lihnid:last-boat'
const noopSubscribe = () => () => {}

const img = (file: string, w: number) =>
  `/.netlify/images?url=/img/${file}&w=${w}&fm=webp`

const route = getRouteApi('/')

/** Why a boat's tour sent this device back to the login. */
const DEVICE_NOTICES = {
  'no-device':
    'Овој уред не е најавен за бродот. Најавете се со кодот и лозинката на бродот.',
  revoked:
    'Овој уред е одјавен од администраторот. Најавете се повторно ако бродот има слободно место за уред.',
} as const

const deviceLimitError = (name: string, max: number) =>
  `Бродот „${name}“ веќе се користи на најмногу дозволени уреди (${max}). ` +
  'Нов уред може да се најави откако администраторот ќе одјави некој од постојните или ќе го зголеми бројот на уреди.'

const LOGIN_ERRORS = {
  'wrong-login': 'Погрешно корисничко име или лозинка.',
  'not-configured':
    'Главната лозинка не е поставена на серверот (ADMIN_PASSWORD).',
} as const

/**
 * Home page: everyone logs in first. A boat (its code + password) goes to its
 * own tour, already unlocked for editing; "admin" + the main password goes to
 * the main admin.
 */
export function HomeLogin() {
  const { t } = useUiLang()
  const navigate = useNavigate()
  const search = route.useSearch()
  const notice = search.reason ? DEVICE_NOTICES[search.reason] : null
  const [username, setUsername] = useState(search.boat ?? '')
  const [password, setPassword] = useState('')
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  // The boat last used on this device, for a one-tap shortcut to its tour
  const lastBoatRaw = useSyncExternalStore(
    noopSubscribe,
    () => {
      try {
        return localStorage.getItem(LAST_BOAT_KEY)
      } catch {
        return null
      }
    },
    () => null,
  )
  const lastBoat = useMemo(() => {
    try {
      const b = lastBoatRaw ? (JSON.parse(lastBoatRaw) as BoatInfo) : null
      return b?.id && b.name ? b : null
    } catch {
      return null
    }
  }, [lastBoatRaw])

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!username.trim() || !password) return
    setPending(true)
    setError(null)
    try {
      const res = await login({ data: { username, password } })
      if (!res.ok) {
        setError(
          res.error === 'device-limit'
            ? deviceLimitError(res.boat.name, res.max)
            : LOGIN_ERRORS[res.error],
        )
        return
      }
      if (res.role === 'main') {
        adminSession().set(password)
        await navigate({ to: '/tour' })
        return
      }
      adminSession(res.boat.id).set(password)
      try {
        localStorage.setItem(LAST_BOAT_KEY, JSON.stringify(res.boat))
      } catch {
        /* storage unavailable */
      }
      await navigate({ to: '/b/$boat', params: { boat: res.boat.id } })
    } catch {
      setError('Серверот не одговара. Проверете ја врската и обидете се пак.')
    } finally {
      setPending(false)
    }
  }

  return (
    <div className="relative isolate min-h-screen overflow-hidden bg-lake-deep">
      <img
        src={img('hero.png', 1600)}
        srcSet={`${img('hero.png', 800)} 800w, ${img('hero.png', 1600)} 1600w`}
        sizes="100vw"
        alt=""
        className="fixed inset-0 -z-20 size-full object-cover"
      />
      <div className="fixed inset-0 -z-10 bg-gradient-to-b from-lake-deep/70 via-lake-deep/55 to-lake-deep/90" />
      <main className="mx-auto max-w-md px-4 pb-10 pt-10 sm:px-6 sm:pt-16">
        <header className="flex flex-col items-center py-6 text-center text-white sm:py-10">
          <img
            src="/icon.svg"
            alt=""
            className="size-20 rounded-2xl shadow-xl ring-1 ring-white/30 sm:size-24"
          />
          <p className="mt-4 text-balance font-display text-5xl font-bold leading-none tracking-wide drop-shadow-lg sm:text-7xl">
            {t('brand')}
          </p>
          <h1 className="mt-3 text-balance font-display text-2xl font-semibold italic leading-snug drop-shadow-lg sm:text-3xl">
            {t('heroTitle')}
          </h1>
        </header>

        {lastBoat && !(notice && search.boat === lastBoat.id) && (
          <Link
            to="/b/$boat"
            params={{ boat: lastBoat.id }}
            className="mb-4 flex items-center gap-3 rounded-2xl bg-white/90 p-4 text-lake-deep shadow-lg transition-colors hover:bg-white focus-visible:outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 motion-reduce:transition-none"
          >
            <Ship className="size-5 shrink-0 text-terracotta" />
            <span className="min-w-0">
              <span className="block text-xs text-muted-foreground">
                Продолжи кон турата
              </span>
              <span className="block truncate font-semibold">
                {lastBoat.name}
              </span>
            </span>
          </Link>
        )}

        <section
          aria-labelledby="login-title"
          className="rounded-3xl border border-border bg-card p-6 shadow-xl"
        >
          <h2
            id="login-title"
            className="flex items-center gap-2 text-2xl font-bold text-lake-deep"
          >
            <LockKeyhole className="size-5 text-terracotta" /> Најава
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Бродот се најавува со својот код и лозинка и оди на својата тура.
            Главниот админ се најавува со „{MAIN_ADMIN_USER}“.
          </p>
          {notice && !error && (
            <p
              role="status"
              className="mt-4 rounded-xl border border-terracotta/30 bg-terracotta/10 p-3 text-sm text-ink"
            >
              {notice}
            </p>
          )}
          <form onSubmit={submit} className="mt-5 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="login-user">Корисничко име (код на бродот)</Label>
              <Input
                id="login-user"
                autoComplete="username"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="font-mono"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="login-pass">Лозинка</Label>
              <Input
                id="login-pass"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                aria-invalid={!!error}
                aria-describedby={error ? 'login-error' : undefined}
              />
            </div>
            {error && (
              <p
                id="login-error"
                role="alert"
                className="text-sm text-destructive"
              >
                {error}
              </p>
            )}
            <Button
              type="submit"
              className="h-12 w-full rounded-full bg-terracotta text-base hover:bg-terracotta/90"
              disabled={pending || !username.trim() || !password}
            >
              {pending && (
                <Loader2 className="size-4 animate-spin motion-reduce:animate-none" />
              )}
              Најави се
            </Button>
          </form>
        </section>
      </main>
    </div>
  )
}
