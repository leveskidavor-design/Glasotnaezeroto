import { createFileRoute, Navigate } from '@tanstack/react-router'
import { Loader2 } from 'lucide-react'
import { useSyncExternalStore } from 'react'
import { TourApp } from '@/components/tour-app'
import { adminSession } from '@/lib/admin-auth'

/**
 * The main admin's tour (shared values). Reached after logging in as "admin";
 * from here the admin page is one tap away. Without that login: back to /.
 */
export const Route = createFileRoute('/tour')({
  head: () => ({ meta: [{ name: 'robots', content: 'noindex, nofollow' }] }),
  component: MainTour,
})

function MainTour() {
  const session = adminSession()
  const password = useSyncExternalStore(
    session.subscribe,
    session.get,
    session.getServer,
  )
  if (password === undefined)
    return (
      <div
        className="grid min-h-screen place-items-center bg-lake-deep"
        role="status"
      >
        <Loader2 className="size-6 animate-spin text-white motion-reduce:animate-none" />
        <span className="sr-only">Се вчитува…</span>
      </div>
    )
  if (!password) return <Navigate to="/" replace />
  return <TourApp />
}
