import { createFileRoute } from '@tanstack/react-router'

/**
 * Hands the Google Maps browser key to the client at runtime, so it is never
 * baked into the build output. The key must be restricted to this site's
 * domains (HTTP referrers) in Google Cloud Console.
 */
export const Route = createFileRoute('/api/maps-key')({
  server: {
    handlers: {
      GET: () => {
        const key =
          process.env.VITE_GOOGLE_MAPS_API_KEY ??
          process.env.GOOGLE_MAPS_API_KEY
        // Google Maps browser keys look like "AIza" + 35 characters. Anything
        // else would only make Google show an error, so the keyless map is used.
        if (!key || !/^AIza[0-9A-Za-z_-]{35}$/.test(key.trim()))
          return Response.json({ error: 'not-configured' }, { status: 404 })
        return Response.json(
          { key: key.trim() },
          { headers: { 'Cache-Control': 'private, max-age=3600' } },
        )
      },
    },
  },
})
