import { createFileRoute } from '@tanstack/react-router'

/**
 * GET /api/tts?lang=mk&text=…&v=1 → MP3 of one sentence spoken by the
 * language's Microsoft neural voice. Cached in Netlify Blobs and, since the
 * URL contains the exact text, also cached forever by the CDN and browser.
 */
export const Route = createFileRoute('/api/tts')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const { sentenceAudio } = await import('@/lib/tts.server')
        const params = new URL(request.url).searchParams
        const result = await sentenceAudio(
          params.get('lang') ?? '',
          params.get('text') ?? '',
        )
        if (!result.ok)
          return Response.json(
            { error: result.error },
            { status: result.status, headers: { 'Cache-Control': 'no-store' } },
          )
        const forever = 'public, max-age=31536000, immutable'
        return new Response(result.audio.slice().buffer, {
          headers: {
            'Content-Type': 'audio/mpeg',
            'Content-Length': String(result.audio.length),
            'Cache-Control': forever,
            'Netlify-CDN-Cache-Control': forever,
            'X-TTS-Cache': result.cached ? 'hit' : 'miss',
          },
        })
      },
    },
  },
})
