import { createFileRoute, notFound, redirect } from '@tanstack/react-router'
import { TourApp } from '@/components/tour-app'
import { checkBoatDevice, type DeviceCheck } from '@/lib/stops.functions'

/** Main admin password of this tab, so the main admin can open any tour. */
function mainAdminPassword() {
  if (typeof window === 'undefined') return undefined
  try {
    return sessionStorage.getItem('lihnid:admin-password') ?? undefined
  } catch {
    return undefined
  }
}

/**
 * A boat's tour opens only on devices logged in to that boat (each boat has a
 * device limit set by the main admin). Without signal the check is skipped,
 * so a tour started in the harbour keeps working on the lake.
 */
export const Route = createFileRoute('/b/$boat/')({
  beforeLoad: async ({ params }) => {
    let res: DeviceCheck
    try {
      res = await checkBoatDevice({
        data: { boatId: params.boat, adminPassword: mainAdminPassword() },
      })
    } catch {
      return
    }
    if (res.ok) return
    if (res.reason === 'not-found') throw notFound()
    throw redirect({
      to: '/',
      search: { boat: params.boat, reason: res.reason },
    })
  },
  component: TourApp,
})
