import { createFileRoute } from '@tanstack/react-router'
import { AdminPanel } from '@/components/admin-panel'
import { useTourMeta } from '@/lib/stops-context'

export const Route = createFileRoute('/b/$boat/admin')({
  head: () => ({ meta: [{ name: 'robots', content: 'noindex, nofollow' }] }),
  component: BoatAdmin,
})

function BoatAdmin() {
  const { boat: code } = Route.useParams()
  const { boat } = useTourMeta()
  return <AdminPanel boat={boat ?? { id: code, name: code }} />
}
