import { createFileRoute, notFound, Outlet } from '@tanstack/react-router'
import { StopsProvider } from '@/lib/stops-context'
import { BOAT_ID_RE, getTourConfig } from '@/lib/stops.functions'

/** A boat's own tour (/b/<code>), with its positions and texts. */
export const Route = createFileRoute('/b/$boat')({
  loader: async ({ params }) => {
    if (!BOAT_ID_RE.test(params.boat)) throw notFound()
    const config = await getTourConfig({ data: { boatId: params.boat } }).catch(
      () => null,
    )
    if (config && config.boat === null) throw notFound()
    return config
  },
  staleTime: 5 * 60_000,
  component: BoatLayout,
})

function BoatLayout() {
  const config = Route.useLoaderData()
  const { boat } = Route.useParams()
  return (
    <StopsProvider config={config ?? null} cacheKey={boat}>
      <Outlet />
    </StopsProvider>
  )
}
