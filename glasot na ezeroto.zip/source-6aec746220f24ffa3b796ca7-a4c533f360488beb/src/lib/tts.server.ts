/**
 * Server-side narration with Microsoft's neural voices (the "Read aloud"
 * voices of Microsoft Edge, via the msedge-tts package). Every sentence is
 * synthesised once and kept in Netlify Blobs, keyed by voice + exact text,
 * so an edited story automatically gets new audio for the changed sentences
 * only, and already recorded sentences keep working even if the voice
 * service stops answering.
 *
 * Only sentences that occur in the tour's stories (bundled, shared admin
 * texts, or a boat's own texts) are synthesised, so the endpoint can't be
 * used as a general-purpose speech service.
 */
import { createHash } from 'node:crypto'
import { LANGUAGES, STOPS, type Lang } from '@/data/tour'
import { fillBoatName } from '@/lib/stop-positions'

/** Bump when the voice settings change, to record everything again. */
export const TTS_VERSION = '1'
/** Slightly slower than normal, like the device voices (rate 0.95). */
const RATE = '-5%'
export const TTS_TEXT_MAX = 1000

export const normaliseText = (text: string) => text.replace(/\s+/g, ' ').trim()

export function voiceFor(lang: string) {
  return LANGUAGES.find((l) => l.code === lang)?.cloudVoice ?? null
}

const blobKey = (voice: string, text: string) =>
  `v${TTS_VERSION}/${voice}/${createHash('sha256').update(text).digest('hex')}.mp3`

async function store() {
  const { getStore } = await import('@netlify/blobs')
  return getStore('tts-audio')
}

/* ------------------------------------------------------------------ */
/* Which texts may be spoken                                           */
/* ------------------------------------------------------------------ */

let corpus: { text: string; at: number } | null = null

async function loadCorpus(): Promise<string> {
  const shared: string[] = STOPS.flatMap((s) => Object.values(s.story))
  const own: string[] = []
  let names: string[] = []
  try {
    const [{ db }, schema, orm] = await Promise.all([
      import('../../db/index'),
      import('../../db/schema'),
      import('drizzle-orm'),
    ])
    const [content, boatRows, boatTexts] = await Promise.all([
      db
        .select({ value: schema.contentTexts.value })
        .from(schema.contentTexts)
        .where(orm.like(schema.contentTexts.key, 'stop:%:story:%')),
      db
        .select({ id: schema.boats.id, name: schema.boats.name })
        .from(schema.boats),
      db
        .select({
          boatId: schema.boatTexts.boatId,
          value: schema.boatTexts.value,
        })
        .from(schema.boatTexts)
        .where(orm.like(schema.boatTexts.key, 'stop:%:story:%')),
    ])
    shared.push(...content.map((r) => r.value))
    names = boatRows.map((b) => b.name)
    const nameOf = new Map(boatRows.map((b) => [b.id, b.name]))
    own.push(
      ...boatTexts.map((r) => fillBoatName(r.value, nameOf.get(r.boatId))),
    )
  } catch (err) {
    console.error('tts: could not load texts, using bundled ones', err)
  }
  const parts = [...own]
  for (const t of shared) {
    parts.push(t)
    for (const n of names) parts.push(fillBoatName(t, n))
  }
  return normaliseText(parts.join(' \n '))
}

/** True when the sentence is part of some story of the tour. */
async function isTourText(text: string) {
  const fresh = corpus && Date.now() - corpus.at < 5 * 60_000
  if (!fresh) corpus = { text: await loadCorpus(), at: Date.now() }
  if (corpus!.text.includes(text)) return true
  // Maybe it was just edited in the admin: reload once (at most every 10 s)
  if (Date.now() - corpus!.at < 10_000) return false
  corpus = { text: await loadCorpus(), at: Date.now() }
  return corpus.text.includes(text)
}

/* ------------------------------------------------------------------ */
/* Synthesis                                                           */
/* ------------------------------------------------------------------ */

const escapeXml = (s: string) =>
  s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;')

async function synthesise(voice: string, text: string): Promise<Uint8Array> {
  const { MsEdgeTTS, OUTPUT_FORMAT } = await import('msedge-tts')
  const tts = new MsEdgeTTS({
    connectionTimeoutMs: 10_000,
    synthesisTimeoutMs: 20_000,
  })
  try {
    await tts.setMetadata(voice, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3)
    const { audioStream } = tts.toStream(escapeXml(text), { rate: RATE })
    const chunks: Uint8Array[] = []
    await new Promise<void>((resolve, reject) => {
      audioStream.on('data', (c: Uint8Array) => chunks.push(c))
      audioStream.on('end', () => resolve())
      audioStream.on('close', () => resolve())
      audioStream.on('error', reject)
    })
    const size = chunks.reduce((a, c) => a + c.length, 0)
    if (size < 500) throw new Error('voice service returned no audio')
    const out = new Uint8Array(size)
    let at = 0
    for (const c of chunks) {
      out.set(c, at)
      at += c.length
    }
    return out
  } finally {
    tts.close()
  }
}

export type TtsResult =
  | { ok: true; audio: Uint8Array; cached: boolean }
  | { ok: false; status: number; error: string }

/** Recorded audio for one sentence: from Blobs, or synthesised and stored. */
export async function sentenceAudio(
  lang: Lang | string,
  rawText: string,
): Promise<TtsResult> {
  const voice = voiceFor(lang)
  const text = normaliseText(rawText)
  if (!voice) return { ok: false, status: 400, error: 'unknown-language' }
  if (!text || text.length > TTS_TEXT_MAX)
    return { ok: false, status: 400, error: 'bad-text' }

  const key = blobKey(voice, text)
  const s = await store()
  try {
    const hit = await s.get(key, { type: 'arrayBuffer' })
    if (hit) return { ok: true, audio: new Uint8Array(hit), cached: true }
  } catch (err) {
    console.error('tts: blob read failed', err)
  }

  if (!(await isTourText(text)))
    return { ok: false, status: 422, error: 'not-a-tour-text' }

  let audio: Uint8Array
  try {
    audio = await synthesise(voice, text)
  } catch (err) {
    console.error('tts: synthesis failed', err)
    return { ok: false, status: 502, error: 'voice-service-failed' }
  }
  try {
    await s.set(key, audio.slice().buffer)
  } catch (err) {
    console.error('tts: blob write failed', err)
  }
  return { ok: true, audio, cached: false }
}
