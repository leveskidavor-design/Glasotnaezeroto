import { useCallback, useEffect, useRef, useState } from 'react'
import { LANGUAGES, STOPS, type Lang, type Stop } from '@/data/tour'
import { playChime, unlockChime } from '@/lib/chime'
import {
  preloadSentences,
  sentenceAudioUrl,
  sentenceBlob,
  silentWavUrl,
  splitSentences,
  type PreloadProgress,
} from '@/lib/cloud-voice'

/** Wait for the background music to fade out before the chime (ms) */
const MUSIC_FADE_WAIT = 1000

export interface VoiceInfo {
  voice: SpeechSynthesisVoice | null
  /** true when the voice is for the language itself, not a fallback */
  exact: boolean
}

export interface NarrationItem {
  stopId: string
  lang: Lang
}

export interface NowPlaying extends NarrationItem {
  sentenceIndex: number
  sentences: string[]
}

const normalise = (tag: string) => tag.toLowerCase().replace('_', '-')

/** Prefer natural-sounding voices (neural / online / enhanced) over basic ones. */
function voiceScore(v: SpeechSynthesisVoice) {
  const n = v.name.toLowerCase()
  let score = 0
  if (/natural|neural|premium|enhanced|online/.test(n)) score += 4
  if (n.includes('google') || n.includes('microsoft')) score += 2
  if (v.localService) score += 1
  return score
}

export function resolveVoices(): Record<Lang, VoiceInfo> {
  const all =
    typeof window !== 'undefined' && 'speechSynthesis' in window
      ? window.speechSynthesis.getVoices()
      : []
  const result = {} as Record<Lang, VoiceInfo>
  for (const meta of LANGUAGES) {
    let found: VoiceInfo = { voice: null, exact: false }
    for (const prefix of meta.voiceFallbacks) {
      const p = normalise(prefix)
      const v = all
        .filter((voice) => normalise(voice.lang).startsWith(p))
        .sort((a, b) => voiceScore(b) - voiceScore(a))[0]
      if (v) {
        found = {
          voice: v,
          exact: normalise(v.lang).startsWith(
            normalise(meta.speechLang).slice(0, 2),
          ),
        }
        break
      }
    }
    result[meta.code] = found
  }
  return result
}

/**
 * Sequential narration queue. Each story is spoken sentence by sentence
 * (makes pause/resume reliable and avoids Chrome's ~15 s utterance cut-off).
 * Every sentence is first played as an MP3 of the Microsoft neural voice
 * (same in every browser, cached for offline use); if that can't be loaded
 * the device's Web Speech voice reads it, and without any voice the text is
 * shown for a reading-time interval.
 */
export function useNarrator(stops: Stop[] = STOPS) {
  // Latest stop texts (admin-edited stories included) for the queue callbacks
  const stopsRef = useRef(stops)
  useEffect(() => {
    stopsRef.current = stops
  }, [stops])
  const [voices, setVoices] = useState<Record<Lang, VoiceInfo> | null>(null)
  const [nowPlaying, setNowPlaying] = useState<NowPlaying | null>(null)
  const [queue, setQueue] = useState<NarrationItem[]>([])
  const [paused, setPaused] = useState(false)

  const queueRef = useRef<NarrationItem[]>([])
  const currentRef = useRef<NowPlaying | null>(null)
  const pausedRef = useRef(false)
  const generation = useRef(0)
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const voicesRef = useRef<Record<Lang, VoiceInfo> | null>(null)
  /** Stop of the item being told, so the chime plays once per zone */
  const lastStopRef = useRef<string | null>(null)
  /** Plays the Microsoft voice MP3s (one element, unlocked on start) */
  const audioRef = useRef<HTMLAudioElement | null>(null)
  /** The closing chime is playing: music stays down until it ends */
  const [ending, setEnding] = useState(false)
  const [preload, setPreload] = useState<PreloadProgress | null>(null)
  const cancelPreload = useRef<(() => void) | null>(null)

  const hasSpeech = typeof window !== 'undefined' && 'speechSynthesis' in window

  useEffect(() => {
    if (!hasSpeech) {
      const empty = resolveVoices()
      voicesRef.current = empty
      setVoices(empty)
      return
    }
    const update = () => {
      const v = resolveVoices()
      voicesRef.current = v
      setVoices(v)
    }
    update()
    window.speechSynthesis.addEventListener('voiceschanged', update)
    return () => {
      window.speechSynthesis.removeEventListener('voiceschanged', update)
      window.speechSynthesis.cancel()
    }
  }, [hasSpeech])

  const clearTimer = () => {
    if (timer.current) clearTimeout(timer.current)
    timer.current = null
  }

  const syncQueue = () => setQueue([...queueRef.current])

  const playSentence = useCallback(() => {
    const cur = currentRef.current
    if (!cur || pausedRef.current) return
    const gen = generation.current
    const text = cur.sentences[cur.sentenceIndex]

    const advance = () => {
      if (gen !== generation.current || pausedRef.current) return
      const c = currentRef.current
      if (!c) return
      if (c.sentenceIndex + 1 < c.sentences.length) {
        currentRef.current = { ...c, sentenceIndex: c.sentenceIndex + 1 }
        setNowPlaying(currentRef.current)
        playSentence()
      } else {
        // short breath between languages / stops
        timer.current = setTimeout(() => startNext(), 700)
      }
    }

    /** Backup: the device's own voice, else text only */
    const speakOnDevice = () => {
      if (gen !== generation.current || pausedRef.current) return
      const info = voicesRef.current?.[cur.lang]
      if (hasSpeech && info?.voice) {
        const u = new SpeechSynthesisUtterance(text)
        u.voice = info.voice
        u.lang = info.voice.lang
        u.rate = 0.95
        u.onend = advance
        u.onerror = (e) => {
          if (e.error === 'interrupted' || e.error === 'canceled') return
          advance()
        }
        window.speechSynthesis.speak(u)
      } else {
        // Text-only: give people time to read the sentence
        timer.current = setTimeout(advance, Math.max(2500, text.length * 65))
      }
    }

    sentenceAudioUrl(cur.lang, text)
      .then((url) => {
        if (gen !== generation.current || pausedRef.current) return
        const a = (audioRef.current ??= new Audio())
        let done = false
        a.onended = () => {
          if (done) return
          done = true
          advance()
        }
        a.onerror = () => {
          if (done) return
          done = true
          speakOnDevice()
        }
        a.src = url
        a.play().catch((err: unknown) => {
          // AbortError = paused/replaced by us; anything else → device voice
          if (
            done ||
            (err instanceof DOMException && err.name === 'AbortError')
          )
            return
          done = true
          speakOnDevice()
        })
        // Get the next sentence ready while this one plays
        const nextText = cur.sentences[cur.sentenceIndex + 1]
        if (nextText) void sentenceBlob(cur.lang, nextText).catch(() => {})
      })
      .catch(speakOnDevice)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasSpeech])

  const startNext = useCallback(() => {
    clearTimer()
    const next = queueRef.current.shift()
    syncQueue()
    if (!next) {
      currentRef.current = null
      setNowPlaying(null)
      if (lastStopRef.current === null) return setEnding(false)
      // A zone's story is over: the closing chime, then the music returns
      lastStopRef.current = null
      setEnding(true)
      const gen = generation.current
      const wait = playChime('end')
      timer.current = setTimeout(() => {
        if (gen !== generation.current) return
        setEnding(false)
      }, wait)
      return
    }
    setEnding(false)
    const stop = stopsRef.current.find((s) => s.id === next.stopId)
    // Unknown stop, or no story in this language (e.g. a new boat zone)
    if (!stop?.story[next.lang]?.trim()) return startNext()
    currentRef.current = {
      ...next,
      sentenceIndex: 0,
      sentences: splitSentences(stop.story[next.lang]),
    }
    setNowPlaying(currentRef.current)
    // A new zone: music fades out, an attention chime, then the story.
    // The other languages of the same zone follow without a chime.
    if (lastStopRef.current === next.stopId) return playSentence()
    lastStopRef.current = next.stopId
    const gen = generation.current
    timer.current = setTimeout(() => {
      if (gen !== generation.current || pausedRef.current) return
      const wait = playChime('start')
      timer.current = setTimeout(() => {
        if (gen !== generation.current || pausedRef.current) return
        playSentence()
      }, wait)
    }, MUSIC_FADE_WAIT)
  }, [playSentence])

  /** Queue one stop in the given languages (in order). */
  const enqueue = useCallback(
    (stopId: string, langs: Lang[]) => {
      queueRef.current.push(...langs.map((lang) => ({ stopId, lang })))
      syncQueue()
      if (!currentRef.current && !pausedRef.current) startNext()
    },
    [startNext],
  )

  /** Must be called from a user gesture so mobile browsers allow audio. */
  const unlock = useCallback(() => {
    unlockChime()
    // iOS: an <audio> element started from a tap may play later on its own
    const a = (audioRef.current ??= new Audio())
    if (a.paused) {
      a.src = silentWavUrl()
      void a.play().catch(() => {})
    }
    if (!hasSpeech) return
    const u = new SpeechSynthesisUtterance(' ')
    u.volume = 0
    window.speechSynthesis.speak(u)
  }, [hasSpeech])

  const halt = () => {
    generation.current++
    clearTimer()
    if (hasSpeech) window.speechSynthesis.cancel()
    const a = audioRef.current
    if (a) {
      a.onended = null
      a.onerror = null
      a.pause()
    }
  }

  const pause = useCallback(() => {
    pausedRef.current = true
    setPaused(true)
    halt()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const resume = useCallback(() => {
    pausedRef.current = false
    setPaused(false)
    if (currentRef.current) playSentence()
    else startNext()
  }, [playSentence, startNext])

  /** Skip the language currently being spoken. */
  const skip = useCallback(() => {
    halt()
    pausedRef.current = false
    setPaused(false)
    startNext()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startNext])

  /**
   * Downloads the Microsoft voice audio of every story in the chosen
   * languages (in the harbour, while there is signal), so the tour also
   * speaks with that voice without internet on the lake.
   */
  const prepare = useCallback((langs: Lang[]) => {
    cancelPreload.current?.()
    const items = stopsRef.current.flatMap((s) =>
      langs.flatMap((lang) =>
        s.story[lang]?.trim()
          ? splitSentences(s.story[lang]).map((text) => ({ lang, text }))
          : [],
      ),
    )
    cancelPreload.current = preloadSentences(items, setPreload)
  }, [])

  useEffect(() => () => cancelPreload.current?.(), [])

  const reset = useCallback(() => {
    halt()
    cancelPreload.current?.()
    cancelPreload.current = null
    setPreload(null)
    setEnding(false)
    queueRef.current = []
    currentRef.current = null
    lastStopRef.current = null
    pausedRef.current = false
    setPaused(false)
    setQueue([])
    setNowPlaying(null)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return {
    voices,
    hasSpeech,
    nowPlaying,
    queue,
    paused,
    busy: nowPlaying !== null || queue.length > 0 || ending,
    preload,
    prepare,
    enqueue,
    unlock,
    pause,
    resume,
    skip,
    reset,
  }
}
