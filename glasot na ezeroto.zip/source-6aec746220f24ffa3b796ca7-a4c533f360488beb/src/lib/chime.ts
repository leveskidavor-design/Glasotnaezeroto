/**
 * Attention chime played before a zone's story, like an announcement on a
 * ship or at an airport (three soft rising-falling tones). Synthesised with
 * the Web Audio API, so no sound file is needed and it works offline.
 */

let ctx: AudioContext | null = null

function context() {
  if (typeof window === 'undefined') return null
  if (!ctx) {
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext
    if (!Ctor) return null
    ctx = new Ctor()
  }
  return ctx
}

/** Call from a user gesture (e.g. the "start" tap) so mobile allows sound. */
export function unlockChime() {
  const c = context()
  if (c && c.state !== 'running') void c.resume().catch(() => {})
}

/** Notes of the chime: frequency (Hz) and start time (s). */
const START_NOTES: [number, number][] = [
  [659.25, 0], // E5
  [830.61, 0.42], // G#5
  [987.77, 0.84], // B5
]
/** The same bells falling, after a zone's story, before the music returns */
const END_NOTES: [number, number][] = [
  [987.77, 0], // B5
  [830.61, 0.42], // G#5
  [659.25, 0.84], // E5
]
const NOTE_LENGTH = 1.3

/**
 * Plays the chime and returns how long to wait (ms) before going on.
 * `start` (rising) comes before a zone's story, `end` (falling) after it.
 * Returns 0 when sound can't be played.
 */
export function playChime(kind: 'start' | 'end' = 'start'): number {
  const NOTES = kind === 'start' ? START_NOTES : END_NOTES
  const c = context()
  if (!c) return 0
  if (c.state !== 'running') void c.resume().catch(() => {})
  const t0 = c.currentTime + 0.05
  const master = c.createGain()
  master.gain.value = 0.35
  master.connect(c.destination)
  for (const [freq, at] of NOTES) {
    // A bell-like tone: a sine with a quieter octave above, fast attack, slow decay
    for (const [mult, level] of [
      [1, 1],
      [2, 0.25],
    ] as const) {
      const osc = c.createOscillator()
      const gain = c.createGain()
      osc.type = 'sine'
      osc.frequency.value = freq * mult
      const start = t0 + at
      gain.gain.setValueAtTime(0.0001, start)
      gain.gain.exponentialRampToValueAtTime(level, start + 0.02)
      gain.gain.exponentialRampToValueAtTime(0.0001, start + NOTE_LENGTH)
      osc.connect(gain)
      gain.connect(master)
      osc.start(start)
      osc.stop(start + NOTE_LENGTH + 0.05)
    }
  }
  const last = NOTES[NOTES.length - 1][1]
  return Math.round((last + NOTE_LENGTH) * 1000) + 300
}
