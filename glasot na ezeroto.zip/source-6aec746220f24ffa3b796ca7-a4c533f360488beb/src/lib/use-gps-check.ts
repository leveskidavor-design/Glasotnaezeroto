import { useCallback, useEffect, useRef, useState } from 'react'
import type { Position } from '@/lib/use-tour-engine'

export type GpsCheckStatus =
  /** Checking permission / waiting for the first fix */
  | 'checking'
  /** Permission not asked yet — needs a tap to ask */
  | 'prompt'
  /** Location works and a position was received */
  | 'ready'
  /** The user blocked location for this site */
  | 'denied'
  /** Location services are off or no signal */
  | 'unavailable'
  /** No fix in time (e.g. indoors) */
  | 'timeout'
  /** Device or browser has no geolocation */
  | 'unsupported'

/**
 * Checks before the tour whether GPS is switched on and allowed, so the map
 * already has the boat's position when the tour starts. When permission was
 * granted earlier the check runs by itself; otherwise `check()` must be
 * called from a tap so the browser shows its permission prompt.
 */
export function useGpsCheck() {
  const [status, setStatus] = useState<GpsCheckStatus>('checking')
  const [position, setPosition] = useState<(Position & { at: number }) | null>(
    null,
  )
  const busy = useRef(false)

  const check = useCallback(() => {
    if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
      setStatus('unsupported')
      return
    }
    if (busy.current) return
    busy.current = true
    setStatus('checking')
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        busy.current = false
        setPosition({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          at: Date.now(),
        })
        setStatus('ready')
      },
      (err) => {
        busy.current = false
        setStatus(
          err.code === err.PERMISSION_DENIED
            ? 'denied'
            : err.code === err.POSITION_UNAVAILABLE
              ? 'unavailable'
              : 'timeout',
        )
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 10000 },
    )
  }, [])

  // On load: check automatically if permission is already granted, and
  // follow permission changes made in the browser settings.
  useEffect(() => {
    if (!('geolocation' in navigator)) {
      queueMicrotask(() => setStatus('unsupported'))
      return
    }
    let perm: PermissionStatus | null = null
    let cancelled = false
    const apply = (state: PermissionState) => {
      if (cancelled) return
      if (state === 'granted') check()
      else if (state === 'denied') setStatus('denied')
      else setStatus('prompt')
    }
    const onChange = () => perm && apply(perm.state)
    if (navigator.permissions?.query) {
      navigator.permissions
        .query({ name: 'geolocation' })
        .then((p) => {
          perm = p
          p.addEventListener('change', onChange)
          apply(p.state)
        })
        .catch(() => apply('prompt'))
    } else {
      queueMicrotask(() => apply('prompt'))
    }
    return () => {
      cancelled = true
      perm?.removeEventListener('change', onChange)
    }
  }, [check])

  return { status, position, check }
}
