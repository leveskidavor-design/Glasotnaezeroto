import { LANGUAGES, STOPS, type Lang, type Stop } from '@/data/tour'
import { UI_STRINGS, type StringKey } from '@/lib/i18n'
import { EXTRA_STOP_IDS, extraStopDefaults } from '@/lib/stop-positions'

/** Admin text overrides: key → text. Missing keys use the bundled defaults. */
export type TextOverrides = Record<string, string>

export type StopField = 'name' | 'subtitle'

export const stopKey = (stopId: string, field: StopField) =>
  `stop:${stopId}:${field}`
export const storyKey = (stopId: string, lang: Lang) =>
  `stop:${stopId}:story:${lang}`
export const uiKey = (key: StringKey) => `ui:${key}`

export const TEXT_MAX = 6000

/** Every key that may be overridden, with its bundled default text. */
export function defaultTexts(): TextOverrides {
  const out: TextOverrides = {}
  for (const s of [...STOPS, ...EXTRA_STOP_IDS.map(extraStopDefaults)]) {
    out[stopKey(s.id, 'name')] = s.name
    out[stopKey(s.id, 'subtitle')] = s.subtitle
    for (const l of LANGUAGES) out[storyKey(s.id, l.code)] = s.story[l.code]
  }
  for (const k of Object.keys(UI_STRINGS) as StringKey[])
    out[uiKey(k)] = UI_STRINGS[k]
  return out
}

export const ALLOWED_TEXT_KEYS = new Set(Object.keys(defaultTexts()))

/** Applies text overrides to stops (positions are applied separately). */
export function applyStopTexts(stops: Stop[], texts: TextOverrides): Stop[] {
  if (!Object.keys(texts).length) return stops
  return stops.map((s) => {
    const story = { ...s.story }
    for (const l of LANGUAGES) {
      const v = texts[storyKey(s.id, l.code)]
      if (v?.trim()) story[l.code] = v
    }
    return {
      ...s,
      name: texts[stopKey(s.id, 'name')]?.trim() || s.name,
      subtitle: texts[stopKey(s.id, 'subtitle')]?.trim() || s.subtitle,
      story,
    }
  })
}
