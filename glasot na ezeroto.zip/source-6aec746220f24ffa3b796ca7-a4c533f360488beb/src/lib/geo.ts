const R = 6371000

const rad = (d: number) => (d * Math.PI) / 180

/** Great-circle distance in metres. */
export function distanceM(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
) {
  const dLat = rad(lat2 - lat1)
  const dLng = rad(lng2 - lng1)
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(a))
}

export function formatDistance(m: number) {
  return m < 1000
    ? `${Math.round(m / 10) * 10} m`
    : `${(m / 1000).toFixed(1)} km`
}

/** Precomputed cumulative lengths so a point can be found by distance along a polyline. */
export function buildPath(points: [number, number][]) {
  const cumulative = [0]
  for (let i = 1; i < points.length; i++) {
    const [a, b] = [points[i - 1], points[i]]
    cumulative.push(cumulative[i - 1] + distanceM(a[0], a[1], b[0], b[1]))
  }
  const total = cumulative[cumulative.length - 1]

  function pointAt(d: number): [number, number] {
    const dist = Math.max(0, Math.min(total, d))
    let i = 1
    while (i < cumulative.length - 1 && cumulative[i] < dist) i++
    const seg = cumulative[i] - cumulative[i - 1] || 1
    const f = (dist - cumulative[i - 1]) / seg
    const [a, b] = [points[i - 1], points[i]]
    return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f]
  }

  return { total, pointAt }
}

/** Initial bearing from point 1 to point 2, in degrees clockwise from north. */
export function bearingDeg(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
) {
  const y = Math.sin(rad(lng2 - lng1)) * Math.cos(rad(lat2))
  const x =
    Math.cos(rad(lat1)) * Math.sin(rad(lat2)) -
    Math.sin(rad(lat1)) * Math.cos(rad(lat2)) * Math.cos(rad(lng2 - lng1))
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360
}
