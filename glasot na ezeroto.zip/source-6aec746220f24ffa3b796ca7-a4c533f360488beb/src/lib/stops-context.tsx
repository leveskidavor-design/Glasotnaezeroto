import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useSyncExternalStore,
} from 'react'
import { STOPS, type Stop } from '@/data/tour'
import { applyStopTexts, type TextOverrides } from '@/lib/content-texts'
import {
  fillBoatName,
  mergeStops,
  type BoatInfo,
  type StopPosition,
  type TourConfig,
} from '@/lib/stop-positions'

const STORAGE_PREFIX = 'lihnid:tour-config'

interface Meta {
  boat: BoatInfo | null
  /** Global layer under a boat's own edits (empty for the main config) */
  baseTexts: TextOverrides
  baseStops: StopPosition[]
}

const NO_TEXTS: TextOverrides = {}
const StopsContext = createContext<Stop[]>(STOPS)
const TextsContext = createContext<TextOverrides>(NO_TEXTS)
const MetaContext = createContext<Meta>({
  boat: null,
  baseTexts: NO_TEXTS,
  baseStops: [],
})

const noopSubscribe = () => () => {}

/**
 * Provides the stops with admin-saved positions and texts applied, and the
 * boat's name filled in for {brod}. The latest config is cached on the device
 * (per boat) so the tour keeps working when the boat has no signal.
 */
export function StopsProvider({
  config,
  cacheKey,
  children,
}: {
  /** From the server; null when it could not be reached */
  config: TourConfig | null
  /** Boat id, so each boat keeps its own offline copy */
  cacheKey?: string
  children: React.ReactNode
}) {
  const storageKey = cacheKey ? `${STORAGE_PREFIX}:${cacheKey}` : STORAGE_PREFIX
  const cachedRaw = useSyncExternalStore(
    noopSubscribe,
    () => {
      try {
        return localStorage.getItem(storageKey)
      } catch {
        return null
      }
    },
    () => null,
  )

  useEffect(() => {
    if (!config) return
    try {
      localStorage.setItem(storageKey, JSON.stringify(config))
    } catch {
      /* storage unavailable */
    }
  }, [config, storageKey])

  // Server data when available, otherwise the copy cached on this device
  const effective = useMemo<TourConfig | null>(() => {
    if (config) return config
    try {
      return cachedRaw ? (JSON.parse(cachedRaw) as TourConfig) : null
    } catch {
      return null
    }
  }, [config, cachedRaw])

  const texts = effective?.texts ?? NO_TEXTS
  const boat = effective?.boat ?? null
  const stops = useMemo(() => {
    const merged = applyStopTexts(mergeStops(effective?.stops ?? null), texts)
    if (!boat) return merged
    return merged.map((s) => ({
      ...s,
      name: fillBoatName(s.name, boat.name),
      subtitle: fillBoatName(s.subtitle, boat.name),
      story: Object.fromEntries(
        Object.entries(s.story).map(([l, v]) => [l, fillBoatName(v, boat.name)]),
      ) as Stop['story'],
    }))
  }, [effective, texts, boat])

  const meta = useMemo<Meta>(
    () => ({
      boat,
      baseTexts: effective?.baseTexts ?? NO_TEXTS,
      baseStops: effective?.baseStops ?? [],
    }),
    [boat, effective],
  )

  return (
    <MetaContext.Provider value={meta}>
      <TextsContext.Provider value={texts}>
        <StopsContext.Provider value={stops}>{children}</StopsContext.Provider>
      </TextsContext.Provider>
    </MetaContext.Provider>
  )
}

/** Stops with their current (possibly admin-edited) positions and texts */
export const useStops = () => useContext(StopsContext)

/** Admin-edited texts, raw ({brod} not filled in) */
export const useTextOverrides = () => useContext(TextsContext)

/** The current boat (null outside a boat's pages) and the global layer */
export const useTourMeta = () => useContext(MetaContext)
