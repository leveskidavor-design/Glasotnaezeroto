import { act, renderHook } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { STOPS } from '@/data/tour'

const chime = vi.fn((_kind?: 'start' | 'end') => 2000)
vi.mock('@/lib/chime', () => ({
  playChime: (kind?: 'start' | 'end') => chime(kind),
  unlockChime: () => {},
}))

const cloudFails = { value: false }
vi.mock('@/lib/cloud-voice', async (orig) => {
  const real = await orig<typeof import('@/lib/cloud-voice')>()
  return {
    ...real,
    sentenceAudioUrl: vi.fn(async (_l: string, text: string) => {
      if (cloudFails.value) throw new Error('offline')
      return `blob:${text.slice(0, 10)}`
    }),
    sentenceBlob: vi.fn(async () => new Blob()),
    silentWavUrl: () => 'blob:silent',
    preloadSentences: () => () => {},
  }
})

/** Fake <audio>: "plays" for 1 s, then ends. */
const played: string[] = []
class FakeAudio {
  src = ''
  paused = true
  onended: (() => void) | null = null
  onerror: (() => void) | null = null
  play() {
    this.paused = false
    if (this.src !== 'blob:silent') played.push(this.src)
    setTimeout(() => {
      this.paused = true
      this.onended?.()
    }, 1000)
    return Promise.resolve()
  }
  pause() {
    this.paused = true
  }
}

const { useNarrator } = await import('@/lib/use-narrator')

beforeEach(() => {
  vi.useFakeTimers()
  vi.stubGlobal('Audio', FakeAudio)
  played.length = 0
  chime.mockClear()
  cloudFails.value = false
})
afterEach(() => {
  vi.useRealTimers()
  vi.unstubAllGlobals()
})

const stop = { ...STOPS[0], story: { ...STOPS[0].story, en: 'One. Two.' } }

describe('useNarrator', () => {
  it('chimes, speaks with the Microsoft voice, chimes again, then frees the music', async () => {
    const { result } = renderHook(() => useNarrator([stop]))
    act(() => result.current.unlock())
    act(() => result.current.enqueue(stop.id, ['en']))
    expect(result.current.busy).toBe(true)

    // music fade (1 s) → opening chime (2 s) → two sentences (1 s each)
    await act(() => vi.advanceTimersByTimeAsync(1000))
    expect(chime).toHaveBeenLastCalledWith('start')
    await act(() => vi.advanceTimersByTimeAsync(2000))
    await act(() => vi.advanceTimersByTimeAsync(2100))
    expect(played).toEqual(['blob:One.', 'blob:Two.'])

    // short breath, then the closing chime; music stays down meanwhile
    await act(() => vi.advanceTimersByTimeAsync(800))
    expect(chime).toHaveBeenLastCalledWith('end')
    expect(result.current.nowPlaying).toBeNull()
    expect(result.current.busy).toBe(true)

    await act(() => vi.advanceTimersByTimeAsync(2000))
    expect(result.current.busy).toBe(false)
  })

  it('falls back to text timing when the voice audio cannot be loaded', async () => {
    cloudFails.value = true
    const { result } = renderHook(() => useNarrator([stop]))
    act(() => result.current.enqueue(stop.id, ['en']))
    await act(() => vi.advanceTimersByTimeAsync(3000))
    expect(result.current.nowPlaying?.sentenceIndex).toBe(0)
    await act(() => vi.advanceTimersByTimeAsync(2600))
    expect(result.current.nowPlaying?.sentenceIndex).toBe(1)
    expect(played).toEqual([])
  })
})
