import { useCallback } from 'react'
import { t as defaultT, type StringKey } from '@/lib/i18n'
import { uiKey } from '@/lib/content-texts'
import { fillBoatName } from '@/lib/stop-positions'
import { useTextOverrides, useTourMeta } from '@/lib/stops-context'

/**
 * Interface strings (Macedonian only). Labels edited on /admin replace the
 * bundled defaults from src/lib/i18n.ts; {brod} becomes the boat's name.
 */
export function useUiLang(): { t: (key: StringKey) => string } {
  const texts = useTextOverrides()
  const { boat } = useTourMeta()
  const t = useCallback(
    (key: StringKey) =>
      fillBoatName(texts[uiKey(key)]?.trim() || defaultT(key), boat?.name),
    [texts, boat],
  )
  return { t }
}
