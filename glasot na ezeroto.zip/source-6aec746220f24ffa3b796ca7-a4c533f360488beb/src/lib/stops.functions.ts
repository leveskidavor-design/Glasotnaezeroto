import {
  createHash,
  randomBytes,
  randomUUID,
  scryptSync,
  timingSafeEqual,
} from 'node:crypto'
import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import {
  ALLOWED_TEXT_KEYS,
  TEXT_MAX,
  type TextOverrides,
} from '@/lib/content-texts'
import {
  ALL_STOP_IDS,
  EXTRA_STOP_IDS,
  isExtraStop,
  MAX_EXTRA_STOPS,
  RADIUS_MAX,
  RADIUS_MIN,
  type BoatInfo,
  type StopPosition,
  type TourConfig,
} from '@/lib/stop-positions'

const STOP_IDS = ALL_STOP_IDS as [string, ...string[]]

const positionSchema = z.object({
  stopId: z.enum(STOP_IDS),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  radius: z.number().int().min(RADIUS_MIN).max(RADIUS_MAX),
})

const passwordSchema = z.string().min(1).max(200)
/** Boat URL code: lowercase letters, digits and dashes */
export const BOAT_ID_RE = /^[a-z0-9](?:[a-z0-9-]{0,38}[a-z0-9])?$/
const boatIdSchema = z.string().regex(BOAT_ID_RE)
const boatNameSchema = z.string().trim().min(1).max(80)
const boatPasswordSchema = z.string().min(6).max(200)
/** Upper bound for a boat's device limit */
export const DEVICES_CAP = 100
const maxDevicesSchema = z.number().int().min(1).max(DEVICES_CAP)

/** Who is editing: the main admin (no boatId) or one boat. */
const authSchema = { password: passwordSchema, boatId: boatIdSchema.optional() }

type AuthError = 'wrong-password' | 'not-configured' | 'not-found'
type AuthResult = { ok: true } | { ok: false; error: AuthError }

const sha = (s: string) => createHash('sha256').update(s, 'utf8').digest()
const slowDown = () => new Promise((r) => setTimeout(r, 800))

function hashPassword(password: string) {
  const salt = randomBytes(16)
  const hash = scryptSync(password, salt, 32)
  return `${salt.toString('hex')}:${hash.toString('hex')}`
}

function verifyHash(password: string, stored: string) {
  const [saltHex, hashHex] = stored.split(':')
  if (!saltHex || !hashHex) return false
  const expected = Buffer.from(hashHex, 'hex')
  const actual = scryptSync(
    password,
    Buffer.from(saltHex, 'hex'),
    expected.length,
  )
  return timingSafeEqual(actual, expected)
}

const isMainPassword = (password: string) => {
  const expected = process.env.ADMIN_PASSWORD
  return !!expected && timingSafeEqual(sha(password), sha(expected))
}

async function loadDb() {
  const [{ db }, schema, orm] = await Promise.all([
    import('../../db/index'),
    import('../../db/schema'),
    import('drizzle-orm'),
  ])
  return { db, ...schema, orm }
}

/** Main admin only. */
async function checkMain(password: string): Promise<AuthResult> {
  if (!process.env.ADMIN_PASSWORD) return { ok: false, error: 'not-configured' }
  if (isMainPassword(password)) return { ok: true }
  await slowDown()
  return { ok: false, error: 'wrong-password' }
}

/**
 * Without boatId: main admin. With boatId: that boat's password, or the main
 * admin password (so the main admin can edit any boat).
 */
async function checkAccess(
  password: string,
  boatId?: string,
): Promise<AuthResult> {
  if (!boatId) return checkMain(password)
  const { db, boats, orm } = await loadDb()
  const [boat] = await db.select().from(boats).where(orm.eq(boats.id, boatId))
  if (!boat) {
    await slowDown()
    return { ok: false, error: 'not-found' }
  }
  if (isMainPassword(password) || verifyHash(password, boat.passwordHash))
    return { ok: true }
  await slowDown()
  return { ok: false, error: 'wrong-password' }
}

const toPositions = (
  rows: { stopId: string; lat: number; lng: number; radius: number }[],
): StopPosition[] =>
  rows
    .filter((r) => STOP_IDS.includes(r.stopId))
    .map(({ stopId, lat, lng, radius }) => ({ stopId, lat, lng, radius }))

const toTexts = (rows: { key: string; value: string }[]): TextOverrides => {
  const out: TextOverrides = {}
  for (const r of rows) if (ALLOWED_TEXT_KEYS.has(r.key)) out[r.key] = r.value
  return out
}

const mergePositions = (base: StopPosition[], over: StopPosition[]) => {
  const map = new Map(base.map((p) => [p.stopId, p]))
  for (const p of over) map.set(p.stopId, p)
  return [...map.values()]
}

/**
 * Tour config: global positions/texts, with a boat's own layer on top when
 * boatId is given. `boat` is null when the boat doesn't exist. Returns null
 * when the database can't be read (the device cache is used then).
 */
export const getTourConfig = createServerFn({ method: 'GET' })
  .validator(z.object({ boatId: boatIdSchema.optional() }).optional())
  .handler(async ({ data }): Promise<TourConfig | null> => {
    try {
      const d = await loadDb()
      const safe = <T>(q: Promise<T[]>) =>
        q.catch((err: unknown) => {
          console.error('Could not read tour data', err)
          return [] as T[]
        })
      const [posRows, textRows] = await Promise.all([
        d.db.select().from(d.stopPositions),
        safe(d.db.select().from(d.contentTexts)),
      ])
      // Extra zones belong to a single boat, never to the shared layer
      const baseStops = toPositions(posRows).filter(
        (p) => !isExtraStop(p.stopId),
      )
      const baseTexts = toTexts(textRows)
      const boatId = data?.boatId
      if (!boatId) return { stops: baseStops, texts: baseTexts }

      const [boat] = await d.db
        .select({ id: d.boats.id, name: d.boats.name })
        .from(d.boats)
        .where(d.orm.eq(d.boats.id, boatId))
      if (!boat) return { stops: baseStops, texts: baseTexts, boat: null }
      const [bPos, bTexts] = await Promise.all([
        d.db
          .select()
          .from(d.boatStopPositions)
          .where(d.orm.eq(d.boatStopPositions.boatId, boatId)),
        d.db
          .select()
          .from(d.boatTexts)
          .where(d.orm.eq(d.boatTexts.boatId, boatId)),
      ])
      return {
        stops: mergePositions(baseStops, toPositions(bPos)),
        texts: { ...baseTexts, ...toTexts(bTexts) },
        baseStops,
        baseTexts,
        boat,
      }
    } catch (err) {
      console.error('Could not read tour config', err)
      return null
    }
  })

/** Username on the home login that means the main admin. */
export const MAIN_ADMIN_USER = 'admin'

type LoginResult =
  | { ok: true; role: 'main' }
  | { ok: true; role: 'boat'; boat: BoatInfo }
  | { ok: false; error: 'wrong-login' | 'not-configured' }
  | { ok: false; error: 'device-limit'; boat: BoatInfo; max: number }

/* ------------------------------------------------------------------ */
/* Devices of a boat                                                   */
/* ------------------------------------------------------------------ */

const deviceCookie = (boatId: string) => `lihnid_dev_${boatId}`
const tokenHash = (token: string) =>
  createHash('sha256').update(token, 'utf8').digest('hex')

/** Short readable name of the device from its User-Agent. */
function deviceLabel(ua: string) {
  const os = /iPad/.test(ua)
    ? 'iPad'
    : /iPhone|iPod/.test(ua)
      ? 'iPhone'
      : /Android/.test(ua)
        ? /Mobile/.test(ua)
          ? 'Android телефон'
          : 'Android таблет'
        : /Windows/.test(ua)
          ? 'Windows'
          : /Macintosh|Mac OS X/.test(ua)
            ? 'Mac'
            : /CrOS/.test(ua)
              ? 'Chromebook'
              : /Linux/.test(ua)
                ? 'Linux'
                : 'Уред'
  const browser = /EdgA?\/|Edg\//.test(ua)
    ? 'Edge'
    : /SamsungBrowser/.test(ua)
      ? 'Samsung Internet'
      : /OPR\/|Opera/.test(ua)
        ? 'Opera'
        : /Firefox|FxiOS/.test(ua)
          ? 'Firefox'
          : /Chrome|CriOS/.test(ua)
            ? 'Chrome'
            : /Safari/.test(ua)
              ? 'Safari'
              : ''
  return browser ? `${os} · ${browser}` : os
}

/** This browser's registered device row for the boat, from its cookie. */
async function currentDevice(boatId: string) {
  const { getCookie } = await import('@tanstack/react-start/server')
  const token = getCookie(deviceCookie(boatId))
  if (!token) return { token: null, device: null }
  const d = await loadDb()
  const [device] = await d.db
    .select({ id: d.boatDevices.id })
    .from(d.boatDevices)
    .where(
      d.orm.and(
        d.orm.eq(d.boatDevices.boatId, boatId),
        d.orm.eq(d.boatDevices.tokenHash, tokenHash(token)),
      ),
    )
  return { token, device: device ?? null }
}

/**
 * Lets this browser into the boat's tour: reuses its registration, or
 * registers it when the boat still has a free device slot.
 */
async function registerDevice(boat: {
  id: string
  maxDevices: number
}): Promise<boolean> {
  const d = await loadDb()
  const { eq } = d.orm
  const now = new Date()
  const { device } = await currentDevice(boat.id)
  if (device) {
    await d.db
      .update(d.boatDevices)
      .set({ lastSeenAt: now })
      .where(eq(d.boatDevices.id, device.id))
    return true
  }
  const [{ count }] = await d.db
    .select({ count: d.orm.count() })
    .from(d.boatDevices)
    .where(eq(d.boatDevices.boatId, boat.id))
  if (count >= boat.maxDevices) return false

  const { getRequestHeader, setCookie } =
    await import('@tanstack/react-start/server')
  const token = randomBytes(32).toString('base64url')
  await d.db.insert(d.boatDevices).values({
    id: randomUUID(),
    boatId: boat.id,
    tokenHash: tokenHash(token),
    label: deviceLabel(getRequestHeader('user-agent') ?? '').slice(0, 80),
    createdAt: now,
    lastSeenAt: now,
  })
  setCookie(deviceCookie(boat.id), token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    // Browsers keep cookies at most ~400 days
    maxAge: 400 * 24 * 3600,
  })
  return true
}

export type DeviceCheck =
  { ok: true } | { ok: false; reason: 'no-device' | 'revoked' | 'not-found' }

/**
 * May this browser open the boat's tour? Only devices logged in to the boat
 * (counted against its limit); the main admin's password also works.
 */
export const checkBoatDevice = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      boatId: boatIdSchema,
      adminPassword: passwordSchema.optional(),
    }),
  )
  .handler(async ({ data }): Promise<DeviceCheck> => {
    const d = await loadDb()
    const [boat] = await d.db
      .select({ id: d.boats.id })
      .from(d.boats)
      .where(d.orm.eq(d.boats.id, data.boatId))
    if (!boat) return { ok: false, reason: 'not-found' }
    if (data.adminPassword && isMainPassword(data.adminPassword))
      return { ok: true }
    const { token, device } = await currentDevice(data.boatId)
    if (!token) return { ok: false, reason: 'no-device' }
    if (!device) {
      const { deleteCookie } = await import('@tanstack/react-start/server')
      deleteCookie(deviceCookie(data.boatId), { path: '/' })
      return { ok: false, reason: 'revoked' }
    }
    await d.db
      .update(d.boatDevices)
      .set({ lastSeenAt: new Date() })
      .where(d.orm.eq(d.boatDevices.id, device.id))
    return { ok: true }
  })

/**
 * Logs this browser out of a boat: its device row is removed, so the slot is
 * free for another device, and the device cookie is deleted.
 */
export const logoutBoatDevice = createServerFn({ method: 'POST' })
  .validator(z.object({ boatId: boatIdSchema }))
  .handler(async ({ data }) => {
    const { device } = await currentDevice(data.boatId)
    if (device) {
      const d = await loadDb()
      await d.db
        .delete(d.boatDevices)
        .where(d.orm.eq(d.boatDevices.id, device.id))
    }
    const { deleteCookie } = await import('@tanstack/react-start/server')
    deleteCookie(deviceCookie(data.boatId), { path: '/' })
    return { ok: true as const }
  })

/**
 * Home-page login: "admin" + main password opens the main admin; a boat's
 * code + its password opens that boat. Unknown boats and wrong passwords give
 * the same error.
 */
export const login = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      username: z.string().trim().toLowerCase().min(1).max(40),
      password: passwordSchema,
    }),
  )
  .handler(async ({ data }): Promise<LoginResult> => {
    if (data.username === MAIN_ADMIN_USER) {
      const auth = await checkMain(data.password)
      if (auth.ok) return { ok: true, role: 'main' }
      return {
        ok: false,
        error:
          auth.error === 'not-configured' ? 'not-configured' : 'wrong-login',
      }
    }
    if (BOAT_ID_RE.test(data.username)) {
      const { db, boats, orm } = await loadDb()
      const [boat] = await db
        .select()
        .from(boats)
        .where(orm.eq(boats.id, data.username))
      if (boat && verifyHash(data.password, boat.passwordHash)) {
        const info = { id: boat.id, name: boat.name }
        if (!(await registerDevice(boat)))
          return {
            ok: false,
            error: 'device-limit',
            boat: info,
            max: boat.maxDevices,
          }
        return { ok: true, role: 'boat', boat: info }
      }
    }
    await slowDown()
    return { ok: false, error: 'wrong-login' }
  })

export const verifyAdminPassword = createServerFn({ method: 'POST' })
  .validator(z.object(authSchema))
  .handler(({ data }) => checkAccess(data.password, data.boatId))

export const saveTourConfig = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      ...authSchema,
      stops: z.array(positionSchema).min(1).max(STOP_IDS.length),
    }),
  )
  .handler(async ({ data }): Promise<AuthResult> => {
    const auth = await checkAccess(data.password, data.boatId)
    if (!auth.ok) return auth
    const d = await loadDb()
    const now = new Date()
    if (data.boatId) {
      const boatId = data.boatId
      const { and, eq, inArray } = d.orm
      // Extra zones are created/removed with addBoatStop/deleteBoatStop;
      // saving only moves the ones that still exist.
      const existing = await d.db
        .select({ stopId: d.boatStopPositions.stopId })
        .from(d.boatStopPositions)
        .where(
          and(
            eq(d.boatStopPositions.boatId, boatId),
            inArray(d.boatStopPositions.stopId, EXTRA_STOP_IDS),
          ),
        )
      const extras = new Set(existing.map((r) => r.stopId))
      const stops = data.stops.filter(
        (s) => !isExtraStop(s.stopId) || extras.has(s.stopId),
      )
      const ids = stops.map((s) => s.stopId)
      await d.db
        .delete(d.boatStopPositions)
        .where(
          and(
            eq(d.boatStopPositions.boatId, boatId),
            inArray(d.boatStopPositions.stopId, ids),
          ),
        )
      await d.db
        .insert(d.boatStopPositions)
        .values(stops.map((s) => ({ ...s, boatId, updatedAt: now })))
      return { ok: true }
    }
    const shared = data.stops.filter((s) => !isExtraStop(s.stopId))
    if (!shared.length) return { ok: true }
    await d.db
      .insert(d.stopPositions)
      .values(shared.map((s) => ({ ...s, updatedAt: now })))
      .onConflictDoUpdate({
        target: d.stopPositions.stopId,
        set: {
          lat: d.orm.sql`excluded.lat`,
          lng: d.orm.sql`excluded.lng`,
          radius: d.orm.sql`excluded.radius`,
          updatedAt: d.orm.sql`excluded.updated_at`,
        },
      })
    return { ok: true }
  })

type AddStopResult =
  { ok: true; stopId: string } | { ok: false; error: AuthError | 'limit' }

/** A boat adds one of its own extra zones (at most MAX_EXTRA_STOPS). */
export const addBoatStop = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      password: passwordSchema,
      boatId: boatIdSchema,
      name: z.string().trim().min(1).max(120),
      lat: z.number().min(-90).max(90),
      lng: z.number().min(-180).max(180),
      radius: z.number().int().min(RADIUS_MIN).max(RADIUS_MAX),
    }),
  )
  .handler(async ({ data }): Promise<AddStopResult> => {
    const auth = await checkAccess(data.password, data.boatId)
    if (!auth.ok) return auth
    const d = await loadDb()
    const { and, eq, inArray } = d.orm
    const rows = await d.db
      .select({ stopId: d.boatStopPositions.stopId })
      .from(d.boatStopPositions)
      .where(
        and(
          eq(d.boatStopPositions.boatId, data.boatId),
          inArray(d.boatStopPositions.stopId, EXTRA_STOP_IDS),
        ),
      )
    const used = new Set(rows.map((r) => r.stopId))
    const stopId = EXTRA_STOP_IDS.find((id) => !used.has(id))
    if (!stopId || used.size >= MAX_EXTRA_STOPS)
      return { ok: false, error: 'limit' }
    const now = new Date()
    await d.db.insert(d.boatStopPositions).values({
      boatId: data.boatId,
      stopId,
      lat: data.lat,
      lng: data.lng,
      radius: data.radius,
      updatedAt: now,
    })
    // Fresh start for the texts of a reused slot
    await d.db
      .delete(d.boatTexts)
      .where(
        and(
          eq(d.boatTexts.boatId, data.boatId),
          d.orm.like(d.boatTexts.key, `stop:${stopId}:%`),
        ),
      )
    await d.db.insert(d.boatTexts).values({
      boatId: data.boatId,
      key: `stop:${stopId}:name`,
      value: data.name,
      updatedAt: now,
    })
    return { ok: true, stopId }
  })

/** A boat removes one of its extra zones, with its texts. */
export const deleteBoatStop = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      password: passwordSchema,
      boatId: boatIdSchema,
      stopId: z.enum(EXTRA_STOP_IDS as [string, ...string[]]),
    }),
  )
  .handler(async ({ data }): Promise<AuthResult> => {
    const auth = await checkAccess(data.password, data.boatId)
    if (!auth.ok) return auth
    const d = await loadDb()
    const { and, eq, like } = d.orm
    await d.db
      .delete(d.boatStopPositions)
      .where(
        and(
          eq(d.boatStopPositions.boatId, data.boatId),
          eq(d.boatStopPositions.stopId, data.stopId),
        ),
      )
    await d.db
      .delete(d.boatTexts)
      .where(
        and(
          eq(d.boatTexts.boatId, data.boatId),
          like(d.boatTexts.key, `stop:${data.stopId}:%`),
        ),
      )
    return { ok: true }
  })

/** Main admin: back to bundled positions. Boat: back to the global positions. */
export const resetTourConfig = createServerFn({ method: 'POST' })
  .validator(z.object(authSchema))
  .handler(async ({ data }): Promise<AuthResult> => {
    const auth = await checkAccess(data.password, data.boatId)
    if (!auth.ok) return auth
    const d = await loadDb()
    if (data.boatId)
      // The boat's extra zones stay; only its moves of shared stops go
      await d.db
        .delete(d.boatStopPositions)
        .where(
          d.orm.and(
            d.orm.eq(d.boatStopPositions.boatId, data.boatId),
            d.orm.notInArray(d.boatStopPositions.stopId, EXTRA_STOP_IDS),
          ),
        )
    else {
      await d.db.delete(d.stopPositions)
      await d.db.delete(d.tourRoute)
    }
    return { ok: true }
  })

/**
 * Replaces the saved texts of one area: `stop` (stop names, subtitles and
 * stories) or `ui` (interface labels). Send only texts that differ from the
 * layer below; everything not sent falls back to it.
 */
export const saveTexts = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      ...authSchema,
      scope: z.enum(['stop', 'ui']),
      texts: z
        .record(z.string(), z.string().max(TEXT_MAX))
        .refine((t) => Object.keys(t).length <= ALLOWED_TEXT_KEYS.size),
    }),
  )
  .handler(async ({ data }): Promise<AuthResult> => {
    const auth = await checkAccess(data.password, data.boatId)
    if (!auth.ok) return auth
    const entries = Object.entries(data.texts).filter(
      ([k, v]) =>
        k.startsWith(`${data.scope}:`) && ALLOWED_TEXT_KEYS.has(k) && v.trim(),
    )
    const d = await loadDb()
    const { and, eq, like } = d.orm
    const now = new Date()
    if (data.boatId) {
      const boatId = data.boatId
      await d.db
        .delete(d.boatTexts)
        .where(
          and(
            eq(d.boatTexts.boatId, boatId),
            like(d.boatTexts.key, `${data.scope}:%`),
          ),
        )
      if (entries.length)
        await d.db.insert(d.boatTexts).values(
          entries.map(([key, value]) => ({
            boatId,
            key,
            value: value.trim(),
            updatedAt: now,
          })),
        )
      return { ok: true }
    }
    await d.db
      .delete(d.contentTexts)
      .where(like(d.contentTexts.key, `${data.scope}:%`))
    if (entries.length)
      await d.db.insert(d.contentTexts).values(
        entries.map(([key, value]) => ({
          key,
          value: value.trim(),
          updatedAt: now,
        })),
      )
    return { ok: true }
  })

/* ------------------------------------------------------------------ */
/* Boats (main admin)                                                  */
/* ------------------------------------------------------------------ */

export type BoatDevice = {
  id: string
  label: string
  createdAt: string
  lastSeenAt: string
}

export type BoatListItem = BoatInfo & {
  createdAt: string
  maxDevices: number
  devices: BoatDevice[]
}

type BoatsResult =
  { ok: true; boats: BoatListItem[] } | { ok: false; error: AuthError }

export const listBoats = createServerFn({ method: 'POST' })
  .validator(z.object({ password: passwordSchema }))
  .handler(async ({ data }): Promise<BoatsResult> => {
    const auth = await checkMain(data.password)
    if (!auth.ok) return auth
    const d = await loadDb()
    const [rows, devices] = await Promise.all([
      d.db
        .select({
          id: d.boats.id,
          name: d.boats.name,
          maxDevices: d.boats.maxDevices,
          createdAt: d.boats.createdAt,
        })
        .from(d.boats)
        .orderBy(d.boats.name),
      d.db
        .select()
        .from(d.boatDevices)
        .orderBy(d.orm.desc(d.boatDevices.lastSeenAt)),
    ])
    return {
      ok: true,
      boats: rows.map((r) => ({
        ...r,
        createdAt: r.createdAt.toISOString(),
        devices: devices
          .filter((v) => v.boatId === r.id)
          .map((v) => ({
            id: v.id,
            label: v.label,
            createdAt: v.createdAt.toISOString(),
            lastSeenAt: v.lastSeenAt.toISOString(),
          })),
      })),
    }
  })

type CreateResult = { ok: true } | { ok: false; error: AuthError | 'exists' }

export const createBoat = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      password: passwordSchema,
      id: boatIdSchema,
      name: boatNameSchema,
      boatPassword: boatPasswordSchema,
      maxDevices: maxDevicesSchema,
    }),
  )
  .handler(async ({ data }): Promise<CreateResult> => {
    const auth = await checkMain(data.password)
    if (!auth.ok) return auth
    // Reserved for the main admin's login
    if (data.id === MAIN_ADMIN_USER) return { ok: false, error: 'exists' }
    const d = await loadDb()
    const inserted = await d.db
      .insert(d.boats)
      .values({
        id: data.id,
        name: data.name,
        passwordHash: hashPassword(data.boatPassword),
        maxDevices: data.maxDevices,
      })
      .onConflictDoNothing()
      .returning({ id: d.boats.id })
    return inserted.length ? { ok: true } : { ok: false, error: 'exists' }
  })

/**
 * Rename a boat, set a new password and/or change its device limit. When the
 * limit drops below the logged-in devices, the least recently used ones are
 * logged out.
 */
export const updateBoat = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      password: passwordSchema,
      id: boatIdSchema,
      name: boatNameSchema.optional(),
      boatPassword: boatPasswordSchema.optional(),
      maxDevices: maxDevicesSchema.optional(),
    }),
  )
  .handler(async ({ data }): Promise<AuthResult> => {
    const auth = await checkMain(data.password)
    if (!auth.ok) return auth
    const d = await loadDb()
    const { eq, desc, inArray } = d.orm
    const set: { name?: string; passwordHash?: string; maxDevices?: number } =
      {}
    if (data.name) set.name = data.name
    if (data.boatPassword) set.passwordHash = hashPassword(data.boatPassword)
    if (data.maxDevices) set.maxDevices = data.maxDevices
    if (!Object.keys(set).length) return { ok: true }
    const updated = await d.db
      .update(d.boats)
      .set(set)
      .where(eq(d.boats.id, data.id))
      .returning({ id: d.boats.id })
    if (!updated.length) return { ok: false, error: 'not-found' }
    if (data.maxDevices) {
      const devices = await d.db
        .select({ id: d.boatDevices.id })
        .from(d.boatDevices)
        .where(eq(d.boatDevices.boatId, data.id))
        .orderBy(desc(d.boatDevices.lastSeenAt))
      const extra = devices.slice(data.maxDevices).map((v) => v.id)
      if (extra.length)
        await d.db.delete(d.boatDevices).where(inArray(d.boatDevices.id, extra))
    }
    return { ok: true }
  })

/** Log out one device of a boat, or all of them (frees the slots). */
export const removeBoatDevices = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      password: passwordSchema,
      boatId: boatIdSchema,
      deviceId: z.string().uuid().optional(),
    }),
  )
  .handler(async ({ data }): Promise<AuthResult> => {
    // The main admin or the boat itself (its own admin page)
    const auth = await checkAccess(data.password, data.boatId)
    if (!auth.ok) return auth
    const d = await loadDb()
    const { and, eq } = d.orm
    await d.db
      .delete(d.boatDevices)
      .where(
        data.deviceId
          ? and(
              eq(d.boatDevices.boatId, data.boatId),
              eq(d.boatDevices.id, data.deviceId),
            )
          : eq(d.boatDevices.boatId, data.boatId),
      )
    return { ok: true }
  })

/** Delete a boat with all its own positions and texts. */
export const deleteBoat = createServerFn({ method: 'POST' })
  .validator(z.object({ password: passwordSchema, id: boatIdSchema }))
  .handler(async ({ data }): Promise<AuthResult> => {
    const auth = await checkMain(data.password)
    if (!auth.ok) return auth
    const d = await loadDb()
    const { eq } = d.orm
    await d.db
      .delete(d.boatStopPositions)
      .where(eq(d.boatStopPositions.boatId, data.id))
    await d.db.delete(d.boatTexts).where(eq(d.boatTexts.boatId, data.id))
    await d.db.delete(d.boatDevices).where(eq(d.boatDevices.boatId, data.id))
    await d.db.delete(d.boats).where(eq(d.boats.id, data.id))
    return { ok: true }
  })

type OwnDevicesResult =
  | {
      ok: true
      maxDevices: number
      devices: (BoatDevice & { current: boolean })[]
    }
  | { ok: false; error: AuthError }

/** A boat's devices for its own admin page (boat or main password). */
export const listOwnBoatDevices = createServerFn({ method: 'POST' })
  .validator(z.object({ password: passwordSchema, boatId: boatIdSchema }))
  .handler(async ({ data }): Promise<OwnDevicesResult> => {
    const auth = await checkAccess(data.password, data.boatId)
    if (!auth.ok) return auth
    const d = await loadDb()
    const { eq } = d.orm
    const [[boat], rows, { device }] = await Promise.all([
      d.db
        .select({ maxDevices: d.boats.maxDevices })
        .from(d.boats)
        .where(eq(d.boats.id, data.boatId)),
      d.db
        .select()
        .from(d.boatDevices)
        .where(eq(d.boatDevices.boatId, data.boatId))
        .orderBy(d.orm.desc(d.boatDevices.lastSeenAt)),
      currentDevice(data.boatId),
    ])
    return {
      ok: true,
      maxDevices: boat?.maxDevices ?? 0,
      devices: rows.map((v) => ({
        id: v.id,
        label: v.label,
        createdAt: v.createdAt.toISOString(),
        lastSeenAt: v.lastSeenAt.toISOString(),
        current: v.id === device?.id,
      })),
    }
  })
