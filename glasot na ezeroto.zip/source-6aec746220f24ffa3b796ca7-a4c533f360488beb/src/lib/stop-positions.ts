import type { TextOverrides } from '@/lib/content-texts'
import { LANGUAGES, STOPS, type Localized, type Stop } from '@/data/tour'

/** An admin-set position and geofence radius for one stop. */
export interface StopPosition {
  stopId: string
  lat: number
  lng: number
  radius: number
}

/** Everything the admin can override. */
export interface BoatInfo {
  id: string
  name: string
}

export interface TourConfig {
  /** Effective positions (boat over global) */
  stops: StopPosition[]
  /** Effective texts (boat over global) */
  texts?: TextOverrides
  /** For a boat: the global layer it builds on (used by the boat's editors) */
  baseStops?: StopPosition[]
  baseTexts?: TextOverrides
  /** The boat this config is for, if any */
  boat?: BoatInfo | null
}

/** Placeholder in texts that is replaced with the boat's name. */
export const BOAT_PLACEHOLDER = '{brod}'
export const fillBoatName = (text: string, name?: string | null) =>
  name ? text.split(BOAT_PLACEHOLDER).join(name) : text

export const RADIUS_MIN = 50
export const RADIUS_MAX = 2000

/** How many extra zones a boat may add to its own tour. */
export const MAX_EXTRA_STOPS = 5
/** Reserved ids for a boat's own extra zones: extra-1 … extra-5. */
export const EXTRA_STOP_IDS = Array.from(
  { length: MAX_EXTRA_STOPS },
  (_, i) => `extra-${i + 1}`,
)
export const isExtraStop = (id: string) => EXTRA_STOP_IDS.includes(id)
/** Bundled stops and the extra zone ids: every id a position may have. */
export const ALL_STOP_IDS = [...STOPS.map((s) => s.id), ...EXTRA_STOP_IDS]

const EMPTY_STORY = Object.fromEntries(
  LANGUAGES.map((l) => [l.code, '']),
) as Localized

/** Default (unnamed, story-less) data for an extra zone. */
export function extraStopDefaults(id: string): Stop {
  return {
    id,
    lat: 0,
    lng: 0,
    radius: 300,
    name: `Дополнителна точка ${id.replace('extra-', '')}`,
    subtitle: '',
    story: EMPTY_STORY,
  }
}

/**
 * Bundled stops with any saved positions applied, followed by the boat's
 * extra zones (an extra zone exists only when it has a saved position).
 */
export function mergeStops(overrides: StopPosition[] | null): Stop[] {
  if (!overrides?.length) return STOPS
  const byId = new Map(overrides.map((o) => [o.stopId, o]))
  const base = STOPS.map((s) => {
    const o = byId.get(s.id)
    return o ? { ...s, lat: o.lat, lng: o.lng, radius: o.radius } : s
  })
  const extras = EXTRA_STOP_IDS.flatMap((id) => {
    const o = byId.get(id)
    return o
      ? [{ ...extraStopDefaults(id), lat: o.lat, lng: o.lng, radius: o.radius }]
      : []
  })
  return [...base, ...extras]
}
