import { createServerFn } from '@tanstack/react-start'
import { z } from 'zod'
import type { ResolveResult } from '@/lib/stream-resolver'

/**
 * Turns any radio link (a radio's web page, a playlist or a direct stream)
 * into playable stream URLs. See src/lib/stream-resolver.ts.
 */
export const resolveStreamUrl = createServerFn({ method: 'POST' })
  .validator(z.object({ url: z.string().url().max(2000) }))
  .handler(async ({ data }): Promise<ResolveResult> => {
    const { resolveStream } = await import('@/lib/stream-resolver')
    return resolveStream(data)
  })
