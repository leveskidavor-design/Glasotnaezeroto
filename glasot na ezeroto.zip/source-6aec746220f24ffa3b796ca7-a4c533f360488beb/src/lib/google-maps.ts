/**
 * Loads the Google Maps JavaScript API once, in Macedonian.
 * The browser key is fetched at runtime from /api/maps-key (it is read from
 * the VITE_GOOGLE_MAPS_API_KEY environment variable on the server), so it is
 * never inlined into the build output.
 */

async function fetchKey(): Promise<string> {
  const res = await fetch('/api/maps-key')
  if (!res.ok) throw new Error('missing-key')
  const data = (await res.json()) as { key?: string }
  if (!data.key) throw new Error('missing-key')
  return data.key
}

let loader: Promise<typeof google.maps> | null = null
let authFailed = false
const authListeners = new Set<() => void>()

declare global {
  interface Window {
    __lihnidMapsReady?: () => void
    gm_authFailure?: () => void
  }
}

/** Subscribe to Google's "invalid key / not authorised" signal, which fires after load. */
export function onGoogleAuthFailure(cb: () => void) {
  if (authFailed) cb()
  authListeners.add(cb)
  return () => {
    authListeners.delete(cb)
  }
}

export function loadGoogleMaps(): Promise<typeof google.maps> {
  if (typeof window === 'undefined') return Promise.reject(new Error('ssr'))
  if (window.google?.maps?.Map) return Promise.resolve(window.google.maps)
  if (loader) return loader

  loader = fetchKey().then(
    (key) =>
      new Promise<typeof google.maps>((resolve, reject) => {
        window.gm_authFailure = () => {
          authFailed = true
          authListeners.forEach((cb) => cb())
        }
        window.__lihnidMapsReady = () => resolve(window.google.maps)
        const script = document.createElement('script')
        script.src =
          'https://maps.googleapis.com/maps/api/js?' +
          new URLSearchParams({
            key,
            v: 'weekly',
            language: 'mk',
            region: 'MK',
            loading: 'async',
            callback: '__lihnidMapsReady',
          }).toString()
        script.async = true
        script.onerror = () => {
          loader = null
          script.remove()
          reject(new Error('load-failed'))
        }
        document.head.appendChild(script)
      }),
  )
  loader.catch(() => {
    loader = null
  })
  return loader
}
