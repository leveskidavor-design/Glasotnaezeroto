/** Path patterns of an audio stream (not a web page). */
const PATH_HINT =
  /\.(mp3|aac|aacp|m4a|ogg|oga|opus|flac|m3u8)$|\/(stream|live|listen|autodj|mount|radio\.mp3)[^/]*$|;stream|^\/?;$/i
/** Hosts of stream providers. */
const HOST_HINT =
  /icecast|shoutcast|streamtheworld|zeno\.fm|radio\.co$|radiojar|^stream|^radiostream|^live\.|^audio\.|^ice\d*\.|^s\d+\.|streaming/i

/** Does this URL look like an audio stream rather than a web page? */
export function looksLikeStream(url: string) {
  try {
    const u = new URL(url)
    if (u.pathname === '/' && !u.port && !HOST_HINT.test(u.hostname))
      return false
    return (
      PATH_HINT.test(u.pathname) ||
      HOST_HINT.test(u.hostname) ||
      /^\d{4,5}$/.test(u.port)
    )
  } catch {
    return false
  }
}

/** Playlist files that list the stream URL(s). */
export const PLAYLIST = /\.(pls|m3u|asx|xspf)(\?|$)/i
