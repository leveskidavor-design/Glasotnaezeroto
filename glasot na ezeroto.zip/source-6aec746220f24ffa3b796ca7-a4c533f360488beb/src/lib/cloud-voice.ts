/**
 * Client side of the Microsoft neural narration (see src/routes/api.tts.ts).
 * Sentences are downloaded as MP3 and kept in the browser's Cache Storage,
 * so a tour prepared in the harbour keeps speaking without signal on the
 * lake. When a sentence can't be loaded the narrator falls back to the
 * device's own voice.
 */
import type { Lang } from '@/data/tour'

const TTS_VERSION = '1'
const CACHE_NAME = 'lihnid-tts-v1'

export const splitSentences = (text: string) =>
  text.match(/[^.!?…]+[.!?…]+["”’]?\s*/g)?.map((s) => s.trim()) ?? [text.trim()]

const normalise = (text: string) => text.replace(/\s+/g, ' ').trim()

export const ttsUrl = (lang: Lang, text: string) =>
  `/api/tts?v=${TTS_VERSION}&lang=${lang}&text=${encodeURIComponent(normalise(text))}`

/** After a network failure, don't wait on the network again for a while. */
let downUntil = 0
const NETWORK_BACKOFF = 60_000
export const cloudReachable = () => Date.now() >= downUntil

async function openCache() {
  if (typeof caches === 'undefined') return null
  try {
    return await caches.open(CACHE_NAME)
  } catch {
    return null
  }
}

const inflight = new Map<string, Promise<Blob>>()

/** MP3 of one sentence: from the offline cache, else from the server. */
export function sentenceBlob(lang: Lang, text: string): Promise<Blob> {
  const url = ttsUrl(lang, text)
  const running = inflight.get(url)
  if (running) return running
  const p = (async () => {
    const cache = await openCache()
    const hit = await cache?.match(url)
    if (hit) return hit.blob()
    if (!cloudReachable()) throw new Error('offline')
    let res: Response
    try {
      res = await fetch(url)
    } catch (err) {
      downUntil = Date.now() + NETWORK_BACKOFF
      throw err
    }
    if (!res.ok) {
      // The voice service is failing: use device voices for a while
      if (res.status >= 500) downUntil = Date.now() + NETWORK_BACKOFF
      throw new Error(`tts ${res.status}`)
    }
    if (cache) await cache.put(url, res.clone()).catch(() => {})
    return res.blob()
  })().finally(() => inflight.delete(url))
  inflight.set(url, p)
  return p
}

const objectUrls = new Map<string, string>()

/** Object URL for an <audio> element (kept for replays and resume). */
export async function sentenceAudioUrl(lang: Lang, text: string) {
  const key = ttsUrl(lang, text)
  const known = objectUrls.get(key)
  if (known) return known
  const url = URL.createObjectURL(await sentenceBlob(lang, text))
  objectUrls.set(key, url)
  // Keep memory bounded on long tours
  if (objectUrls.size > 80) {
    const [oldKey, oldUrl] = objectUrls.entries().next().value!
    URL.revokeObjectURL(oldUrl)
    objectUrls.delete(oldKey)
  }
  return url
}

export interface PreloadProgress {
  done: number
  total: number
  failed: number
}

/**
 * Downloads every sentence (in the given order) into the offline cache.
 * Already cached sentences are skipped quickly. Returns a cancel function.
 */
export function preloadSentences(
  items: { lang: Lang; text: string }[],
  onProgress: (p: PreloadProgress) => void,
): () => void {
  let cancelled = false
  const unique = [
    ...new Map(items.map((i) => [ttsUrl(i.lang, i.text), i])).values(),
  ]
  const progress: PreloadProgress = { done: 0, total: unique.length, failed: 0 }
  onProgress({ ...progress })
  let next = 0
  const worker = async () => {
    while (!cancelled && next < unique.length) {
      const item = unique[next++]
      try {
        await sentenceBlob(item.lang, item.text)
      } catch {
        progress.failed++
        // Offline or the service is down: stop, it's retried on next start
        if (!cloudReachable()) cancelled = true
      }
      progress.done++
      if (!cancelled) onProgress({ ...progress })
    }
  }
  void Promise.all([worker(), worker(), worker()])
  return () => {
    cancelled = true
  }
}

/**
 * A silent WAV, played from a user gesture so iOS lets the same <audio>
 * element play the narration later without a tap.
 */
let silent: string | null = null
export function silentWavUrl() {
  if (silent) return silent
  const samples = 800
  const buf = new ArrayBuffer(44 + samples * 2)
  const v = new DataView(buf)
  const str = (o: number, s: string) =>
    [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)))
  str(0, 'RIFF')
  v.setUint32(4, 36 + samples * 2, true)
  str(8, 'WAVE')
  str(12, 'fmt ')
  v.setUint32(16, 16, true)
  v.setUint16(20, 1, true)
  v.setUint16(22, 1, true)
  v.setUint32(24, 8000, true)
  v.setUint32(28, 16000, true)
  v.setUint16(32, 2, true)
  v.setUint16(34, 16, true)
  str(36, 'data')
  v.setUint32(40, samples * 2, true)
  silent = URL.createObjectURL(new Blob([buf], { type: 'audio/wav' }))
  return silent
}
