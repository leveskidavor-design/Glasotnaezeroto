/** Messages for server auth errors. */
export const AUTH_ERRORS = {
  'wrong-password': 'Погрешна лозинка.',
  'not-configured':
    'Лозинката за уредување не е поставена на серверот (ADMIN_PASSWORD).',
  'not-found': 'Бродот не постои.',
} as const

export type AdminSession = {
  subscribe: (cb: () => void) => () => void
  /** undefined on the server, before the browser session is known */
  get: () => string | null | undefined
  getServer: () => string | null | undefined
  set: (value: string | null) => void
}

const sessions = new Map<string, AdminSession>()

/**
 * Password kept only for this browser tab (sessionStorage): one session for
 * the main admin and one per boat.
 */
export function adminSession(boatId?: string): AdminSession {
  const key = boatId
    ? `lihnid:boat-password:${boatId}`
    : 'lihnid:admin-password'
  const existing = sessions.get(key)
  if (existing) return existing
  const listeners = new Set<() => void>()
  const s: AdminSession = {
    subscribe(cb) {
      listeners.add(cb)
      return () => {
        listeners.delete(cb)
      }
    },
    get: () => sessionStorage.getItem(key),
    getServer: () => undefined,
    set(value) {
      if (value) sessionStorage.setItem(key, value)
      else sessionStorage.removeItem(key)
      listeners.forEach((cb) => cb())
    },
  }
  sessions.set(key, s)
  return s
}
