import { useCallback, useEffect, useRef, useState } from 'react'
import type { Lang, Stop } from '@/data/tour'
import { distanceM } from '@/lib/geo'
import type { useNarrator } from '@/lib/use-narrator'

export interface Position {
  lat: number
  lng: number
  accuracy?: number
  /** Speed over ground reported by the GPS, in m/s (not all devices report it) */
  speed?: number | null
  /** Time of the fix, ms since epoch */
  at?: number
}

interface Options {
  langs: Lang[]
  /** Stops with their current (possibly admin-edited) geofences */
  stops: Stop[]
  narrator: ReturnType<typeof useNarrator>
}

/**
 * Drives the tour: reads the device GPS position, detects when the boat
 * enters a stop's geofence and queues its story once, in every selected
 * language.
 */
export function useTourEngine({ langs, stops, narrator }: Options) {
  const [running, setRunning] = useState(false)
  const [position, setPosition] = useState<Position | null>(null)
  const [gpsError, setGpsError] = useState<
    'denied' | 'unsupported' | 'other' | null
  >(null)
  const [triggered, setTriggered] = useState<string[]>([])

  const triggeredRef = useRef(new Set<string>())
  const watchId = useRef<number | null>(null)
  const wakeLock = useRef<WakeLockSentinel | null>(null)

  // Latest values for the GPS watch callback
  const live = useRef({ langs, stops, enqueue: narrator.enqueue })
  useEffect(() => {
    live.current = { langs, stops, enqueue: narrator.enqueue }
  })

  const checkZones = useCallback((p: Position) => {
    for (const stop of live.current.stops) {
      if (triggeredRef.current.has(stop.id)) continue
      if (distanceM(p.lat, p.lng, stop.lat, stop.lng) <= stop.radius) {
        triggeredRef.current.add(stop.id)
        setTriggered([...triggeredRef.current])
        live.current.enqueue(stop.id, live.current.langs)
      }
    }
  }, [])

  const updatePosition = useCallback(
    (p: Position) => {
      setPosition(p)
      checkZones(p)
    },
    [checkZones],
  )

  const releaseResources = () => {
    if (watchId.current !== null)
      navigator.geolocation.clearWatch(watchId.current)
    watchId.current = null
    wakeLock.current?.release().catch(() => {})
    wakeLock.current = null
  }

  /**
   * Starts the tour. `initial` is a recent GPS fix from the pre-tour check,
   * so the map shows the boat (and a zone the boat is already in triggers)
   * right away instead of waiting for the first watch update.
   */
  const start = useCallback(
    async (initial?: Position | null) => {
      narrator.unlock()
      // Download the narration audio while the harbour still has signal
      narrator.prepare(live.current.langs)
      triggeredRef.current = new Set()
      setTriggered([])
      setGpsError(null)
      setPosition(null)
      setRunning(true)
      if (initial) updatePosition(initial)

      try {
        wakeLock.current = (await navigator.wakeLock?.request('screen')) ?? null
      } catch {
        /* not supported or refused — tour still works */
      }

      if (!('geolocation' in navigator)) {
        setGpsError('unsupported')
        return
      }
      watchId.current = navigator.geolocation.watchPosition(
        (pos) =>
          updatePosition({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
            speed: pos.coords.speed,
            at: pos.timestamp,
          }),
        (err) =>
          setGpsError(err.code === err.PERMISSION_DENIED ? 'denied' : 'other'),
        { enableHighAccuracy: true, maximumAge: 2000, timeout: 20000 },
      )
    },
    [narrator, updatePosition],
  )

  const stop = useCallback(() => {
    releaseResources()
    narrator.reset()
    setRunning(false)
  }, [narrator])

  /** Manually play a stop (e.g. a replay, or GPS is weak). */
  const playStop = useCallback(
    (stopId: string) => {
      narrator.unlock()
      triggeredRef.current.add(stopId)
      setTriggered([...triggeredRef.current])
      narrator.enqueue(stopId, live.current.langs)
    },
    [narrator],
  )

  useEffect(() => () => releaseResources(), [])

  // Re-acquire the wake lock when returning to the tab
  useEffect(() => {
    const onVisible = async () => {
      if (
        running &&
        document.visibilityState === 'visible' &&
        (!wakeLock.current || wakeLock.current.released)
      ) {
        try {
          wakeLock.current =
            (await navigator.wakeLock?.request('screen')) ?? null
        } catch {
          /* ignore */
        }
      }
    }
    document.addEventListener('visibilitychange', onVisible)
    return () => document.removeEventListener('visibilitychange', onVisible)
  }, [running])

  return {
    running,
    position,
    gpsError,
    triggered,
    start,
    stop,
    playStop,
  }
}
