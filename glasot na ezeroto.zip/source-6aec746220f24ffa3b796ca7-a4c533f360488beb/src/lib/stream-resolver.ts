import { looksLikeStream, PLAYLIST } from '@/lib/stream-hints'

export type ResolveResult =
  | {
      ok: true
      /** Playable stream URLs, best first (https before http) */
      urls: string[]
      /** Station name, when known */
      name?: string
    }
  | { ok: false }

const MAX_BYTES = 256 * 1024

/** Hosts a public radio link can't point to (no fetching of internal hosts). */
function isPrivateHost(host: string) {
  const h = host.toLowerCase().replace(/^\[|\]$/g, '')
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.internal'))
    return true
  if (h.includes(':')) return h === '::1' || /^(f[cd]|fe80|::ffff:)/.test(h)
  const m = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/)
  if (!m) return false
  const [a, b] = [Number(m[1]), Number(m[2])]
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127)
  )
}

const NOT_AUDIO =
  /\.(js|css|png|jpe?g|gif|svg|webp|ico|woff2?|ttf|html?|php|aspx?|json|xml)(\?|$)|facebook|twitter|instagram|google|youtube|tiktok|linkedin|viber|pinterest|whatsapp|wa\.me|t\.me|(^|\/\/|\.)x\.com|apple\.com|wp-json|api\.w\.org|\/feed\/?$|\/wp-content\//i

const UA = 'Mozilla/5.0 (Glasot na ezeroto audio guide)'

async function fetchText(
  url: string,
  ms = 6000,
): Promise<{ url: string; type: string; body: string } | null> {
  let u: URL
  try {
    u = new URL(url)
  } catch {
    return null
  }
  if (!/^https?:$/.test(u.protocol) || isPrivateHost(u.hostname)) return null
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), ms)
  try {
    const res = await fetch(u, {
      signal: ctrl.signal,
      redirect: 'follow',
      headers: { 'user-agent': UA, accept: '*/*' },
    })
    if (!res.ok || !res.body) return null
    const type = res.headers.get('content-type') ?? ''
    const finalUrl = res.url || u.toString()
    // An audio stream never ends: don't read it
    if (/^audio\//i.test(type) && !/mpegurl|scpls|x-scpls|xspf/i.test(type)) {
      res.body.cancel().catch(() => {})
      return { url: finalUrl, type, body: '' }
    }
    const reader = res.body.getReader()
    const chunks: Uint8Array[] = []
    let size = 0
    while (size < MAX_BYTES) {
      const { done, value } = await reader.read()
      if (done || !value) break
      chunks.push(value)
      size += value.length
    }
    reader.cancel().catch(() => {})
    return {
      url: finalUrl,
      type,
      body: new TextDecoder().decode(Buffer.concat(chunks)),
    }
  } catch {
    return null
  } finally {
    clearTimeout(timer)
  }
}

const isAudioType = (type: string) =>
  /^audio\//i.test(type) && !/mpegurl|scpls|x-scpls|xspf/i.test(type)

/** URLs listed in a .pls / .m3u / .asx / .xspf playlist. */
function playlistUrls(body: string) {
  const out: string[] = []
  for (const line of body.split(/\r?\n/)) {
    const m = line.trim().match(/^(?:File\d+=)?(https?:\/\/\S+)$/i)
    if (m) out.push(m[1])
  }
  for (const m of body.matchAll(
    /(?:href|location)[^>]*?>?\s*["']?(https?:\/\/[^"'<\s]+)/gi,
  ))
    out.push(m[1])
  return out
}

/** Clean up URLs found inside HTML / JSON / JS. */
const unescapeUrl = (u: string) =>
  u
    .replace(/\\\//g, '/')
    .replace(/\\u0026/gi, '&')
    .replace(/&amp;/g, '&')
    .replace(/[.,;)]+$/, (m) => (m.startsWith(';') ? m : ''))

interface PageScan {
  streams: string[]
  playlists: string[]
  frames: string[]
  title?: string
}

function scanPage(body: string, base: string): PageScan {
  const text = body.replace(/\\\//g, '/')
  const abs = (u: string) => {
    try {
      return new URL(unescapeUrl(u), base).toString()
    } catch {
      return null
    }
  }
  const all = (text.match(/https?:\/\/[^\s"'<>`\\]+/gi) ?? []).map(unescapeUrl)
  const streams = new Set<string>()
  const playlists = new Set<string>()
  for (const u of all) {
    if (PLAYLIST.test(u)) playlists.add(u)
    else if (looksLikeStream(u) && !NOT_AUDIO.test(u)) streams.add(u)
  }
  // <audio src>, <source src>, data-src / data-stream / data-url attributes
  for (const m of text.matchAll(
    /<(?:audio|source)[^>]+src=["']([^"']+)["']|data-(?:src|stream|url|audio|file)=["']([^"']+)["']/gi,
  )) {
    const u = abs(m[1] ?? m[2])
    if (u && !NOT_AUDIO.test(u)) (PLAYLIST.test(u) ? playlists : streams).add(u)
  }
  // Relative playlist links
  for (const m of text.matchAll(
    /href=["']([^"']+\.(?:pls|m3u|asx|xspf)[^"']*)["']/gi,
  )) {
    const u = abs(m[1])
    if (u) playlists.add(u)
  }
  // Embedded players (often hosted by the stream provider)
  const frames: string[] = []
  for (const m of text.matchAll(/<iframe[^>]+src=["']([^"']+)["']/gi)) {
    const u = abs(m[1])
    if (
      u &&
      /player|radio|stream|listen|live|embed|audio/i.test(u) &&
      !/youtube|facebook|google/i.test(u)
    )
      frames.push(u)
  }
  const title =
    text.match(
      /<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i,
    )?.[1] ??
    text.match(
      /<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i,
    )?.[1] ??
    text.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]
  return {
    streams: [...streams],
    playlists: [...playlists],
    frames: frames.slice(0, 3),
    title: title?.trim(),
  }
}

/** Is this URL really an audio stream? (checks the response type) */
async function checkStream(url: string): Promise<string | null> {
  const r = await fetchText(url, 4000)
  if (!r) return null
  if (isAudioType(r.type)) return r.url
  // Some servers send audio as application/octet-stream or text/html (old shoutcast)
  if (/octet-stream|ogg|aac|mpeg/i.test(r.type) && !/mpegurl/i.test(r.type))
    return r.url
  if (/mpegurl|scpls|xspf|x-ms-asf/i.test(r.type) || PLAYLIST.test(url)) {
    const inner = playlistUrls(r.body)[0]
    return inner ?? null
  }
  return null
}

interface RbStation {
  name: string
  url_resolved: string
  homepage: string
  lastcheckok: number
  votes: number
}

const hostOf = (u: string) => {
  try {
    return new URL(u).hostname.replace(/^www\./, '').toLowerCase()
  } catch {
    return ''
  }
}

/** Letters and digits only, for loose name matching. */
const norm = (s: string) =>
  s
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^\p{L}\p{N}]/gu, '')

/** Generic 2-letter endings that aren't a country. */
const NOT_COUNTRY = new Set(['fm', 'io', 'co', 'tv', 'me', 'am', 'cc', 'ai'])

const RB = 'https://all.api.radio-browser.info/json/stations'

async function rbQuery(path: string) {
  const r = await fetchText(`${RB}/${path}`, 6000)
  if (!r) return [] as RbStation[]
  try {
    return JSON.parse(r.body) as RbStation[]
  } catch {
    return []
  }
}

/**
 * The free Radio Browser directory (radio-browser.info) knows the stream of
 * most stations: find the station whose web site is the pasted page (within
 * the site's country, e.g. .mk), or whose name matches the site.
 */
async function lookupDirectory(pageUrl: string, title?: string) {
  const host = hostOf(pageUrl)
  const parts = host.split('.')
  const tld = parts.at(-1) ?? ''
  const site =
    parts.length > 2 && parts.at(-2)!.length <= 3
      ? parts.at(-3)!
      : (parts.at(-2) ?? '')
  const siteKey = norm(site)
  const titleName = title?.split(/[|–—:·]| - /)[0]?.trim()

  const sameSite = (s: RbStation) => {
    const h = hostOf(s.homepage)
    return (
      !!h && (h === host || h.endsWith(`.${host}`) || host.endsWith(`.${h}`))
    )
  }
  const nameMatch = (s: RbStation) => {
    const n = norm(s.name)
    return (
      (siteKey.length >= 4 && n.includes(siteKey)) ||
      (!!titleName &&
        norm(titleName).length >= 4 &&
        n.includes(norm(titleName)))
    )
  }

  const lists: Promise<RbStation[]>[] = []
  if (/^[a-z]{2}$/.test(tld) && !NOT_COUNTRY.has(tld))
    lists.push(
      rbQuery(
        `bycountrycodeexact/${tld.toUpperCase()}?hidebroken=true&limit=2000`,
      ),
    )
  for (const name of [titleName, site].filter(
    (n): n is string => !!n && n.length >= 3,
  ))
    lists.push(
      rbQuery(
        `search?name=${encodeURIComponent(name)}&hidebroken=true&order=votes&reverse=true&limit=50`,
      ),
    )
  const found = (await Promise.all(lists)).flat()

  const bySite = found.filter(sameSite)
  const pick = bySite.length ? bySite : found.filter(nameMatch)
  pick.sort((a, b) => b.votes - a.votes)
  return {
    urls: pick.filter((s) => s.lastcheckok !== 0).map((s) => s.url_resolved),
    name: pick[0]?.name?.trim(),
  }
}

/** https streams first (an https page can't play http audio), no duplicates. */
function rank(urls: string[]) {
  const seen = new Set<string>()
  const out: string[] = []
  for (const u of urls) {
    if (!/^https?:\/\//i.test(u) || seen.has(u)) continue
    try {
      if (isPrivateHost(new URL(u).hostname)) continue
    } catch {
      continue
    }
    seen.add(u)
    out.push(u)
  }
  return [
    ...out.filter((u) => u.startsWith('https:')),
    // http streams: try the https version first, then as they are
    ...out
      .filter((u) => u.startsWith('http:'))
      .flatMap((u) => [u.replace(/^http:/, 'https:'), u]),
  ].slice(0, 8)
}

/**
 * Turns any radio link into playable stream URLs: a direct stream, a
 * .pls/.m3u playlist, or simply the web page of an online radio (its player,
 * embedded players and playlists are searched, then the Radio Browser
 * directory).
 */
export async function resolveStream(data: {
  url: string
}): Promise<ResolveResult> {
  const page = await fetchText(data.url)
  if (!page) {
    // Site unreachable from the server: the directory may still know it
    const dir = await lookupDirectory(data.url)
    return dir.urls.length
      ? { ok: true, urls: rank(dir.urls), name: dir.name }
      : { ok: false }
  }
  if (isAudioType(page.type)) return { ok: true, urls: [page.url] }
  if (
    /mpegurl|scpls|xspf|x-ms-asf/i.test(page.type) ||
    PLAYLIST.test(page.url)
  ) {
    const urls = playlistUrls(page.body)
    if (urls.length) return { ok: true, urls: rank(urls) }
  }

  const scan = scanPage(page.body, page.url)
  const candidates: string[] = []
  // Players embedded from another site (one level deep)
  const frames = await Promise.all(scan.frames.map((f) => fetchText(f, 4000)))
  for (const f of frames) {
    if (!f) continue
    const inner = scanPage(f.body, f.url)
    scan.streams.push(...inner.streams)
    scan.playlists.push(...inner.playlists)
  }
  // Playlists found on the page → their stream URLs
  const lists = await Promise.all(
    [...new Set(scan.playlists)].slice(0, 3).map((u) => fetchText(u, 4000)),
  )
  for (const l of lists) if (l) candidates.push(...playlistUrls(l.body))
  candidates.push(...scan.streams)

  // Keep the ones that really answer with audio (checked in parallel)
  const checked = (
    await Promise.all(rank(candidates).slice(0, 10).map(checkStream))
  ).filter((u): u is string => !!u)

  if (checked.length) return { ok: true, urls: rank(checked), name: scan.title }

  const dir = await lookupDirectory(page.url, scan.title)
  const urls = rank(dir.urls)
  return urls.length
    ? { ok: true, urls, name: dir.name ?? scan.title }
    : { ok: false }
}
