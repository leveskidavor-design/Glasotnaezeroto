/**
 * Tour content: stops (geofenced zones) and the narration
 * in every supported language. This is the single place to edit when
 * adding a new stop, adjusting a zone or adding a narration language.
 *
 * The interface is Macedonian only, so stop names and subtitles are plain
 * Macedonian strings. Only the spoken story is localized per narration
 * language.
 *
 * Zone centres sit on the water, along the course the boat actually sails,
 * so the boat passes through each circle. Coordinates are WGS84 decimal degrees.
 */

export type Lang = 'mk' | 'en' | 'sr' | 'pl' | 'tr' | 'de'

export type Localized = Record<Lang, string>

export interface LanguageMeta {
  code: Lang
  /** Name of the language, in Macedonian (the interface language) */
  name: string
  flag: string
  /** BCP-47 tag used for speech synthesis */
  speechLang: string
  /**
   * Voice prefixes to try, in order, when the device has no voice for the
   * language itself (e.g. many phones have no Macedonian voice, but a
   * Serbian or Bulgarian voice reads Macedonian Cyrillic well).
   */
  voiceFallbacks: string[]
  /**
   * Microsoft neural voice (the same voices as Edge's "Read aloud"), spoken
   * on the server so every browser and phone hears it (src/routes/api.tts.ts).
   */
  cloudVoice: string
  /** Voice name shown on the setup screen */
  cloudVoiceLabel: string
}

export const LANGUAGES: LanguageMeta[] = [
  {
    code: 'mk',
    name: 'Македонски',
    flag: '🇲🇰',
    speechLang: 'mk-MK',
    // Never Russian: it mispronounces Macedonian. Serbian reads it closest.
    voiceFallbacks: ['mk', 'sr', 'bg', 'hr', 'bs'],
    cloudVoice: 'mk-MK-MarijaNeural',
    cloudVoiceLabel: 'Microsoft Марија',
  },
  {
    code: 'en',
    name: 'Англиски',
    flag: '🇬🇧',
    speechLang: 'en-GB',
    voiceFallbacks: ['en-GB', 'en'],
    cloudVoice: 'en-GB-SoniaNeural',
    cloudVoiceLabel: 'Microsoft Sonia',
  },
  {
    code: 'sr',
    name: 'Срп/Хрв',
    flag: '🇭🇷',
    speechLang: 'hr-HR',
    // Shown as "Срп/Хрв"; the stories are written in Croatian and read by a
    // Croatian voice (Bosnian/Serbian voices as fallback). The code stays 'sr'
    // so saved language choices keep working.
    voiceFallbacks: ['hr', 'bs', 'sr', 'sh'],
    cloudVoice: 'hr-HR-GabrijelaNeural',
    cloudVoiceLabel: 'Microsoft Gabrijela',
  },
  {
    code: 'pl',
    name: 'Полски',
    flag: '🇵🇱',
    speechLang: 'pl-PL',
    voiceFallbacks: ['pl'],
    cloudVoice: 'pl-PL-ZofiaNeural',
    cloudVoiceLabel: 'Microsoft Zofia',
  },
  {
    code: 'tr',
    name: 'Турски',
    flag: '🇹🇷',
    speechLang: 'tr-TR',
    voiceFallbacks: ['tr'],
    cloudVoice: 'tr-TR-EmelNeural',
    cloudVoiceLabel: 'Microsoft Emel',
  },
  {
    code: 'de',
    name: 'Германски',
    flag: '🇩🇪',
    speechLang: 'de-DE',
    voiceFallbacks: ['de-DE', 'de'],
    cloudVoice: 'de-DE-KatjaNeural',
    cloudVoiceLabel: 'Microsoft Katja',
  },
]

export const getLanguage = (code: Lang) =>
  LANGUAGES.find((l) => l.code === code) ?? LANGUAGES[0]

export interface Stop {
  id: string
  lat: number
  lng: number
  /** Geofence radius in metres */
  radius: number
  name: string
  subtitle: string
  story: Localized
}

export const STOPS: Stop[] = [
  {
    id: 'port',
    lat: 41.1116,
    lng: 20.7986,
    radius: 180,
    name: 'Пристаниште Охрид',
    subtitle: 'Стариот град и Самуиловата тврдина',
    story: {
      mk: 'Добредојдовте на Охридското Езеро! Тргнуваме од пристаништето во стариот град Охрид, еден од најстарите населени градови во Европа. Во античко време градот се викал Лихнидос, што значи град на светлината. Над нас, на највисокиот рид, се издига Самуиловата тврдина, седиште на царот Самуил кон крајот на десеттиот век. Охрид и езерото се дел од светското природно и културно наследство на УНЕСКО. Удобно сместете се, турата започнува.',
      en: 'Welcome to Lake Ohrid! We are departing from the harbour of Ohrid’s old town, one of the oldest continuously inhabited towns in Europe. In antiquity the town was called Lychnidos, the city of light. Above us, on the highest hill, stands Samuel’s Fortress, the seat of Tsar Samuel at the end of the tenth century. Ohrid and its lake are listed by UNESCO as both natural and cultural World Heritage. Make yourselves comfortable, the tour is beginning.',
      sr: 'Dobro došli na Ohridsko jezero! Polazimo iz luke u starom gradu Ohridu, jednom od najstarijih naseljenih gradova u Europi. U antičko doba grad se zvao Lihnidos, što znači grad svjetlosti. Iznad nas, na najvišem brdu, uzdiže se Samuilova tvrđava, sjedište cara Samuila krajem desetog stoljeća. Ohrid i jezero dio su UNESCO-ove svjetske prirodne i kulturne baštine. Udobno se smjestite, tura počinje.',
      pl: 'Witamy nad Jeziorem Ochrydzkim! Wypływamy z portu na Starym Mieście w Ochrydzie, jednym z najstarszych nieprzerwanie zamieszkanych miast Europy. W starożytności miasto nazywało się Lychnidos, czyli miasto światła. Nad nami, na najwyższym wzgórzu, wznosi się Twierdza Samuela, siedziba cara Samuela pod koniec dziesiątego wieku. Ochryda i jezioro znajdują się na liście światowego dziedzictwa przyrodniczego i kulturowego UNESCO. Usiądźcie wygodnie, rejs się zaczyna.',
      tr: "Ohri Gölü'ne hoş geldiniz! Avrupa'nın en eski yerleşim yerlerinden biri olan Ohri'nin eski şehir limanından yola çıkıyoruz. Antik çağda şehrin adı Lihnidos, yani ışık şehriydi. Yukarıda, en yüksek tepede, onuncu yüzyılın sonunda Çar Samuil'in merkezi olan Samuil Kalesi yükseliyor. Ohri ve gölü, UNESCO Dünya Doğal ve Kültürel Mirası listesinde yer alıyor. Rahatınıza bakın, tur başlıyor.",
      de: 'Willkommen am Ohridsee! Wir legen im Hafen der Altstadt von Ohrid ab, einer der ältesten durchgehend bewohnten Städte Europas. In der Antike hieß die Stadt Lychnidos, die Stadt des Lichts. Über uns, auf dem höchsten Hügel, erhebt sich die Festung des Zaren Samuel, Ende des zehnten Jahrhunderts sein Herrschersitz. Ohrid und sein See gehören zum Natur- und Kulturerbe der UNESCO. Machen Sie es sich bequem, die Tour beginnt.',
    },
  },
  {
    id: 'kaneo',
    lat: 41.1103,
    lng: 20.7862,
    radius: 230,
    name: 'Св. Јован Канео',
    subtitle: 'Црквата на карпата над езерото',
    story: {
      mk: 'Пред нас е црквата Свети Јован Богослов, позната како Канео, по старото рибарско населба под неа. Изградена е во тринаесеттиот век, на карпа која се спушта директно во езерото. Нејзината основа има облик на крст, а над неа се издига купола со осумаголен тамбур. Во внатрешноста се зачувани делови од оригиналните фрески, меѓу нив и Христос Пантократор во куполата. Над црквата се наоѓа Плаошник, каде Свети Климент Охридски кон крајот на деветтиот век основал една од првите словенски школи. Ова е можеби најпрепознатливата слика на цела Македонија.',
      en: 'In front of us is the Church of St. John the Theologian, known as Kaneo after the old fishing quarter beneath it. It was built in the thirteenth century on a rock that drops straight into the lake. The church has a cross-shaped plan, crowned by a dome on an octagonal drum. Inside, parts of the original frescoes survive, including Christ Pantocrator in the dome. On the hill above lies Plaošnik, where Saint Clement of Ohrid founded one of the first Slavic schools at the end of the ninth century. This is perhaps the most recognisable view in all of North Macedonia.',
      sr: 'Ispred nas je crkva Svetog Ivana Bogoslova, poznata kao Kaneo, po starom ribarskom naselju ispod nje. Izgrađena je u trinaestom stoljeću, na stijeni koja se spušta ravno u jezero. Njezin tlocrt ima oblik križa, a iznad nje uzdiže se kupola na osmerokutnom tamburu. U unutrašnjosti su sačuvani dijelovi izvornih fresaka, među njima i Krist Pantokrator u kupoli. Iznad crkve nalazi se Plaošnik, gdje je sveti Klement Ohridski krajem devetog stoljeća osnovao jednu od prvih slavenskih škola. Ovo je možda najprepoznatljiviji prizor cijele Makedonije.',
      pl: 'Przed nami cerkiew świętego Jana Teologa, zwana Kaneo od dawnej dzielnicy rybackiej leżącej u jej stóp. Zbudowano ją w trzynastym wieku na skale, która opada prosto do jeziora. Cerkiew ma plan krzyża, a nad nią wznosi się kopuła na ośmiobocznym bębnie. Wewnątrz zachowały się fragmenty oryginalnych fresków, w tym Chrystus Pantokrator w kopule. Na wzgórzu powyżej znajduje się Plaošnik, gdzie święty Klemens Ochrydzki pod koniec dziewiątego wieku założył jedną z pierwszych szkół słowiańskich. To chyba najbardziej rozpoznawalny widok w całej Macedonii Północnej.',
      tr: "Karşımızda, altındaki eski balıkçı mahallesinden dolayı Kaneo olarak bilinen İlahiyatçı Aziz Yuhanna Kilisesi var. On üçüncü yüzyılda, doğrudan göle inen bir kayanın üzerine inşa edildi. Kilisenin planı haç şeklindedir ve üzerinde sekizgen bir kasnağa oturan bir kubbe yükselir. İçeride, kubbedeki Pantokrator İsa da dahil olmak üzere orijinal fresklerin bir kısmı korunmuştur. Kilisenin yukarısındaki tepede, Ohrili Aziz Kliment'in dokuzuncu yüzyılın sonunda ilk Slav okullarından birini kurduğu Plaoşnik bulunur. Burası belki de tüm Kuzey Makedonya'nın en tanınmış manzarasıdır.",
      de: 'Vor uns liegt die Kirche des heiligen Johannes des Theologen, nach dem alten Fischerviertel unter ihr Kaneo genannt. Sie wurde im dreizehnten Jahrhundert auf einem Felsen erbaut, der direkt in den See abfällt. Die Kirche hat einen kreuzförmigen Grundriss und wird von einer Kuppel auf einem achteckigen Tambour gekrönt. Im Inneren sind Teile der ursprünglichen Fresken erhalten, darunter Christus Pantokrator in der Kuppel. Auf dem Hügel darüber liegt Plaošnik, wo der heilige Klemens von Ohrid Ende des neunten Jahrhunderts eine der ersten slawischen Schulen gründete. Dies ist vielleicht der bekannteste Anblick ganz Nordmazedoniens.',
    },
  },
  {
    id: 'villa-biljana',
    lat: 41.095,
    lng: 20.79,
    radius: 450,
    name: 'Вила Билјана',
    subtitle: 'Летната резиденција на Тито, денес на претседателот',
    story: {
      mk: 'На брегот лево од нас, меѓу зеленилото, се наоѓа Вила Билјана, позната и како Титовата вила. Изградена е по Втората светска војна како летна резиденција на југословенскиот претседател Јосип Броз Тито, кој тука ги поминувал летата и примал високи гости од целиот свет. Името потсетува на Билјана од познатата охридска народна песна Билјана платно белеше. Денес вилата е во сопственост на македонската држава и е летна резиденција на претседателот на Македонија, па затоа не е отворена за посетители. Најубаво се гледа токму од езерото.',
      en: 'On the shore to our left, among the trees, stands Villa Biljana, also known as Tito’s Villa. It was built after the Second World War as the summer residence of the Yugoslav president Josip Broz Tito, who spent his summers here and received distinguished guests from all over the world. Its name recalls Biljana from the famous Ohrid folk song about a girl bleaching linen by the lake. Today the villa is owned by the Macedonian state and serves as the summer residence of the President of North Macedonia, so it is not open to visitors. The best view of it is exactly this one, from the lake.',
      sr: 'Na obali lijevo od nas, među zelenilom, nalazi se Vila Biljana, poznata i kao Titova vila. Izgrađena je nakon Drugoga svjetskog rata kao ljetna rezidencija jugoslavenskog predsjednika Josipa Broza Tita, koji je ovdje provodio ljeta i primao visoke goste iz cijeloga svijeta. Ime podsjeća na Biljanu iz poznate ohridske narodne pjesme Biljana platno beleše. Danas je vila u vlasništvu makedonske države i ljetna je rezidencija predsjednika Makedonije, pa nije otvorena za posjetitelje. Najljepše se vidi upravo s jezera.',
      pl: 'Na brzegu po naszej lewej stronie, wśród zieleni, stoi Willa Biljana, zwana też Willą Tity. Zbudowano ją po drugiej wojnie światowej jako letnią rezydencję prezydenta Jugosławii Josipa Broza Tity, który spędzał tu lata i przyjmował dostojnych gości z całego świata. Jej nazwa przywołuje Biljanę ze słynnej ochrydzkiej pieśni ludowej o dziewczynie bielącej płótno nad jeziorem. Dziś willa należy do państwa macedońskiego i jest letnią rezydencją prezydenta Macedonii Północnej, dlatego nie jest dostępna dla zwiedzających. Najpiękniej widać ją właśnie stąd, z jeziora.',
      tr: "Solumuzdaki kıyıda, yeşillikler arasında, Tito'nun Villası olarak da bilinen Villa Biljana yer alıyor. İkinci Dünya Savaşı'ndan sonra Yugoslavya Devlet Başkanı Josip Broz Tito için yazlık konut olarak inşa edildi. Tito yazlarını burada geçirir, dünyanın dört bir yanından seçkin konukları ağırlardı. Adı, göl kıyısında keten ağartan bir kızı anlatan ünlü Ohri halk şarkısındaki Biljana'yı hatırlatıyor. Bugün villa Makedon devletine aittir ve Kuzey Makedonya Cumhurbaşkanı'nın yazlık konutudur, bu nedenle ziyarete açık değildir. En güzel görüntüsü tam da buradan, gölden.",
      de: 'Am Ufer zu unserer Linken, zwischen den Bäumen, steht die Villa Biljana, auch Titos Villa genannt. Sie wurde nach dem Zweiten Weltkrieg als Sommerresidenz des jugoslawischen Präsidenten Josip Broz Tito erbaut, der hier seine Sommer verbrachte und hohe Gäste aus aller Welt empfing. Ihr Name erinnert an Biljana aus dem berühmten Ohrider Volkslied über ein Mädchen, das am See Leinen bleicht. Heute gehört die Villa dem mazedonischen Staat und ist die Sommerresidenz des Präsidenten Nordmazedoniens, daher ist sie für Besucher nicht geöffnet. Am schönsten sieht man sie genau von hier, vom See aus.',
    },
  },
  {
    id: 'lake',
    lat: 41.062,
    lng: 20.786,
    radius: 600,
    name: 'Отворено езеро',
    subtitle: 'Едно од најстарите езера во светот',
    story: {
      mk: 'Сега сме на отворено езеро. Охридското Езеро е старо повеќе од еден милион години и е едно од најстарите езера во светот. Длабоко е речиси триста метри, а водата е толку бистра што на места се гледа дно и на дваесет метри длабочина. Голем дел од водата доаѓа од подземни извори, кои низ карстот на планината Галичица ја носат водата од Преспанското Езеро. Тука живеат повеќе од двесте ендемски видови, меѓу кои и познатата охридска пастрмка, летницата.',
      en: 'We are now on the open lake. Lake Ohrid is more than a million years old, making it one of the oldest lakes in the world. It is almost three hundred metres deep, and the water is so clear that in places you can see the bottom twenty metres down. Much of its water arrives through underground springs, carried through the limestone of Mount Galičica from Lake Prespa. More than two hundred endemic species live here, including the famous Ohrid trout, known locally as letnica.',
      sr: 'Sada smo na otvorenom jezeru. Ohridsko jezero staro je više od milijun godina i jedno je od najstarijih jezera na svijetu. Duboko je gotovo tristo metara, a voda je toliko bistra da se ponegdje vidi dno i na dvadeset metara dubine. Velik dio vode dolazi iz podzemnih izvora, koji kroz vapnenac planine Galičice donose vodu iz Prespanskog jezera. Ovdje živi više od dvjesto endemskih vrsta, među kojima i čuvena ohridska pastrva, letnica.',
      pl: 'Jesteśmy teraz na otwartym jeziorze. Jezioro Ochrydzkie ma ponad milion lat i jest jednym z najstarszych jezior na świecie. Ma prawie trzysta metrów głębokości, a woda jest tak przejrzysta, że miejscami widać dno na głębokości dwudziestu metrów. Duża część wody dopływa podziemnymi źródłami, które przez wapienne skały góry Galičica przynoszą wodę z Jeziora Prespa. Żyje tu ponad dwieście gatunków endemicznych, w tym słynny pstrąg ochrydzki, zwany letnicą.',
      tr: "Şimdi açık göldeyiz. Ohri Gölü bir milyon yıldan daha yaşlıdır ve dünyanın en eski göllerinden biridir. Derinliği neredeyse üç yüz metreyi bulur ve suyu o kadar berraktır ki bazı yerlerde yirmi metre derinlikteki dip görülebilir. Suyunun büyük kısmı, Galiçiça Dağı'nın kireçtaşı içinden Prespa Gölü'nden gelen yeraltı kaynaklarından beslenir. Burada, ünlü Ohri alabalığı letnica da dahil olmak üzere iki yüzden fazla endemik tür yaşar.",
      de: 'Wir sind jetzt auf dem offenen See. Der Ohridsee ist mehr als eine Million Jahre alt und damit einer der ältesten Seen der Welt. Er ist fast dreihundert Meter tief, und das Wasser ist so klar, dass man an manchen Stellen zwanzig Meter tief bis auf den Grund sieht. Ein großer Teil seines Wassers kommt aus unterirdischen Quellen, die durch den Kalkstein des Galičica-Gebirges vom Prespasee herübergeleitet werden. Hier leben mehr als zweihundert endemische Arten, darunter die berühmte Ohrid-Forelle, hier Letnica genannt.',
    },
  },
  {
    id: 'galicica',
    lat: 41.045,
    lng: 20.795,
    radius: 450,
    name: 'Планина Галичица',
    subtitle: 'Национален парк меѓу две езера',
    story: {
      mk: 'Лево од нас, над источниот брег, се издига планината Галичица. Од 1958 година таа е национален парк, кој се протега меѓу две езера, Охридското и Преспанското. Нејзиниот највисок врв, Магаро, е висок над две илјади и двесте метри, а од горе во ист миг се гледаат двете езера. На Галичица растат многу ретки растенија што ги нема никаде на друго место во светот. Летно време од нејзините падини полетуваат параглајдери, што се спуштаат токму кон брегот на езерото.',
      en: 'To our left, above the eastern shore, rises Mount Galičica. Since 1958 it has been a national park, stretching between two lakes, Lake Ohrid and Lake Prespa. Its highest peak, Magaro, is more than two thousand two hundred metres high, and from the top you can see both lakes at once. Galičica is home to many rare plants found nowhere else in the world. In summer, paragliders take off from its slopes and glide down towards the lake shore.',
      sr: 'Lijevo od nas, iznad istočne obale, uzdiže se planina Galičica. Od 1958. godine ona je nacionalni park, koji se proteže između dvaju jezera, Ohridskog i Prespanskog. Njezin najviši vrh, Magaro, visok je preko dvije tisuće i dvjesto metara, a s vrha se istodobno vide oba jezera. Na Galičici rastu mnoge rijetke biljke kojih nema nigdje drugdje na svijetu. Ljeti s njezinih padina polijeću paraglajderi i spuštaju se ravno prema obali jezera.',
      pl: 'Po naszej lewej stronie, nad wschodnim brzegiem, wznosi się góra Galičica. Od 1958 roku jest parkiem narodowym, rozciągającym się między dwoma jeziorami, Ochrydzkim i Prespa. Jej najwyższy szczyt, Magaro, ma ponad dwa tysiące dwieście metrów wysokości, a ze szczytu widać jednocześnie oba jeziora. Na Galičicy rośnie wiele rzadkich roślin, których nie ma nigdzie indziej na świecie. Latem z jej zboczy startują paralotniarze, szybujący w stronę brzegu jeziora.',
      tr: "Solumuzda, doğu kıyısının üzerinde Galiçitsa Dağı yükseliyor. 1958'den beri milli park olan dağ, iki göl arasında, Ohri ve Prespa gölleri arasında uzanır. En yüksek zirvesi Magaro iki bin iki yüz metreyi aşar ve tepeden iki göl aynı anda görülür. Galiçitsa'da dünyanın başka hiçbir yerinde bulunmayan pek çok nadir bitki yetişir. Yazın yamaçlarından yamaç paraşütçüleri havalanır ve göl kıyısına doğru süzülür.",
      de: 'Zu unserer Linken, über dem Ostufer, erhebt sich das Galičica-Gebirge. Seit 1958 ist es ein Nationalpark, der sich zwischen zwei Seen erstreckt, dem Ohridsee und dem Prespasee. Sein höchster Gipfel, der Magaro, ist mehr als zweitausendzweihundert Meter hoch, und von oben sieht man beide Seen zugleich. Auf der Galičica wachsen viele seltene Pflanzen, die es sonst nirgends auf der Welt gibt. Im Sommer starten Gleitschirmflieger von ihren Hängen und schweben hinunter zum Seeufer.',
    },
  },
  {
    id: 'pestani',
    lat: 41.022,
    lng: 20.806,
    radius: 350,
    name: 'Пештани',
    subtitle: 'Рибарско село и летувалиште',
    story: {
      mk: 'Пред нас е Пештани, некогаш мирно рибарско село, а денес едно од најпосакуваните летувалишта на Охридското Езеро. Селото лежи во подножјето на Галичица, а неговите чакалести плажи и чистата вода секое лето привлекуваат гости од цела Македонија и странство. Веднаш јужно од селото е ридот Градиште, со остатоци од античка тврдина, а под него Заливот на коските, кон кој пловиме сега.',
      en: 'Ahead of us is Peštani, once a quiet fishing village and today one of the most popular resorts on Lake Ohrid. The village lies at the foot of Mount Galičica, and its pebble beaches and clear water attract visitors from all over Macedonia and abroad every summer. Just south of the village is the hill of Gradište, with the remains of an ancient fortress, and below it the Bay of Bones, where we are heading now.',
      sr: 'Ispred nas je Peštani, nekoć mirno ribarsko selo, a danas jedno od najomiljenijih ljetovališta na Ohridskom jezeru. Selo leži u podnožju Galičice, a njegove šljunčane plaže i čista voda svakog ljeta privlače goste iz cijele Makedonije i inozemstva. Odmah južno od sela je brdo Gradište, s ostacima antičke tvrđave, a ispod njega Zaljev kostiju, prema kojem sada plovimo.',
      pl: 'Przed nami Peštani, niegdyś spokojna wioska rybacka, a dziś jeden z najpopularniejszych kurortów nad Jeziorem Ochrydzkim. Wioska leży u stóp góry Galičica, a jej kamieniste plaże i czysta woda każdego lata przyciągają gości z całej Macedonii i z zagranicy. Tuż na południe od wioski wznosi się wzgórze Gradište z ruinami starożytnej twierdzy, a pod nim Zatoka Kości, do której właśnie płyniemy.',
      tr: "Önümüzde, bir zamanlar sakin bir balıkçı köyü olan ve bugün Ohri Gölü'nün en sevilen tatil yerlerinden biri olan Peştani var. Köy Galiçitsa Dağı'nın eteğinde yer alır; çakıllı plajları ve berrak suyu her yaz Makedonya'nın dört bir yanından ve yurt dışından ziyaretçi çeker. Köyün hemen güneyinde antik bir kalenin kalıntılarının bulunduğu Gradişte tepesi, onun altında da şimdi doğru gittiğimiz Kemikler Koyu bulunur.",
      de: 'Vor uns liegt Peštani, einst ein ruhiges Fischerdorf und heute einer der beliebtesten Ferienorte am Ohridsee. Das Dorf liegt am Fuß des Galičica-Gebirges, und seine Kieselstrände und das klare Wasser locken jeden Sommer Besucher aus ganz Mazedonien und dem Ausland an. Gleich südlich des Dorfes liegt der Hügel Gradište mit den Resten einer antiken Festung, und darunter die Bucht der Knochen, zu der wir jetzt fahren.',
    },
  },
  {
    id: 'bay-of-bones',
    lat: 41.0108,
    lng: 20.809,
    radius: 400,
    name: 'Заливот на коските',
    subtitle: 'Праисториска населба на вода',
    story: {
      mk: 'Пред нас е Заливот на коските, кај полуостровот Градиште. Тука, пред околу три илјади години, луѓето живееле во куќи изградени на дрвени колци над водата. Нуркачите на дното откриле илјадници колци, како и керамика и коски од животни, по кои заливот го добил своето име. Денес на истото место е реконструирана населбата, со платформа и колибите од тоа време, и претставува музеј на вода. На ридот над неа се наоѓаат остатоците од римска тврдина.',
      en: 'Ahead of us is the Bay of Bones, beside the Gradište peninsula. Around three thousand years ago people lived here in houses built on wooden piles above the water. Divers have found thousands of piles on the lake bed, along with pottery and animal bones, which gave the bay its name. Today the settlement has been reconstructed on the very same spot, with its platform and huts, as a museum on the water. On the hill above are the remains of a Roman fortress.',
      sr: 'Ispred nas je Zaljev kostiju, kod poluotoka Gradište. Ovdje su prije otprilike tri tisuće godina ljudi živjeli u kućama podignutima na drvenim stupovima iznad vode. Ronioci su na dnu otkrili tisuće stupova, kao i keramiku i životinjske kosti, po kojima je zaljev dobio ime. Danas je na istome mjestu rekonstruirano naselje, s platformom i kolibama iz toga vremena, kao muzej na vodi. Na brdu iznad njega nalaze se ostaci rimske tvrđave.',
      pl: 'Przed nami Zatoka Kości, przy półwyspie Gradište. Około trzech tysięcy lat temu ludzie mieszkali tu w domach zbudowanych na drewnianych palach nad wodą. Nurkowie znaleźli na dnie tysiące pali, a także ceramikę i kości zwierząt, od których zatoka wzięła swoją nazwę. Dziś w tym samym miejscu odtworzono osadę, z pomostem i chatami, jako muzeum na wodzie. Na wzgórzu powyżej znajdują się ruiny rzymskiej twierdzy.',
      tr: 'Önümüzde, Gradişte yarımadasının yanında Kemikler Koyu var. Yaklaşık üç bin yıl önce insanlar burada, suyun üzerinde ahşap kazıklara kurulmuş evlerde yaşıyordu. Dalgıçlar göl tabanında binlerce kazığın yanı sıra çanak çömlek ve koya adını veren hayvan kemikleri buldu. Bugün yerleşim, platformu ve kulübeleriyle aynı yerde, suyun üzerinde bir müze olarak yeniden inşa edildi. Yukarıdaki tepede bir Roma kalesinin kalıntıları bulunur.',
      de: 'Vor uns liegt die Bucht der Knochen neben der Halbinsel Gradište. Vor etwa dreitausend Jahren lebten hier Menschen in Häusern auf Holzpfählen über dem Wasser. Taucher haben auf dem Seegrund Tausende Pfähle gefunden, dazu Keramik und Tierknochen, die der Bucht ihren Namen gaben. Heute ist die Siedlung an genau derselben Stelle mit ihrer Plattform und ihren Hütten als Museum auf dem Wasser nachgebaut. Auf dem Hügel darüber liegen die Reste einer römischen Festung.',
    },
  },
  {
    id: 'trpejca',
    lat: 40.9582,
    lng: 20.7765,
    radius: 380,
    name: 'Трпејца',
    subtitle: 'Последното рибарско село',
    story: {
      mk: 'Лево од нас е Трпејца, едно од последните вистински рибарски села на македонскиот брег на езерото. Куќите се натрупани по стрмниот брег, со црвени покриви и мали дворови, а рибарските чамци и денес се врзани пред самите куќи. Поради неговите мали плажи и бистра вода, некои го нарекуваат охридскиот Сен Тропе. Зад селото се издигнуваат падините на Националниот парк Галичица.',
      en: 'On our left is Trpejca, one of the last true fishing villages on the Macedonian shore of the lake. Its houses with red roofs and small courtyards are stacked along the steep shore, and fishing boats are still moored right in front of them. Because of its little beaches and clear water, some call it the Saint-Tropez of Ohrid. Behind the village rise the slopes of Galičica National Park.',
      sr: 'Lijevo od nas je Trpejca, jedno od posljednjih pravih ribarskih sela na makedonskoj obali jezera. Kuće s crvenim krovovima i malim dvorištima nanizane su po strmoj obali, a ribarski čamci i danas su privezani ispred samih kuća. Zbog malih plaža i bistre vode neki je zovu ohridskim Saint-Tropezom. Iza sela uzdižu se padine Nacionalnog parka Galičica.',
      pl: 'Po lewej stronie widzimy Trpejcę, jedną z ostatnich prawdziwych wiosek rybackich na macedońskim brzegu jeziora. Domy z czerwonymi dachami i małymi podwórkami tłoczą się na stromym brzegu, a łodzie rybackie wciąż cumują tuż przed nimi. Ze względu na małe plaże i czystą wodę niektórzy nazywają ją ochrydzkim Saint-Tropez. Za wioską wznoszą się zbocza Parku Narodowego Galičica.',
      tr: "Solumuzda, gölün Makedonya kıyısındaki son gerçek balıkçı köylerinden biri olan Trpeyça var. Kırmızı çatılı ve küçük avlulu evler dik kıyı boyunca sıralanır, balıkçı tekneleri bugün hâlâ evlerin hemen önüne bağlanır. Küçük plajları ve berrak suyu nedeniyle bazıları burayı Ohri'nin Saint-Tropez'i olarak adlandırır. Köyün arkasında Galiçiça Milli Parkı'nın yamaçları yükselir.",
      de: 'Zu unserer Linken liegt Trpejca, eines der letzten echten Fischerdörfer am mazedonischen Ufer des Sees. Die Häuser mit roten Dächern und kleinen Höfen drängen sich am steilen Ufer, und die Fischerboote liegen noch heute direkt vor den Häusern vor Anker. Wegen seiner kleinen Strände und des klaren Wassers nennen manche es das Saint-Tropez von Ohrid. Hinter dem Dorf erheben sich die Hänge des Nationalparks Galičica.',
    },
  },
  {
    id: 'zaum',
    lat: 40.9405,
    lng: 20.7665,
    radius: 350,
    name: 'Св. Богородица Заум',
    subtitle: 'Скриена црква до која се стига со брод',
    story: {
      mk: 'На брегот пред нас е црквата Света Богородица Заум, изградена во четиринаесеттиот век. Сместена е во мирен залив под планината Галичица, далеку од патиштата, па и денес до неа најлесно се стига со брод. Во внатрешноста се зачувани фрески од времето на нејзиното градење. Тишината на ова место ни покажува како изгледал брегот на езерото пред многу векови.',
      en: 'On the shore ahead is the Church of the Holy Mother of God Zaum, built in the fourteenth century. It sits in a quiet cove beneath Mount Galičica, far from any road, so even today the easiest way to reach it is by boat. Inside, frescoes from the time of its construction have survived. The silence of this place shows us what the lakeshore looked like centuries ago.',
      sr: 'Na obali ispred nas je crkva Svete Bogorodice Zaum, izgrađena u četrnaestom stoljeću. Smještena je u mirnom zaljevu podno planine Galičice, daleko od cesta, pa se i danas do nje najlakše stiže brodom. U unutrašnjosti su sačuvane freske iz vremena njezine izgradnje. Tišina ovoga mjesta pokazuje nam kako je obala jezera izgledala prije mnogo stoljeća.',
      pl: 'Na brzegu przed nami stoi cerkiew Matki Bożej Zaum, zbudowana w czternastym wieku. Leży w cichej zatoce u stóp góry Galičica, z dala od dróg, dlatego nawet dziś najłatwiej dotrzeć do niej łodzią. Wewnątrz zachowały się freski z czasów jej budowy. Cisza tego miejsca pokazuje, jak wyglądał brzeg jeziora wiele wieków temu.',
      tr: "Önümüzdeki kıyıda, on dördüncü yüzyılda inşa edilen Meryem Ana Zaum Kilisesi var. Galiçiça Dağı'nın eteğinde, yollardan uzak sessiz bir koyda yer alır, bu yüzden bugün bile oraya ulaşmanın en kolay yolu tekneyle gitmektir. İçeride, inşa edildiği döneme ait freskler korunmuştur. Bu yerin sessizliği, göl kıyısının yüzyıllar önce nasıl göründüğünü bize gösterir.",
      de: 'Am Ufer vor uns steht die Kirche der Heiligen Muttergottes Zaum, erbaut im vierzehnten Jahrhundert. Sie liegt in einer stillen Bucht unterhalb des Galičica-Gebirges, fern jeder Straße, deshalb erreicht man sie auch heute am einfachsten mit dem Boot. Im Inneren sind Fresken aus der Zeit ihres Baus erhalten. Die Stille dieses Ortes zeigt uns, wie das Seeufer vor vielen Jahrhunderten ausgesehen hat.',
    },
  },
  {
    id: 'st-naum',
    lat: 40.9168,
    lng: 20.7437,
    radius: 420,
    name: 'Манастир Св. Наум',
    subtitle: 'Изворите и манастирот на крајот од патот',
    story: {
      mk: 'Пристигнуваме кај манастирот Свети Наум, крајната точка на нашата тура. Манастирот го основал Свети Наум Охридски на почетокот на десеттиот век, ученик на светите браќа Кирил и Методиј. Денешната црква е подоцна изградена врз старите темели, а во неа се наоѓа гробот на светителот. Според преданието, ако го приближите увото до гробот, ќе го слушнете отчукувањето на неговото срце. Покрај манастирот извираат бистрите извори на Свети Наум, кои го хранат езерото со вода од Преспа, а во дворот слободно шетаат пауни. Ви благодариме што бевте со нас!',
      en: 'We are arriving at the Monastery of St. Naum, the final stop of our tour. It was founded at the beginning of the tenth century by Saint Naum of Ohrid, a disciple of the holy brothers Cyril and Methodius. Today’s church was built later on the old foundations, and it holds the saint’s tomb. According to tradition, if you put your ear to the tomb, you can hear his heart still beating. Beside the monastery rise the crystal-clear springs of St. Naum, which feed the lake with water from Prespa, and peacocks roam freely in the courtyard. Thank you for travelling with us!',
      sr: 'Stižemo do manastira Svetog Nauma, krajnje točke naše ture. Manastir je početkom desetog stoljeća osnovao sveti Naum Ohridski, učenik svete braće Ćirila i Metoda. Današnja crkva kasnije je podignuta na starim temeljima, a u njoj se nalazi grob sveca. Prema predaji, ako prislonite uho uz grob, čut ćete otkucaje njegova srca. Pokraj manastira izviru bistri izvori Svetog Nauma, koji jezero hrane vodom iz Prespe, a dvorištem slobodno šeću paunovi. Hvala vam što ste bili s nama!',
      pl: 'Dopływamy do monasteru świętego Nauma, ostatniego przystanku naszego rejsu. Monaster założył na początku dziesiątego wieku święty Naum Ochrydzki, uczeń świętych braci Cyryla i Metodego. Dzisiejsza cerkiew powstała później na dawnych fundamentach i kryje grób świętego. Według tradycji, jeśli przyłożysz ucho do grobu, usłyszysz bicie jego serca. Obok monasteru wypływają krystalicznie czyste źródła świętego Nauma, które zasilają jezioro wodą z Prespy, a po dziedzińcu swobodnie przechadzają się pawie. Dziękujemy, że płynęliście z nami!',
      tr: "Turumuzun son durağı olan Aziz Naum Manastırı'na varıyoruz. Manastırı, onuncu yüzyılın başında, kutsal kardeşler Kiril ve Metodi'nin öğrencisi Ohrili Aziz Naum kurdu. Bugünkü kilise daha sonra eski temellerin üzerine inşa edildi ve azizin mezarı buradadır. Rivayete göre kulağınızı mezara dayarsanız kalbinin hâlâ attığını duyarsınız. Manastırın yanında, göle Prespa'dan su taşıyan Aziz Naum'un berrak kaynakları çıkar ve avluda tavus kuşları serbestçe dolaşır. Bizimle olduğunuz için teşekkür ederiz!",
      de: 'Wir erreichen das Kloster des heiligen Naum, die letzte Station unserer Tour. Es wurde Anfang des zehnten Jahrhunderts vom heiligen Naum von Ohrid gegründet, einem Schüler der heiligen Brüder Kyrill und Method. Die heutige Kirche wurde später auf den alten Fundamenten errichtet und birgt das Grab des Heiligen. Der Überlieferung nach hört man seinen Herzschlag, wenn man das Ohr an das Grab legt. Neben dem Kloster entspringen die kristallklaren Quellen des heiligen Naum, die den See mit Wasser aus dem Prespasee speisen, und im Hof spazieren frei Pfauen umher. Vielen Dank, dass Sie mit uns gereist sind!',
    },
  },
]
