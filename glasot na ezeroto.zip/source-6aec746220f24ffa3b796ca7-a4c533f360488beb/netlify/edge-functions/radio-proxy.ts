/**
 * Relays an http-only online-radio stream over https, because a page served
 * over https may not play http audio. Only http:// audio responses from
 * public hosts are relayed; the body is piped through untouched.
 */

const isPrivateHost = (host: string) => {
  const h = host.toLowerCase().replace(/^\[|\]$/g, '')
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.internal'))
    return true
  if (h.includes(':')) return true // no IPv6 literals
  const m = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/)
  if (!m) return false
  const [a, b] = [Number(m[1]), Number(m[2])]
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    (a === 100 && b >= 64 && b <= 127)
  )
}

const AUDIO = /^audio\/|application\/ogg|octet-stream|aacp|mpeg/i

export default async (req: Request) => {
  const raw = new URL(req.url).searchParams.get('url')
  let target: URL
  try {
    target = new URL(raw ?? '')
  } catch {
    return new Response('Bad url', { status: 400 })
  }
  if (target.protocol !== 'http:' || isPrivateHost(target.hostname))
    return new Response('Not allowed', { status: 400 })

  let upstream: Response
  try {
    upstream = await fetch(target, {
      headers: { 'user-agent': 'Mozilla/5.0 (Glasot na ezeroto audio guide)' },
      redirect: 'follow',
      signal: req.signal,
    })
  } catch {
    return new Response('Radio unreachable', { status: 502 })
  }
  const type = upstream.headers.get('content-type') ?? ''
  if (
    !upstream.ok ||
    !upstream.body ||
    !AUDIO.test(type) ||
    /mpegurl/i.test(type)
  ) {
    upstream.body?.cancel()
    return new Response('Not an audio stream', { status: 502 })
  }
  return new Response(upstream.body, {
    headers: {
      'content-type': type,
      'cache-control': 'no-store',
    },
  })
}

export const config = {
  path: '/radio-proxy',
  cache: 'manual',
}
