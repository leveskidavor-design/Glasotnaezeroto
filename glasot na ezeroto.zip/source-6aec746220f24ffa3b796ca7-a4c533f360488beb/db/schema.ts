import {
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  text,
  timestamp,
} from 'drizzle-orm/pg-core'

/**
 * Admin overrides for a stop's geofence. Stops without a row use the
 * defaults bundled in src/data/tour.ts.
 */
export const stopPositions = pgTable('stop_positions', {
  stopId: text('stop_id').primaryKey(),
  lat: doublePrecision().notNull(),
  lng: doublePrecision().notNull(),
  radius: integer().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
})

/**
 * Admin-drawn demo route (a single row, id 'default'). When absent the
 * ROUTE bundled in src/data/tour.ts is used.
 */
export const tourRoute = pgTable('tour_route', {
  id: text().primaryKey(),
  points: jsonb().$type<[number, number][]>().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
})

/**
 * Admin-edited texts. Keys are `stop:<stopId>:name`, `stop:<stopId>:subtitle`,
 * `stop:<stopId>:story:<lang>` and `ui:<stringKey>`. Missing keys use the
 * bundled defaults (src/data/tour.ts and src/lib/i18n.ts).
 */
export const contentTexts = pgTable('content_texts', {
  key: text().primaryKey(),
  value: text().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
})

/** Boats (companies). Each has its own tour link /b/<id> and password. */
export const boats = pgTable('boats', {
  /** URL code, e.g. "marija" */
  id: text().primaryKey(),
  name: text().notNull(),
  /** scrypt: "salt:hash" (hex) */
  passwordHash: text('password_hash').notNull(),
  /** How many devices may be logged in to this boat's tour at once */
  maxDevices: integer('max_devices').notNull().default(1),
  createdAt: timestamp('created_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
})

/** A boat's own stop positions, over the global ones. */
export const boatStopPositions = pgTable(
  'boat_stop_positions',
  {
    boatId: text('boat_id')
      .notNull()
      .references(() => boats.id, { onDelete: 'cascade' }),
    stopId: text('stop_id').notNull(),
    lat: doublePrecision().notNull(),
    lng: doublePrecision().notNull(),
    radius: integer().notNull(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.boatId, t.stopId] })],
)

/** A boat's own texts (same keys as content_texts), over the global ones. */
export const boatTexts = pgTable(
  'boat_texts',
  {
    boatId: text('boat_id')
      .notNull()
      .references(() => boats.id, { onDelete: 'cascade' }),
    key: text().notNull(),
    value: text().notNull(),
    updatedAt: timestamp('updated_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.boatId, t.key] })],
)

/**
 * Devices logged in to a boat's tour (at most boats.max_devices). The device
 * keeps a random token in an httpOnly cookie; only its sha256 is stored.
 */
export const boatDevices = pgTable(
  'boat_devices',
  {
    id: text().primaryKey(),
    boatId: text('boat_id')
      .notNull()
      .references(() => boats.id, { onDelete: 'cascade' }),
    tokenHash: text('token_hash').notNull().unique(),
    /** e.g. "iPhone · Safari" */
    label: text().notNull(),
    createdAt: timestamp('created_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
    lastSeenAt: timestamp('last_seen_at', { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index('boat_devices_boat_idx').on(t.boatId)],
)
