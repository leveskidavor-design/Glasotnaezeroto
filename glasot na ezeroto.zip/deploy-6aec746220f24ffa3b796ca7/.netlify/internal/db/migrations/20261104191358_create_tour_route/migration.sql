CREATE TABLE "tour_route" (
	"id" text PRIMARY KEY,
	"points" jsonb NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
