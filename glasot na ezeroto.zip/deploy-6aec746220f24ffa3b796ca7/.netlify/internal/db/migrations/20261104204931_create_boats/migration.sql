CREATE TABLE "boat_stop_positions" (
	"boat_id" text,
	"stop_id" text,
	"lat" double precision NOT NULL,
	"lng" double precision NOT NULL,
	"radius" integer NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "boat_stop_positions_pkey" PRIMARY KEY("boat_id","stop_id")
);
--> statement-breakpoint
CREATE TABLE "boat_texts" (
	"boat_id" text,
	"key" text,
	"value" text NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "boat_texts_pkey" PRIMARY KEY("boat_id","key")
);
--> statement-breakpoint
CREATE TABLE "boats" (
	"id" text PRIMARY KEY,
	"name" text NOT NULL,
	"password_hash" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "boat_stop_positions" ADD CONSTRAINT "boat_stop_positions_boat_id_boats_id_fkey" FOREIGN KEY ("boat_id") REFERENCES "boats"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "boat_texts" ADD CONSTRAINT "boat_texts_boat_id_boats_id_fkey" FOREIGN KEY ("boat_id") REFERENCES "boats"("id") ON DELETE CASCADE;