CREATE TABLE "stop_positions" (
	"stop_id" text PRIMARY KEY,
	"lat" double precision NOT NULL,
	"lng" double precision NOT NULL,
	"radius" integer NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
